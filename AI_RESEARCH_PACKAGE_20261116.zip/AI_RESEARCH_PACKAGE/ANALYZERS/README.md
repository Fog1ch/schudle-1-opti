# Анализаторы

- offline_query.py: полностью автономный read-only поиск и manifest verification; только standard library.
- native-index/Program.cs и Analyzer.csproj: read-only Cecil/Iced extraction, требует локальные game/dependency files; старые listings не повторяет.
- asset_links.py: bounds-checked v22 object/external reference extension, candidate names heuristic.
- baseline.py / checkpoint_and_review.py / summarize_evidence.py: provenance текущего исследования, исходная lab layout.
- build_package.py / package_content.py: recipe текущего пакета, не обязательны для offline использования.
- archive/static_inventory.py: исторический алгоритм с отсутствующим здесь s1lab dependency, читать как source only.

Не выполнять старые verify/finalize/apply команды из historical README поверх исходного evidence. Текущая независимая проверка: `python ANALYZERS/offline_query.py verify .` из package root.

Ни одного оптимизационного runtime DLL здесь нет.

qa_package.py и refine_package.py сохранены как recipe текущей проверки/редакции и требуют исходной lab layout. Не запускать refine_package повторно на финальном пакете. Для получателя независимая проверка только offline_query.py verify.
