"""Read-only Unity SerializedFile v22 dependency/object metadata index. No payload decoding."""
from pathlib import Path
import json,struct,collections,hashlib,csv,re
R=Path(__file__).parent; G=Path(r'B:\Schedule I');O=R/'evidence';O.mkdir(exist_ok=True)
def parse(p):
 with p.open('rb') as f:
  h=f.read(48);v=struct.unpack_from('>I',h,8)[0];assert v==22
  endian='<' if h[16]==0 else '>';ms,size,off,_=struct.unpack_from('>IQQQ',h,20);assert size==p.stat().st_size and ms<64*1024*1024;buf=f.read(ms)
 pos=0
 def rd(fmt):
  nonlocal pos
  st=struct.Struct(endian+fmt);assert pos+st.size<=len(buf);x=st.unpack_from(buf,pos);pos+=st.size;return x[0] if len(x)==1 else x
 def skip(n):
  nonlocal pos
  assert n>=0 and pos+n<=len(buf);pos+=n
 def string():
  nonlocal pos
  end=buf.index(0,pos);s=buf[pos:end].decode('utf-8',errors='replace');pos=end+1;return s
 unity=string();platform=rd('i');tree=rd('?');nt=rd('i');assert 0<=nt<100000;types=[]
 for _ in range(nt):
  cid=rd('i');rd('?');rd('h')
  if cid==114:skip(16)
  skip(16)
  if tree:
   nodes=rd('i');ss=rd('i');skip(nodes*32);skip(ss);nd=rd('i');skip(nd*4)
  types.append(cid)
 count=rd('i');assert 0<=count<10000000;counts=collections.Counter();rows=[]
 for _ in range(count):
  skip((-pos)%4);pid=rd('q');start=rd('q')+off;n=rd('I');ti=rd('i');assert 0<=ti<len(types) and off<=start<=start+n<=size;cid=types[ti];counts[cid]+=1
  if cid in [21,28,43,48,83,142,30,47,141,104,187]:rows.append({'container':p.name,'path_id':pid,'class_id':cid,'file_offset':start,'serialized_bytes':n})
 refs=[];err=None
 try:
  ns=rd('i');assert 0<=ns<1000000
  for _ in range(ns):rd('i');skip((-pos)%4);rd('q')
  ne=rd('i');assert 0<=ne<100000
  for idx in range(ne):
   empty=string();guid=buf[pos:pos+16].hex();skip(16);kind=rd('i');path=string();refs.append({'file_id':idx+1,'guid':guid,'type':kind,'path':path})
 except Exception as e:err=type(e).__name__+': '+str(e)
 # m_Name is a length-prefixed string at start for these selected built-player NamedObject layouts.
 # Candidate only; no versioned type database or semantic payload decoding.
 with p.open('rb') as f:
  for row in rows:
   if row['class_id'] not in [21,28,43,48,83,187] or row['serialized_bytes']<4:continue
   f.seek(row['file_offset']);n=struct.unpack(endian+'i',f.read(4))[0]
   if 0<=n<=min(512,row['serialized_bytes']-4):
    try:
     name=f.read(n).decode('utf-8')
     if all(ord(c)>=32 or c=='\t' for c in name):row['candidate_name']=name
    except UnicodeDecodeError:pass
 return {'container':p.name,'unity':unity,'version':v,'objects':count,'type_tree':tree,'class_counts':dict(counts),'external_references':refs,'external_parse_error':err,'metadata_cursor':pos,'metadata_buffer_bytes':len(buf),'scope':'Object table and external file references. Candidate names not schema-verified. Not dependency resolution of every PPtr; no mip formats/residency/GPU cost decoded.'},rows
containers=[];rows=[]
for p in sorted((G/'Schedule I_Data').iterdir()):
 if p.is_file() and (p.suffix=='.assets' or p.name=='globalgamemanagers' or re.fullmatch('level[0-9]+',p.name)):
  try:c,r=parse(p);containers.append(c);rows.extend(r)
  except Exception as e:containers.append({'container':p.name,'error':type(e).__name__+': '+str(e)})
(O/'asset-containers-current.json').write_text(json.dumps(containers,indent=2,ensure_ascii=False),encoding='utf-8')
with (O/'asset-object-index.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=['container','path_id','class_id','file_offset','serialized_bytes','candidate_name']);w.writeheader();w.writerows(rows)
print(json.dumps({'containers':len(containers),'selected_object_rows':len(rows),'errors':[x for x in containers if x.get('error') or x.get('external_parse_error')],'external_refs':sum(len(x.get('external_references',[])) for x in containers)},ensure_ascii=True))
