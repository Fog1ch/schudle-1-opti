from pathlib import Path
import json,hashlib,collections,datetime,subprocess,shutil
LAB=Path(__file__).resolve().parents[1]; GAME=Path(r'B:\Schedule I'); OUT=Path(__file__).parent
OUT.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''): h.update(b)
 return h.hexdigest()
def save(n,x): (OUT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
prior=json.loads((LAB/'phase2-npcmovement/MANIFEST.sha256.json').read_text()); checks=[]
for x in prior:
 p=LAB/'phase2-npcmovement'/x['path']; checks.append({'path':x['path'],'exists':p.exists(),'match':p.exists() and sha(p)==x['sha256']})
save('prior-evidence-integrity.json',checks)
files=[]; excluded=[]
for p in sorted(GAME.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(GAME).as_posix(); parts={s.lower() for s in p.relative_to(GAME).parts}
 if any('save' in s for s in parts): excluded.append(rel);continue
 st=p.stat(); files.append({'path':rel,'bytes':st.st_size,'mtime_ns':st.st_mtime_ns})
save('game-file-inventory.json',files)
critical=[]
for x in files:
 rel=x['path'];p=GAME/rel
 if p.name in ['GameAssembly.dll','UnityPlayer.dll','Schedule I.exe','baselib.dll','global-metadata.dat','boot.config','MelonPreferences.cfg','ScriptingAssemblies.json','RuntimeInitializeOnLoads.json'] or rel.startswith('Mods/') and p.suffix=='.dll' or rel.startswith('Schedule I_Data/') and (p.suffix=='.assets' or p.name in ['globalgamemanagers','level0','level1','level2']) or rel in ['MelonLoader/net6/Mono.Cecil.dll','MelonLoader/net6/Iced.dll']:
  critical.append({**x,'sha256':sha(p)})
save('critical-fingerprints.json',critical)
methods=json.loads((LAB/'phase2-npcmovement/evidence/methods-all.json').read_text()); types=collections.Counter(x['Type'] for x in methods)
patterns=['NPC','Path','Ragdoll','Avatar','Animation','Animator','TimeManager','LoadManager','ScheduleManager','Physics','Camera','Culling','LOD','Pool','Resource','Plant','Network','Render','Light','PlayerMovement','Vehicle','Visibility']
selection={k:[{'type':t,'methods':n} for t,n in types.items() if k.lower() in t.lower() and not '/' in t][:65] for k in patterns}
save('research-type-candidates.json',selection)
summary={'created':datetime.datetime.now().astimezone().isoformat(),'prior_manifest_entries':len(checks),'prior_manifest_failures':[x for x in checks if not x['match']],'inventory_files':len(files),'inventory_bytes':sum(x['bytes'] for x in files),'save_paths_excluded':len(excluded),'important_files_hashed':len(critical),'prior_method_entries':len(methods),'tools':{k:shutil.which(k) for k in ['python','dotnet','git','ilspycmd']},'restrictions':['No game execution','No original files or saves modified','No existing research overwritten','No packages installed','No optimization mod developed'],'scope':'Inventory excludes all save paths; fingerprints cover selected important files. Prior evidence reused only after integrity and binary identity checks.'}
save('BASELINE.json',summary)
print(json.dumps(summary,ensure_ascii=False,indent=2))
for name in ['assets.json','audit.json','mod-analysis.json']:
 data=json.loads((LAB/'evidence'/name).read_text(encoding='utf-8-sig'));print(name, 'keys',list(data)[:20] if isinstance(data,dict) else 'list '+str(len(data)));print(json.dumps(data if name=='mod-analysis.json' else (data[0] if isinstance(data,list) else {k:data[k] for k in list(data)[:2]}),ensure_ascii=False)[:3000])
print('TYPE CANDIDATES');print(json.dumps(selection,ensure_ascii=False)[:22000])
