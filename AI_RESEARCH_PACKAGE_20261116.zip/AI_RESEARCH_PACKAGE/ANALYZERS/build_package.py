from pathlib import Path
import json,shutil,csv,collections,hashlib,datetime,re
from package_content import SUBSYSTEMS,HANDOFF
R=Path(__file__).parent;L=R.parent;P=L/'EXPORT/AI_RESEARCH_PACKAGE';E=R/'evidence'
if P.exists():raise SystemExit('Package already exists; refusing overwrite. Preserve/version it explicitly.')
P.mkdir(parents=True)
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def put(n,s):
 p=P/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s.strip()+'\n',encoding='utf-8')
def cp(src,dst):
 p=P/dst;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,p)
def jput(n,x):put(n,json.dumps(x,ensure_ascii=False,indent=2))
for d in ['REVERSE_ENGINEERING','SUBSYSTEMS','CALL_GRAPHS','EVIDENCE','ANALYZERS']:(P/d).mkdir(exist_ok=True)
# Prior research preserved byte-for-byte; no binaries/build artifacts or configuration profiles.
prior=L/'phase2-npcmovement'
for p in prior.rglob('*'):
 if p.is_file() and not set(p.relative_to(prior).parts)&{'bin','obj','__pycache__'}:cp(p,'EVIDENCE/phase2/'+p.relative_to(prior).as_posix())
for n in ['PROJECT_STATE.md','REPORT.ru.md','README.ru.md']:cp(L/n,'EVIDENCE/prior/'+n)
for n in ['assets.json','mod-analysis.json','S1Perf.installed.cs','ScheduleRu.installed.cs']:cp(L/'evidence'/n,'EVIDENCE/prior/'+n)
for p in E.rglob('*'):
 if p.is_file():cp(p,'EVIDENCE/current/'+p.relative_to(E).as_posix())
for n in ['BASELINE.json','prior-evidence-integrity.json','critical-fingerprints.json','baseline-identity-check.json','PROJECT_STATE.phase3.json']:cp(R/n,'EVIDENCE/baseline/'+n)
for n in ['Program.cs','Analyzer.csproj']:cp(R/'analyzer'/n,'ANALYZERS/native-index/'+n)
for n in ['asset_links.py','baseline.py','summarize_evidence.py','checkpoint_and_review.py','offline_query.py','build_package.py','package_content.py']:cp(R/n,'ANALYZERS/'+n)
cp(L/'static_inventory.py','ANALYZERS/archive/static_inventory.py')
methods=read(E/'selected-methods.json');scans=read(E/'native-scans.json');edges=read(E/'native-edges.json');stats=read(E/'summary.json');fps=read(E/'original-files-sha256.json');assets=read(E/'asset-containers-current.json')
put('PROJECT_OVERVIEW.md','''# Schedule I Performance Overhaul: AI Research Package

Цель: передать автономный набор статических доказательств и проверяемых исследовательских направлений ИИ, не имеющему Custom MCP и доступа к этому компьютеру.

Это НЕ полное восстановление игры, не Unity project, не исходный C# код и не оптимизационный мод. Пакет позволяет продолжать анализ включённых листингов, формализовать поведение, проектировать проверки и запрашивать узкие недостающие данные. Новые неизвестные тела методов, asset payloads и runtime telemetry из одного пакета получить нельзя.

Начать с [состояния](PROJECT_STATE.md), [архитектуры](GAME_ARCHITECTURE.md), [правил evidence](REVERSE_ENGINEERING/EVIDENCE_RULES.md), затем [HANDOFF_PROMPT](HANDOFF_PROMPT.md).

Установка: `B:\\Schedule I`. Лаборатория: `C:\\Users\\herob\\Documents\\notion-code\\work\\ScheduleI-Performance-Lab-20261115`.

Все работы read-only относительно игры. Игра не запускалась. Сохранения не читались и не изменялись. Никакие новые пакеты не установлены, игровой мод не разработан. Исходные отчёты и phase2 evidence сохранены. Новое исследование датировано 2026-11-16 Europe/Warsaw.

Результаты по десяти направлениям имеют разную глубину: глубокий ограниченный NPCMovement reuse, выборочный native анализ новых корней, managed-mod IL, метаданные ресурсов. GPU workload остаётся неизвестным без runtime.''')
put('PROJECT_STATE.md',f'''# Текущее состояние

Дата: 2026-11-16. Статическая исследовательская поставка. Итог машинной проверки находится в [QA_REPORT.json](QA_REPORT.json); сама проверка не доказывает полноту reverse engineering.

## Выполнено
- Прочитаны исходные PROJECT_STATE, REPORT, README и phase2 REPORT. Проверены все 252 entries прежнего phase2 manifest, несовпадений нет.
- Исходные шесть identity hashes совпали. Инвентаризированы и хэшированы {len(fps)} файлов, исключены save paths. Хэши не являются копией их содержимого.
- Повторно использованы 146047 address-bearing method entries и исходное NPC evidence. Полный глобальный native scan не повторялся.
- Расширенный выбранный индекс: {stats['SelectedMethodEntries']} method entries; {stats['NativeRoots']} native ranges; {stats['NativeEdges']} call/jump/indirect records; два Astar диапазона с INVALID, остальные выбранные диапазоны без INVALID.
- 15 managed mod/library assemblies, 26013 IL call/newobj sites, 103 Harmony attribute records. Один подтверждённый overlap объявленных targets.
- 9 SerializedFile v22 containers, 39 external file reference entries, 11016 выбранных serialized object index rows.
- Новые evidence и контрольная точка сохранены в phase3-handoff до упаковки.

## Новая информация относительно phase2
Animator ID cache, event-driven shadow LOD со setter dedup, ActionList staggering, retained path reference в AddPath/GetPath, callback-before-clear в EndSetDestination, Plant-light dependency, конкретный ShouldSave overlap. См. [находки](REVERSE_ENGINEERING/FINDINGS.md).

## Следующая граница
Формализовать callback reentrancy и все исходы UpdateDestination; закончить ownership/invalidation NPCPathCache; исследовать фактические patch semantics. Полная runtime приоритизация не выполнена и не разрешена. Не повторять готовую декомпозицию NPC roots без смены бинарников.

## Не выполнено
Нет полного indirect/callback/Burst/UnityPlayer graph, декодирования всех textures/scenes, активного render pipeline asset, всех dynamic Harmony targets, актуальных CPU/GPU/GC timings, FPS или поведения host/client в игре.

Предыдущая точка продолжения сохранена без изменений: [исходный PROJECT_STATE](EVIDENCE/prior/PROJECT_STATE.md).''')
put('GAME_ARCHITECTURE.md','''# Архитектура и связи

## Native Player и IL2CPP
Unity 2022.3.62f2 подтверждается предыдущим аудитом Player/контейнеров; девять контейнеров повторно сообщают эту версию. Game 0.4.7f12 и MelonLoader 0.7.3 Open-Beta происходят из исторического журнала, не проверки обновлений Steam. Текущий gate: SHA-256 оригинальных файлов.

Schedule I.exe загружает UnityPlayer; GameAssembly.dll содержит native IL2CPP code. global-metadata.dat имеет magic 0xFAB11BAF и version 31. Это не доказательство отсутствия защит во всём файле. PE image base 0x180000000; RVA, file offsets и sections: [PE layout](EVIDENCE/current/pe-layout.json).

Cpp2IL output содержит восстановленные типы/атрибуты Address/FieldOffset и заглушки. MelonLoader/Il2CppAssemblies содержит Interop proxies. Ни тот, ни другой слой не заменяет реальные machine bodies. Методы интерпретируются совместно с native listings.

## Основные связи
- NPCMovement → Unity NavMeshAgent/Path → Unity native engine; ragdoll → Rigidbody/ConstantForce; network guards/RPC → FishNet.
- NPCAnimation → AvatarAnimation → AvatarAnimationId → integer Animator API. IK/standup/bones связаны с ragdoll и visibility.
- TimeManager → ActionList staggered callbacks; NPC schedules и world simulation подписываются на события. Полный dispatch graph не восстановлен.
- Plant.MinPass → GrowContainer light/moisture → Grid.Tile → LightExposureNode. Это simulation lighting, не GPU pass.
- ShadowLODController → PlayerCamera movement events → distance policy → Light.shadows, запись только при смене mode.
- LoadManager coroutine → SceneManager.LoadSceneAsync → LoadRequest/events/network readiness; CleanUp → GUID/NavMeshUtility caches.
- Mods → MelonLoader/.NET runtime → Il2CppInterop → IL2CPP-aware hooks/proxies. Actual patch order не установлен.

## Ресурсы
Serialized scene files level0/1/2 используют sharedassets/resources containers. .resS/.resource хранят внешние payloads. External reference index связывает containers, но не доказывает наличие всех объектных PPtr edges. `Library/unity default resources` является специальным engine reference, не обязательным физическим путём под игрой.

URP, AmplifyImpostors, Astar, RootMotion, TextMeshPro и FishNet присутствуют в assembly indices. Наличие сборки/кода не равно активному компоненту сцены. Experimental OcclusionManager не объявляется включённым.

[Assembly references](EVIDENCE/current/assembly-index.json), [managed/interop layers](EVIDENCE/current/managed-interop-assembly-index.json), [type inheritance](EVIDENCE/current/types.jsonl), [asset dependencies](CALL_GRAPHS/ASSET_DEPENDENCIES.dot).''')
put('GAME_INVENTORY.md',f'''# Инвентаризация

{len(fps)} файлов вне save paths, {sum(x['bytes'] for x in fps)} bytes. Это размер инвентаризированной установки на диске, не RAM/VRAM. 68 save-path файлов исключены из чтения и хэширования.

Полный путь относительно `B:\\Schedule I`, размер, время снимка и SHA-256: [original-files-sha256.json](EVIDENCE/current/original-files-sha256.json). Важные 30 fingerprint entries: [critical-fingerprints.json](EVIDENCE/baseline/critical-fingerprints.json).

Категории: Player/native DLL; metadata; Cpp2IL stubs; interop/Managed libraries; Mods и UserLibs; serialized scene/asset containers; .resS/.resource payloads; конфигурации. Backup-like DLL не объявляются загруженными.

15 индексированных managed mod/library assemblies не означают 15 активных модов: это 10 DLL верхнего уровня Mods и 5 UserLibs. Другие subdirectories и сторонние network helpers отражены в файловом inventory, но не исследовались на обход защиты.

## Как получить отсутствующий оригинал локально
Найти точный относительный путь и SHA-256 в inventory. Проверить `Get-FileHash -Algorithm SHA256 -LiteralPath <полный путь>` в PowerShell. Не скачивать неизвестный бинарник вместо оригинала. Для нового native метода использовать включённый analyser с его RVA и соответствующим index; для asset object использовать container/path_id/file_offset/serialized_bytes из CSV. Выгружать только нужный небольшой диапазон с hash исходника и способом извлечения.

## Ресурсные индексы
[Containers и external refs](EVIDENCE/current/asset-containers-current.json), [object index](EVIDENCE/current/asset-object-index.csv), [предыдущие counts](EVIDENCE/prior/assets.json). 3064 Texture2D, 1310 AudioClip, 206 Shader records из прежнего аудита сверяются с текущими tables в QA. Это не уникальные или активные ресурсы. Candidate names не подтверждены class database.

## Конфигурации
[Безопасная выборка](EVIDENCE/current/performance-config-evidence.json) содержит performance preferences и boot diff относительно локального `.orig` неизвестного происхождения. Не включены save payloads, полные логи, translator service credentials или исходные игровые бинарники. Прежние значения подтверждаются отдельно hash comparison текущих конфигураций с исторической baseline.''')
put('HANDOFF_PROMPT.md',HANDOFF)
put('REVERSE_ENGINEERING/EVIDENCE_RULES.md','''# Правила достоверности

CONFIRMED_STATIC: bytes/IL/metadata прямо подтверждают ограниченный вывод. HISTORICAL: прежний журнал или отчёт, не новый runtime. HYPOTHESIS: возможная стоимость/оптимизация. UNKNOWN: нет достаточного evidence.

Native edge означает machine call или внешнюю jump instruction в выбранном range. Не call frequency, не полный CFG. Косвенные вызовы, Unity callbacks и inlining требуют дополнительной карты. Cpp2IL Length не доказанная граница исходной функции. В phase2 сохранён unwind audit +1 byte для корней; новые roots такой общей гарантии не имеют.

Aliases по RVA неоднозначны. Даже единственное именованное попадание может быть generic representative (пример delegate constructor с именем IsBurstEnabledDelegate в обычной coroutine); не утверждать Burst activation из этого имени. Shared ret 0x43FEC0 не вызов всех aliased подсистем. Автоматический root-summary показывает адресные метки, не окончательное семантическое толкование.

Сигнатуры/поля stubs и interop не являются восстановленными C# bodies. Предпочтительный VA не runtime VA. Native hex в листингах есть RVA, если не указано иное.

Serialized tables проверены на bounds/type indices; extension external refs не прошёл независимую проверку зрелым asset reader. Candidate m_Name получен эвристикой начала payload. ClassID и offsets надёжнее candidate name. Нет доказательства active renderer/pipeline по одному assembly name.

Уровень полноты указан в SUBSYSTEMS. Не путать завершённую поставку пакета с полным reverse engineering игры. Для новых данных использовать [reproduction guide](REPRODUCTION.md).''')
put('REVERSE_ENGINEERING/NPC_DESTINATION_CONTRACT.md','''# UpdateDestination: границы безопасной замены

Источник: [листинг UpdateDestination](../EVIDENCE/phase2/evidence/UpdateDestination_8F9B70.asm.txt), [EndSetDestination](../EVIDENCE/phase2/evidence/EndSetDestination_8F4490.asm.txt), [поля](../EVIDENCE/phase2/evidence/npc-fields.json).

| Условие в порядке проверки | Наблюдаемое поведение |
|---|---|
| _hasDestination=false | Выход |
| NPC.IsInVehicle=true | EndSetDestination(Interrupted=1) |
| IsMoving=true либо pathPending=true | Выход без завершения |
| CanMove=false либо IsOnLadder=true | Выход без завершения |
| !IsAsCloseAsPossible(destination,constant) | SetDestination с текущей целью, callback и threshold; повторный вызов SetDestination, не доказанный новый path request; выход |
| Достижимость удовлетворена и agent.hasPath | ResetPath; обнулить поля +0x168 и +0x170, после каждой записи вызван helper 0x316AB0 |
| Финальная проверка distance < threshold | EndSetDestination(Success=4) |
| Первая distance не прошла | Снова прочитать destination/transform.position и пересчитать ту же Euclidean distance |
| Вторая distance < threshold | Success=4; иначе Partial=3 |

Условие native `comiss threshold,distance; ja` означает строгий `<`, не `<=`; unordered/NaN не проходит ветку ja. Не заменять sqrt на squared comparison без float proof.

## Callback before clear
В EndSetDestination 0x8F4490:
- проверить callback +0x178;
- 0x8F44B2: indirect delegate call с result;
- при нормальном возврате callback затем 0x8F44BC: callback = null; вызов helper 0x316AB0;
- 0x8F44CE: _hasDestination=false;
- 0x8F4506/0x8F450E: запись vector constant в destination +0x11C/+0x124.

Факт: на пути нормального возврата callback вызывается до очистки. При исключении callback последующая очистка данным листингом не гарантируется. Риск/гипотеза: callback может реентерабельно поставить новую цель, которая затем будет затёрта текущим завершением; наличие такой реентерабельности в runtime не доказано. Нельзя незаметно переставлять очистку до callback под видом оптимизации.

## Ещё не доказано
Все callback implementations, exception paths/действия сторонних hooks, полный SetDestination retry contract, native getter side effects. Между двумя distance checks нет явного перемещения в листинге, но этого недостаточно для гарантированной equivalence. Безопасная работа сейчас: формальный контракт, не мод.
''')
put('REVERSE_ENGINEERING/PATH_CACHE_OWNERSHIP.md','''# NPCPathCache: владение и открытые вопросы

[AddPath 0x8FB4A0](../EVIDENCE/current/native/8FB4A0.asm.txt), [GetPath 0x8FB5B0](../EVIDENCE/current/native/8FB5B0.asm.txt), [phase2 agent.path](../EVIDENCE/phase2/evidence/helper_2B1F000.asm.txt), [corners](../EVIDENCE/phase2/evidence/helper_2B20BF0.asm.txt).

Подтверждено: PathCache entry Start +0x10, End +0x1C, Path +0x28. AddPath выделяет entry, сохраняет переданный path reference и добавляет в list; GetPath возвращает reference первого подходящего entry. Start/end squared distance должны быть строго меньше переданного порога; переданный float в теле не возводится в квадрат. Не менять его единицы по имени параметра.

NavMeshAgent.path создаёт отдельный NavMeshPath с native handle. Corners array lazily cached per object. Путь может удерживаться NPCMovement и PathCache, поэтому return-to-pool/dispose при локальном завершении нельзя считать безопасным.

Нет eviction/Dispose в двух рассмотренных методах. Это НЕ доказанная утечка. Открыты: все изменения Paths, scene/NPC destruction, общий доступ нескольких consumers, actual native path lifetime и моды. LoadManager.CleanUp → NavMeshUtility.ClearCache не доказывает очистку NPCPathCache, это другой символ.

Следующий offline шаг: проследить SetDestination_8F8110, UpdateCache и FixedUpdate retained writes; составить ownership table. Следующий data request: все прямые/indirect callers и field writers Paths, native NavMeshPath destruction path. Ничего не внедрять до завершения.''')
put('MODDING_API.md','''# Modding API и IL2CPP ограничения

[Проверенная interop поверхность](EVIDENCE/current/interop-selected-api.json) содержит public methods/properties/fields выбранных типов и путь proxy assembly. [Managed assembly index](EVIDENCE/current/managed-interop-assembly-index.json) содержит refs/MVID/versions/hash.

MelonLoader является сторонним загрузчиком. Прокси передают вызов в native IL2CPP; изменение IL proxy не переписывает машинное тело GameAssembly. Обычный Harmony IL transpiler не является универсальным решением. IL2CPP-aware managed hooks могут использовать native detour внутри реализации. Совместимость конкретных hooks и loader runtime здесь не испытана.

Гейты будущего мода: game/metadata hashes, signatures, loader/interop compatibility, existing patches, thread/lifecycle constraints. Предпочтительные VA не использовать как runtime addresses. Unity object/API обычно требуют main thread; не переносить Unity calls в Task ради ускорения.

Prefix/Postfix не удаляет середину native UpdateDestination. Inline работа FixedUpdate не исчезает от hook отдельного helper. Полная замена FixedUpdate опасна и не нужна для узкого duplicate.

[Declared patches](EVIDENCE/current/mod-declared-targets.json), [raw attributes](EVIDENCE/current/mod-patch-attributes.json), [overlap](EVIDENCE/current/mod-target-overlaps.json). Dynamic reflection targets и реальный order не разрешены. PackagerConfiguration.ShouldSave overlap нужно рассматривать с обеими реализациями, а не объявлять конфликтом.

В пакет не включён готовый оптимизационный мод. Старые apply/rollback профили не включены и не запускались.''')
put('GLOSSARY.md','''# Терминология

- IL2CPP: AOT преобразование управляемого кода в native implementation.
- Cpp2IL stubs: восстановленный metadata/API outline, не гарантированные тела исходника.
- Interop proxy: managed wrapper для native IL2CPP объекта/метода.
- RVA: адрес относительно загруженного PE image base.
- File offset: позиция bytes в исходном PE, определяется section mapping.
- Preferred VA: preferred image base + RVA; ASLR меняет реальную базу процесса.
- Alias/generic sharing: разные методы/инстанциации могут иметь общие machine bytes.
- Call site: статическое место инструкции, не измеренное число вызовов.
- CFG: граф базовых блоков и переходов управления; текущие graphs не полный CFG.
- Unwind span: range из PE exception metadata; не всегда весь исходный метод.
- PPtr: сериализованная ссылка по file ID/path ID.
- Type tree: описание сериализованного layout; в девяти исследованных файлах отсутствует.
- .resS/.resource: внешние payloads ресурсов; размер не равен resident memory.
- GC allocation: managed heap allocation; Vector3 на стеке сам по себе не GC allocation.
- Native handle: ресурс движка, lifetime которого не равен lifetime одной managed ссылки.
- Staggering: распределение callbacks во времени; не обязательно уменьшение их общего количества.
- p99 frametime: 99-й процентиль времени кадра; 1000/p99 не средний FPS худшего 1%.
- CONFIRMED_STATIC / HISTORICAL / HYPOTHESIS / UNKNOWN: уровни evidence данного пакета.''')
put('RISKS.md','''# Риски

1. Бинарная версия: RVA/offset переносимы только при matching hashes. Хэши и metadata обязательны.
2. Native aliasing/inlining/indirect calls: автоматические labels могут вводить в заблуждение.
3. NPC callbacks: EndSetDestination вызывает callback до очистки; изменение порядка меняет семантику.
4. Path lifetime: retained reference запрещает преждевременный pooling/dispose.
5. Host/client и physics: пропуск fixed ticks меняет поведение, RNG, ragdoll, движение.
6. Animator culling: уже установленный S1Perf воздействует на offscreen bones; root motion/events/IK не проверены runtime.
7. Resources: versioned layout, references и streaming flags не восстановлены полностью; перепаковка небезопасна.
8. Mod overlap: ShouldSave влияет на сохранение employee configuration. Два declared targets не равны доказанному конфликту.
9. Measurement: размеры файлов, число методов и call sites не стоимость. Нельзя обещать FPS.
10. Exposure: пакет содержит имена файлов/типов, локальные пути и reverse-engineering snippets. Не включает saves, полные логи, API credentials или игровые binaries. Перед публичным распространением проверить права на derived материалы.
11. Tool failures: при сборке вспомогательные чтения требовали UTF-8; extension потребовал local assembly resolver. Исправлено, финальные outputs проверяются отдельно. Незавершённые Astar decodes явно оставлены в coverage.
12. Старые REPORT/README являются историческим контекстом: команды apply/rollback и отсутствующие из пакета profiles не инструкции к выполнению. Текущий handoff имеет приоритет для безопасного продолжения.''')
put('OPEN_QUESTIONS.md','''# Открытые вопросы и узкие запросы данных

- Callback reentrancy: все consumers EndSetDestination callback и exceptions; закрыть formal contract перед implementation.
- Path ownership: все readers/writers Paths, destruction и invalidation; нет доказанного memory leak.
- Два Astar MoveNext с INVALID: определить корректные PE boundaries/control flow, не выполнять их. Это не блокирует существующее NPCMovement evidence.
- Generic delegate constructors: representative labels не являются доказательством runtime типа. Нужна metadata usage/type resolution.
- Render pipeline asset: расшифровать GraphicsSettings/QualitySettings и references; URP assembly alone недостаточна.
- Texture formats/mips/compression/streaming и native Unity setter cost: не извлечены.
- Полный AI/physics/Animator/IK/Burst graph: текущий выбранный scope не исчерпывающий.
- Dynamic Harmony targets/patch order и семантика ShouldSave prefix/postfix: статическое пересечение есть, конфликт не доказан.
- Активные NPC/lights/plants, CPU/GPU/GC/frametime и branch frequency: требуют отдельно разрешённого runtime, нельзя вывести offline.

## Формат DATA_REQUEST
Указать вопрос, оригинальный относительный путь, SHA-256 из inventory, method signature/RVA/range либо container/path_id/offset, read-only способ извлечения, ожидаемый небольшой формат и критерий проверки. Не просить всю игру или постоянный Custom MCP.

## Первая offline задача
Сформулировать тестовые обязательства для UpdateDestination на основе уже включённых листингов. Не писать мод, пока user отдельно не согласует разработку.''')
put('OPTIMIZATION_OPPORTUNITIES.md','''# Возможности: исследовательские, не измеренные ускорения

| Направление | Evidence | Следующий шаг | Риск |
|---|---|---|---|
| Duplicate distance в UpdateDestination | Два native distance sites в конечной ветви | Callback/float/retry proof; затем отдельное разрешение на narrow change | Высокий |
| ScheduleRu canvas scan cadence | Установленный IL + interval=0 | Измерить один canvas scan, задержки текста, baseline | Средний |
| ScheduleRu diagnostic append | DumpUntranslated и AppendAllText | Измерить редкость/стоимость, согласовать потерю диагностик | Низкий/средний |
| Texture budget | Конфигурация 8000 MB, historical 4 GB GPU | CPU/GPU/texture counters, один контролируемый эксперимент | Качество/подгрузки |
| Path-cache access/ownership | Retained reference, linear matching | Все owners/writers и cache frequency | Высокий |
| Plant light recomputation | Grid/LightExposureNode loop | Invalidation/event map; не менять рост | Высокий |
| Coroutine temporary objects | Allocation helper в отдельных branches | Runtime frequency и lifetime; generic type resolve | Средний/высокий |
| Dynamic mod interaction | ShouldSave declared overlap | Проверить semantics обеих реализаций | Сохранения |

## Не считать новой оптимизацией
Avoidance 2 Hz/random staggering уже есть. Ring buffer/path cache/Burst Average уже есть. Animator hash cache уже есть. Shadow setter dedup и distance LOD уже есть. ActionList staggered callbacks уже есть.

Не делать blanket FixedUpdate throttling, GC.Collect/GC disable, global shader warmup, новые allocator budgets, PhysX toggles, root-motion culling или resource repack без доказательств и согласования.''')
# Per subsystem actual signature/field maps and scoped graphs
for slug,title,types,facts,opportunity,risk in SUBSYSTEMS:
 selected=[m for m in methods if any(m['Type']==t or m['Type'].startswith(t+'/') for t in types)]
 graphrows=[x for x in scans if any(t+'::' in x['Signature'] or t+'/' in x['Signature'] for t in types)]
 lines=[f'# {title}','', '## Scope и подтверждённые наблюдения',facts,'','## Возможности, пока гипотезы',opportunity,'','## Риски и неизвестное',risk,'','## Адресуемые методы','| Метод | RVA | Offset | Cpp2IL bytes |','|---|---|---|---|']
 for m in selected:lines.append('| '+m['Signature'].replace('|','\\|')+f" | 0x{m['RVA']:X} | 0x{m['Offset']:X} | {m['Length']} |")
 lines+=['','Полные поля и offsets: [selected-types-fields](../EVIDENCE/current/selected-types-fields.json). Public proxy API: [interop-selected-api](../EVIDENCE/current/interop-selected-api.json).','', '## Сохранённые native roots']
 for x in graphrows:lines.append(f"- [{x['Signature']}](../EVIDENCE/current/{x['File']})"+(' **INVALID: неполный range**' if x['Invalid'] else ''))
 lines+=['','[Native edge records](../EVIDENCE/current/native-edges.json). [Правила aliasing и scope](../REVERSE_ENGINEERING/EVIDENCE_RULES.md). [Исторический NPC report](../EVIDENCE/phase2/REPORT.ru.md). [Mod call sites](../EVIDENCE/current/mod-call-sites.json).']
 put('SUBSYSTEMS/'+slug+'.md','\n'.join(lines))
 rvas={x['RVA'] for x in graphrows};es=[x for x in edges if x['FromRVA'] in rvas];jput('CALL_GRAPHS/'+slug+'.json',es)
 dot=['digraph G {','  rankdir=LR;']
 for x in es:
  src=f"r{x['FromRVA']:X}";site=f"0x{x['SiteRVA']:X}";dst=f"r{x['TargetRVA']:X}" if 'TargetRVA' in x else f"indirect{x['SiteRVA']:X}";dot.append(f'  "{src}" -> "{dst}" [label="{site} {x["Kind"]}"];')
 dot.append('}');put('CALL_GRAPHS/'+slug+'.dot','\n'.join(dot))
put('CALL_GRAPHS/README.md','''# Graph scope

DOT files use RVA nodes and source instruction-site labels. JSON contains signatures and up to eight representative aliases plus AliasCount. Empty graphs mean no selected native root for that category, not no work. Mod-specific relations live in mod-call-sites.json and mod-target-overlaps.json. Asset graph contains container references, not every PPtr.

NPC previous graph: [CALL_GRAPH.md](../EVIDENCE/phase2/CALL_GRAPH.md), [CALL_GRAPH.dot](../EVIDENCE/phase2/CALL_GRAPH.dot). Indirect calls are explicit unresolved nodes. Runtime order/frequency cannot be inferred from graph size.''')
dot=['digraph Assets {']
for a in assets:
 for x in a['external_references']:dot.append('  '+json.dumps(a['container'])+' -> '+json.dumps(x['path'])+' [label="fileID '+str(x['file_id'])+'"];')
dot.append('}');put('CALL_GRAPHS/ASSET_DEPENDENCIES.dot','\n'.join(dot))
# Addressable findings with validation needles
findings=[
('F01','EndSetDestination invokes callback before clearing callback/destination state','EVIDENCE/phase2/evidence/EndSetDestination_8F4490.asm.txt',['008F44B2','008F44BC','008F44CE']),
('F02','AvatarAnimationId has cache-hit return; StringToHash is on miss path','EVIDENCE/current/native/7C51B0.asm.txt',['007C5248','007C5279','007C52AC']),
('F03','ShadowLODController skips setter loop when applied mode matches','EVIDENCE/current/native/723040.asm.txt',['0072318A','0072318D','007231BC']),
('F04','TimeManager tick coroutine directly calls staggered ActionList','EVIDENCE/current/native/9CE410.asm.txt',['ActionList::InvokeAllStaggered']),
('F05','AddPath stores input path pointer in entry','EVIDENCE/current/native/8FB4A0.asm.txt',['008FB524 mov [rdi+28h],rsi']),
('F06','GetPath returns retained path reference from matching entry','EVIDENCE/current/native/8FB5B0.asm.txt',['008FB6F7','008FB70A']),
('F07','GrowContainer light loop uses Grid and LightExposureNode','EVIDENCE/current/native/7E4BB0.asm.txt',['Grid::GetTile','LightExposureNode::GetTotalExposure']),
('F08','Two installed mods declare PackagerConfiguration.ShouldSave targets','EVIDENCE/current/mod-target-overlaps.json',['Schedule1BetterEmployees','WagesManager','ShouldSave']),
('F09','LoadManager load routine has LoadSceneAsync call','EVIDENCE/current/native/590A80.asm.txt',['SceneManager::LoadSceneAsync']),
('F10','PhysicsManager gravity RPC writes Physics.gravity','EVIDENCE/current/native/58B420.asm.txt',['Physics::set_gravity']),
('F11','NPC animation routes local velocity to SetMotion and animation parameters','EVIDENCE/current/native/8E9870.asm.txt',['InverseTransformVector','AvatarAnimation::SetMotion','AvatarAnimation::SetBool']),
('F12','Container dependency table includes level1 sharedassets links','EVIDENCE/current/asset-containers-current.json',['level1','sharedassets1.assets'])]
jput('REVERSE_ENGINEERING/claims.json',[{'id':i,'status':'CONFIRMED_STATIC','claim':c,'file':f,'needles':n} for i,c,f,n in findings])
put('REVERSE_ENGINEERING/FINDINGS.md','# Подтверждённые статические находки\n\n'+'\n\n'.join(f'## {i}: {c}\n\n[Evidence](../{f}). Статический вывод ограничен приведённым методом/таблицей; runtime frequency и ускорение не измерены.' for i,c,f,n in findings)+'\n\nПредыдущие подтверждённые NPC результаты сохранены в [phase2 report](../EVIDENCE/phase2/REPORT.ru.md). Старые claims не объявляются новыми.')
put('REVERSE_ENGINEERING/REPRODUCTION.md','''# Воспроизводимость

## Offline, без игры/MCP
Python 3.11+ standard library. Из корня пакета:
```
python ANALYZERS/offline_query.py verify .
python ANALYZERS/offline_query.py methods NPCMovement
python ANALYZERS/offline_query.py calls GetAverageLightExposure
python ANALYZERS/offline_query.py mods PackagerConfiguration
```
Все документы/JSON/CSV/DOT читаются и без запуска Python. Не требуется .NET или установка tooling для offline reasoning.

## Новый статический native extract, только у владельца игры
Требуются уже имеющиеся .NET 8 SDK, Mono.Cecil и Iced из MelonLoader/net6, Cpp2IL outputs указанной сборки и GameAssembly. Никакая зависимость в пакет не скопирована. Версии/hashes в assembly index. Это не запускает игру.
```
dotnet build ANALYZERS/native-index/Analyzer.csproj -c Release -p:GameRoot="B:\\Schedule I" --ignore-failed-sources
dotnet ANALYZERS/native-index/bin/Release/net8.0/Analyzer.dll "B:\\Schedule I" "EVIDENCE/phase2/evidence/methods-all.json" "C:\\Temp\\ScheduleI-new-static-evidence"
```
Output обязан быть вне game root. Использовать новую пустую папку: analyser skips existing listing files, поэтому нельзя подменять game version и оставлять старые listing files. Перед запуском сверить fingerprints, не переносить старый method index на другую сборку.

## Asset extension
ANALYZERS/asset_links.py имеет явный локальный game path и лабораторный output. Для нового компьютера перенести copy в отдельную lab, изменить только input/output paths. Парсер read-only, v22 only; не считать candidate name schema validated.

## Архивные анализаторы
EVIDENCE/phase2/analyzer и его scripts сохранены как исторические исходники. Они имеют hardcoded paths/output и могут перезаписать evidence: не запускать прямо внутри пакета. ANALYZERS/archive/static_inventory.py зависит от старого s1lab и не standalone; включён для аудита старого алгоритма, а не как команда к исполнению. Новый offline_query standalone.

Сборщики baseline/checkpoint/build_package фиксируют происхождение текущей поставки, рассчитаны на исходную lab layout и не нужны получателю для продолжения. Полные game binaries/dependencies не включены. Не объявлять сам пакет воспроизводимой сборкой игры.''')
put('ANALYZERS/README.md','''# Анализаторы

- offline_query.py: полностью автономный read-only поиск и manifest verification; только standard library.
- native-index/Program.cs и Analyzer.csproj: read-only Cecil/Iced extraction, требует локальные game/dependency files; старые listings не повторяет.
- asset_links.py: bounds-checked v22 object/external reference extension, candidate names heuristic.
- baseline.py / checkpoint_and_review.py / summarize_evidence.py: provenance текущего исследования, исходная lab layout.
- build_package.py / package_content.py: recipe текущего пакета, не обязательны для offline использования.
- archive/static_inventory.py: исторический алгоритм с отсутствующим здесь s1lab dependency, читать как source only.

Не выполнять старые verify/finalize/apply команды из historical README поверх исходного evidence. Текущая независимая проверка: `python ANALYZERS/offline_query.py verify .` из package root.

Ни одного оптимизационного runtime DLL здесь нет.''')
put('EVIDENCE/README.md','''# Происхождение

phase2: прежние файлы без bin/obj, byte-for-byte копии; исходный manifest проверен. prior: исторические отчёты и небольшой установленный mod IL/decompilation. current: новые statically extracted indices/listings. baseline: контрольная точка до упаковки.

Исходные paths в исторических документах объясняют, где проводилась работа; они не являются переносимыми ссылками. Текущие relative Markdown links проверяются QA. Все новые claims указывают portable evidence. Не интерпретировать числа historical logs как текущий runtime.

Полный original-file hash inventory включает только путь/размер/hash, не содержимое. Saves исключены. Реальные executable DLLs, textures/audio и full logs не включены.''')
# Flatten selected fields and methods for small spreadsheet-friendly data
with (P/'REVERSE_ENGINEERING/METHOD_MAP.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=['Assembly','Type','Name','Signature','RVA','Offset','Length']);w.writeheader();w.writerows(methods)
with (P/'REVERSE_ENGINEERING/FIELD_MAP.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.writer(f);w.writerow(['Assembly','OwnerType','Field','Type','Static','Offset','Constant'])
 for t in read(E/'selected-types-fields.json'):
  for x in t['Fields']:
   offset=next((v['Value'] for a in x['Attributes'] if a['Type'].endswith('FieldOffsetAttribute') for v in a['Fields'] if v['Name']=='Offset'),'');w.writerow([t['Assembly'],t['Type'],x['Name'],x['Type'],x['IsStatic'],offset,x['Constant']])
put('README.md','''# AI Research Package

[Overview](PROJECT_OVERVIEW.md) • [State](PROJECT_STATE.md) • [Handoff prompt](HANDOFF_PROMPT.md) • [Findings](REVERSE_ENGINEERING/FINDINGS.md) • [Open questions](OPEN_QUESTIONS.md) • [Risks](RISKS.md)

Read documents and included evidence offline. Verify with `python ANALYZERS/offline_query.py verify .`. No MCP, game, network or package installation is needed for that verification/query.

This is a bounded static research package, not the entire game source or a measured performance improvement. Runtime/GPU and unextracted functions require explicitly requested additional evidence.

Full file listing: [CREATED_FILES.txt](CREATED_FILES.txt). Integrity: [FILE_MANIFEST.json](FILE_MANIFEST.json), [QA_REPORT.json](QA_REPORT.json).''')
print('Package created:',P,'files',sum(p.is_file() for p in P.rglob('*')))
