from pathlib import Path
import json,hashlib,collections
R=Path(__file__).parent;L=R.parent;G=Path(r'B:\Schedule I');E=R/'evidence'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
# Hash every inventoried non-save file, streaming. Nothing is copied from saves or logs.
files=read(R/'game-file-inventory.json'); hashed=[]
for x in files:
 p=G/x['path'];before=p.stat();h=sha(p);after=p.stat();hashed.append({**x,'sha256':h,'stable_during_hash':before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns})
(E/'original-files-sha256.json').write_text(json.dumps(hashed,indent=2),encoding='utf-8')
a=read(L/'evidence/audit.json');safe={k:a[k] for k in ['il2cpp_metadata_header','relevant_preferences','boot_diff_against_unverified_local_orig']};(E/'performance-config-evidence.json').write_text(json.dumps(safe,ensure_ascii=False,indent=2),encoding='utf-8')
for name in ['ScriptingAssemblies.json','RuntimeInitializeOnLoads.json']:
 data=read(G/'Schedule I_Data'/name);(E/name).write_text(json.dumps(data,indent=2),encoding='utf-8')
patches=read(E/'mod-patch-attributes.json');owners=collections.defaultdict(list)
for x in patches:
 if x['Attribute']['Type'].endswith('.HarmonyPatch'): owners[(x['Assembly'],x['Owner'])].append(x['Attribute']['Args'])
resolved=[]
for (asm,owner),attrs in owners.items():
 if '::' not in owner:continue
 cls=owner.split('::')[0].split(' ',1)[-1];base=owners.get((asm,cls),[]);args=[z for a in base+attrs for z in a if isinstance(z,str)];types=[z for z in args if z.startswith('Il2Cpp')];names=[z for z in args if z and not z.startswith('Il2Cpp')]
 if types and names:resolved.append({'assembly':asm,'owner':owner,'target_type':types[0],'target_method':names[-1],'precision':'type+method name; overload and dynamic patches require further resolution'})
# class-scoped Harmony targets
for (asm,owner),attrs in owners.items():
 if '::' in owner:continue
 for a in attrs:
  if len(a)>=2 and isinstance(a[0],str) and a[0].startswith('Il2Cpp'):resolved.append({'assembly':asm,'owner':owner,'target_type':a[0],'target_method':a[1],'precision':'class target; exact patch method/order not established'})
groups=collections.defaultdict(list)
for x in resolved:groups[(x['target_type'],x['target_method'])].append(x)
overlaps=[{'type':k[0],'method':k[1],'records':v,'status':'overlapping static declared targets, NOT proven runtime conflict'} for k,v in groups.items() if len({x['assembly'] for x in v})>1]
(E/'mod-declared-targets.json').write_text(json.dumps(resolved,indent=2),encoding='utf-8');(E/'mod-target-overlaps.json').write_text(json.dumps(overlaps,indent=2),encoding='utf-8')
fields=read(E/'selected-types-fields.json'); wanted=['ScheduleOne.AvatarFramework.Animation.AvatarAnimationId','ScheduleOne.Lighting.ShadowLODController','ScheduleOne.NPCs.NPCMovement','ScheduleOne.NPCs.NPCPathCache/PathCache','ActionList']
text=['OVERLAPS '+json.dumps(overlaps),'CONFIG '+json.dumps(safe,ensure_ascii=False)]
for t in fields:
 if t['Type'] in wanted:text.append(json.dumps(t,ensure_ascii=False))
containers=read(E/'asset-containers-current.json');text.append('ASSET REFS '+json.dumps([{k:c[k] for k in ['container','objects','external_references']} for c in containers]))
(R/'focused-review.txt').write_text('\n'.join(text),encoding='utf-8')
summary=read(E/'summary.json');summary['stage']='Static inventory and bounded subsystem evidence saved; packaging and QA pending';summary['original_files_hashed']=len(hashed);summary['runtime_profiled']=False;summary['limitations']=['Not full game reverse engineering','Two Astar iterator ranges stop on invalid decode','No active scene/component counts','No GPU workload measurement','No full indirect graph','No original texture payloads decoded'];(R/'PROJECT_STATE.phase3.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))
