from pathlib import Path
import json,hashlib,shutil,zipfile,subprocess,sys,datetime,re
from urllib.parse import unquote
R=Path(__file__).parent;L=R.parent;P=L/'EXPORT/AI_RESEARCH_PACKAGE';G=Path(r'B:\Schedule I');X=L/'EXPORT';Z=X/'AI_RESEARCH_PACKAGE_20261116.zip'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if Z.exists():raise SystemExit('Refusing to overwrite existing archive')
qa=read(P/'QA_REPORT.json');assert qa['status']=='PASS'
# Rehash inventoried originals; exclude saves exactly as initial inventory did.
original=read(P/'EVIDENCE/current/original-files-sha256.json');changes=[]
for x in original:
 p=G/x['path']
 if not p.exists() or p.stat().st_size!=x['bytes'] or sha(p)!=x['sha256']:changes.append(x['path'])
assert not changes, 'Original non-save file changes: '+repr(changes)
qa['checks']['original_non_save_files_rehashed_unchanged']=len(original)
qa['checks']['independent_review']='Read-only review; normal-return callback, path request wording and helper evidence clarified. See REVERSE_ENGINEERING/INDEPENDENT_REVIEW.md.'
qa['checks']['runtime']='Not run; no FPS/CPU/GPU/GC measurement'
save(P/'QA_REPORT.json',qa)
shutil.copy2(Path(__file__),P/'ANALYZERS/finalize_package.py')
# Checkpoint document is new, preserves existing root PROJECT_STATE.md.
checkpoint={'state':'Research package assembled and QA passed; archive verification follows','date':datetime.datetime.now().astimezone().isoformat(),'package':str(P),'original_files_unchanged':len(original),'runtime_profiled':False,'existing_research_preserved':True}
save(R/'FINAL_CHECKPOINT.json',checkpoint)
# File list includes generated manifest/list itself; manifest excludes itself to avoid recursion.
paths=sorted({p.relative_to(P).as_posix() for p in P.rglob('*') if p.is_file()}|{'CREATED_FILES.txt','FILE_MANIFEST.json'})
(P/'CREATED_FILES.txt').write_text('\n'.join(paths)+'\n',encoding='utf-8')
manifest=[{'path':p.relative_to(P).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(P.rglob('*')) if p.is_file() and p.name!='FILE_MANIFEST.json'];save(P/'FILE_MANIFEST.json',manifest)
# Final link check with no future-file allowances.
link_count=0
for p in P.rglob('*.md'):
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8-sig')):
  target=unquote(target.strip().strip('<>')).split('#')[0]
  if not target or re.match(r'^[a-zA-Z]+://',target):continue
  q=(p.parent/target).resolve();assert q.exists() and q.is_relative_to(P.resolve()),(p,target);link_count+=1
verify=subprocess.run([sys.executable,str(P/'ANALYZERS/offline_query.py'),'verify',str(P)],capture_output=True,text=True,encoding='utf-8');assert verify.returncode==0,verify.stdout+verify.stderr
with zipfile.ZipFile(Z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(P.rglob('*')):
  if p.is_file():z.write(p,'AI_RESEARCH_PACKAGE/'+p.relative_to(P).as_posix())
with zipfile.ZipFile(Z) as z:assert z.testzip() is None;entries=len(z.infolist())
# Independent relocated offline smoke test, preserved for audit, never touches game.
relocated=R/'offline-smoke-test';assert not relocated.exists();relocated.mkdir()
with zipfile.ZipFile(Z) as z:z.extractall(relocated)
Q=relocated/'AI_RESEARCH_PACKAGE';tests=[]
for args in [['verify',str(Q)],['methods','AvatarAnimationId'],['calls','GetAverageLightExposure'],['mods','PackagerConfiguration']]:
 p=subprocess.run([sys.executable,str(Q/'ANALYZERS/offline_query.py'),*args],cwd=relocated,capture_output=True,text=True,encoding='utf-8',errors='replace');assert p.returncode==0,p.stderr;tests.append({'command':args[0],'exit_code':p.returncode,'stdout_tail':p.stdout[-1000:]})
archive_hash=sha(Z);(X/(Z.name+'.sha256')).write_text(archive_hash+'  '+Z.name+'\n',encoding='ascii')
shutil.copy2(P/'HANDOFF_PROMPT.md',X/'HANDOFF_PROMPT.md')
files=[p for p in P.rglob('*') if p.is_file()]
result={'status':'VERIFIED','package_path':str(P),'archive_path':str(Z),'package_files':len(files),'package_bytes':sum(p.stat().st_size for p in files),'archive_bytes':Z.stat().st_size,'archive_sha256':archive_hash,'archive_entries':entries,'zip_crc':'PASS','final_internal_links':link_count,'manifest_entries':len(manifest),'original_non_save_files_unchanged':len(original),'offline_relocated_tests':tests,'handoff_path':str(P/'HANDOFF_PROMPT.md'),'standalone_handoff_path':str(X/'HANDOFF_PROMPT.md'),'full_created_file_list':str(P/'CREATED_FILES.txt'),'bounded_scope':'89 new selected native ranges, 2 incomplete; prior NPC research reused; no runtime profiling or full game source recovery'}
save(X/'DELIVERY.json',result);save(R/'FINAL_CHECKPOINT.json',result)
summary=f'''# Phase 3: AI handoff completed\n\nPackage: `{P}`\nArchive: `{Z}`\nFiles: {len(files)}\nUncompressed bytes: {result['package_bytes']}\nZIP bytes: {result['archive_bytes']}\nSHA-256: `{archive_hash}`\n\nVerified {len(original)} non-save original-file hashes unchanged, {link_count} internal links, ZIP CRC and relocated offline query/manifest tests. No game launch, game edits, saves access or optimization mod implementation. Prior root PROJECT_STATE.md left intact. Latest continuation: EXPORT/AI_RESEARCH_PACKAGE/PROJECT_STATE.md and HANDOFF_PROMPT.md.\n\nScope is bounded static analysis, not full reverse engineering or measured performance gain. Two Astar decodes incomplete, active GPU workload and indirect graphs remain unknown.\n'''
(L/'PROJECT_STATE.phase3-handoff.md').write_text(summary,encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='offline_relocated_tests'},ensure_ascii=True,indent=2))
