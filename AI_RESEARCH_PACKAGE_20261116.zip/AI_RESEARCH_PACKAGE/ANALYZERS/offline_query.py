"""Offline research query/verification. Python 3.11+, standard library only; no game/MCP/network."""
from pathlib import Path
import sys,json,hashlib
R=Path(__file__).resolve().parents[1]
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def main():
 global R
 cmd=sys.argv[1] if len(sys.argv)>1 else 'help';q=sys.argv[2] if len(sys.argv)>2 else ''
 if cmd=='verify':
  if q:R=Path(q).resolve()
  failures=[];manifest=read(R/'FILE_MANIFEST.json')
  for row in manifest:
   p=(R/row['path']).resolve()
   if not p.is_relative_to(R) or not p.is_file() or p.stat().st_size!=row['bytes'] or digest(p)!=row['sha256']:failures.append(row['path'])
  print(json.dumps({'verified_entries':len(manifest),'failures':failures,'note':'Manifest excludes itself. Archive SHA256 is supplied separately. Checks integrity, not truth of claims.'},indent=2));return bool(failures)
 if cmd=='methods': paths=['EVIDENCE/phase2/evidence/methods-all.json']
 elif cmd=='calls':paths=['EVIDENCE/current/native-edges.json','EVIDENCE/phase2/evidence/npc-outgoing.json','EVIDENCE/phase2/evidence/npc-incoming.json']
 elif cmd=='mods':paths=['EVIDENCE/current/mod-call-sites.json','EVIDENCE/current/mod-declared-targets.json','EVIDENCE/current/mod-target-overlaps.json']
 else:print('Commands: verify [package-root], methods <keyword>, calls <keyword>, mods <keyword>. First 100 matches shown; total reported.');return 0
 count=0
 for rel in paths:
  for x in read(R/rel):
   if q.casefold() in json.dumps(x,ensure_ascii=False).casefold():
    count+=1
    if count<=100:print(json.dumps({'source':rel,'record':x},ensure_ascii=True))
 print('MATCHES',count,'SHOWN',min(count,100));return 0
if __name__=='__main__':sys.exit(main())
