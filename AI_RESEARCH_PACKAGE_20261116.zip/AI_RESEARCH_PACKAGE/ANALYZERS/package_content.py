"""Curated research conclusions. No runtime or optimization implementation claims."""
SUBSYSTEMS=[
('01-NPC-AI','NPC и AI',['ScheduleOne.NPCs.NPC','ScheduleOne.NPCs.NPCManager','ScheduleOne.NPCs.NPCScheduleManager','ScheduleOne.NPCs.NPCAwareness'],
'''Подтверждено предыдущим native evidence: NPCMovement.FixedUpdate серверный; Update обрабатывает вход на лестницу, а не основной obstacle solver. UpdateDestination использует guards движения, pending path, CanMove, ladder и ветку повторного SetDestination. Новая проверка EndSetDestination: на пути нормального возврата callback вызывается ДО очистки callback и _hasDestination; это создаёт обязательство сохранить порядок и возможную реентерабельность.
Новый индекс: NPC.Start/OnDestroy регистрирует и снимает ActionList callbacks и регистрацию weather entity. NPCScheduleManager.Start взаимодействует с TimeManager и UnityEvent. Полный список подписчиков и косвенный вызов Update пока не разрешены.''',
'Устранение второго вычисления distance в конечной ветви UpdateDestination, только после доказательства эквивалентности callback и float semantics. Не замедлять весь FixedUpdate.',
'Поведение host/client, RNG, ladder/ragdoll, callback reentrancy. Реальная частота дорогой ветви неизвестна.'),
('02-PATHFINDING','Pathfinding и obstacle avoidance',['ScheduleOne.NPCs.NPCPathCache','UnityEngine.AI.NavMeshPath','UnityEngine.AI.NavMeshAgent','AstarPath','Pathfinding.Seeker','Pathfinding.AIPath'],
'''Подтверждено phase2: avoidance уже InvokeRepeating 0.5 s с random initial delay 0..0.5 s; сравнение distanceSquared <=625 с ближайшим Player Avatar.CenterPoint. Это не raycast loop. SetObstacleAvoidanceEnabled содержит inline policy, OnStartClient также writer.
NPCPathCache.AddPath сохраняет переданную ссылку NavMeshPath в entry +0x28, не копирует путь на исследованном прямом пути. GetPath возвращает ту же ссылку из первого подходящего entry; start/end сравниваются квадратами расстояний со строгим порогом. В этих двух методах нет eviction/Dispose, но это НЕ доказывает утечку: другие владельцы и lifecycle не полностью исследованы.
AstarPath.Update содержит NavmeshUpdates.Update, TickNonMultithreaded и ReturnPaths. Наличие этой реализации не доказывает, что NPCMovement использует Astar: его прямой backend Unity NavMesh. Два Astar iterator ranges имеют INVALID и считаются неполными.''',
'Сначала аудит владения кэшем и writers. Условная дедупликация avoidance setter требует проверки внутренних Unity setters и всех writer paths.',
'Retained native handles, устаревшие пути, отключение агента, server/client, no-player distance=0. Pooling пока небезопасен.'),
('03-PHYSICS','Physics и взаимодействия',['ScheduleOne.GamePhysics.PhysicsManager','ScheduleOne.AvatarFramework.Ragdoll','ScheduleOne.Combat.PhysicsDamageable'],
'''PhysicsManager.RpcLogic___SetGravityMultiplier вызывает UnityEngine.Physics.set_gravity. Ragdoll.SetGravityMultiplier читает Rigidbody.mass и Physics.gravity, записывает ConstantForce.force. Следовательно, эти параметры несут игровую семантику, а не только настройки производительности.
Phase2 покрывает NPC collision callbacks, ragdoll recovery и NavMeshAgent.Move; прямого Raycast/Overlap loop в трёх исходных NPC roots нет. Установленный S1Perf.ApplyGlobal условно включает Physics.reuseCollisionCallbacks, что уже является существующим изменением поведения объекта Collision.
Глубина: выборочные native roots, не полный PhysX solver и не карта всех контактов.''',
'Исследовать lifetime Collision у потребителей перед любым расширением reuse; фиксировать контактные counters только при отдельно разрешённом runtime.',
'Нельзя менять fixed timestep, gravity, autoSyncTransforms или collision reuse вслепую. Ссылки Collision могут сохраняться обработчиками.'),
('04-RENDERING','Rendering и GPU workload',['ScheduleOne.Lighting.ShadowLODController','ScheduleOne.Avatar.Impostors.AvatarImpostor','ScheduleOne.AvatarFramework.AvatarLODBoundsUpdater','ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager','ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject'],
'''Новый подтверждённый механизм: ShadowLODController регистрирует movement event камеры. UpdateShadows вычисляет squared distance, выбирает soft/hard/none, затем сравнивает _appliedShadowsMode (+0x40). При совпадении setter loop не выполняется. Дедупликация shadow setters уже реализована.
OcclusionManager.Update в experimental namespace вызывает GetObjectVisiblityState, WorldPositionToOcclusionIndex и OcclusionObject.SetActive. Это наличие кода, НЕ доказательство активного компонента в level1.
URP и AmplifyImpostors присутствуют в assembly metadata. Активный pipeline asset, render passes, shader variants, draw calls, GPU time и resident VRAM не декодированы/не измерены. Исторический D3D11/3965 MB и BC6H fallback из phase1 помечены историческими, не текущими измерениями.''',
'Сначала установить активные renderer/volume/light assets. Не предлагать существующие LOD/dedup как новые. Texture budget 8000 MB требует измерения всей GPU памяти, не только texture counters.',
'Качество теней, pop-in, visual parity, ложное отождествление serialized object counts с активной GPU нагрузкой.'),
('05-MEMORY','Memory management и allocations',['ScheduleOne.DevUtilities.ObjectPool`1','ScheduleOne.Cartel.GoonPool','ScheduleOne.NPCs.NPCPathCache','ActionList'],
'''Phase2: NativeArray CircularQueue.Enqueue не выделяет heap на исследованном пути; agent.path создаёт новый NavMeshPath, corners кэшируется на конкретном path object. Ladder allocation условная при переходе, не каждый Update.
Новые roots ObjectPool.Get/Return показывают существующий generic pool API, не его все call sites. GoonPool.Update совпадает с общим ret RVA 0x43FEC0 и не является горячей работой.
TimeManager tick coroutine содержит allocation helper и WaitForSecondsRealtime path; ActionList имеет собственную staggered routine. Типы некоторых generic shared constructors не следует угадывать по единственному символу адреса.
Увеличенные native allocator blocks в boot.config и GC time slice известны как конфигурация. Их польза, peak/fallback и GC bytes/sec неизвестны.''',
'Предварительная исследовательская возможность: уменьшать ненужные временные объекты только после аудита lifetime и branch frequency. Pooling NavMeshPath пока не обоснован.',
'Native/managed ownership, shared handles, mutation, GC timing, ложный вывод по размеру файла или аллокациям на редкой ветви.'),
('06-ASSET-LOADING','Asset loading и resource management',['ScheduleOne.Persistence.LoadManager'],
'''LoadManager StartGame coroutine содержит SceneManager.LoadSceneAsync и проверку AsyncOperation.isDone, LoadRequest и UnityEvent callbacks. CleanUp вызывает GUIDManager.Clear и NavMeshUtility.ClearCache. Это не доказательство очистки именно NPCPathCache.
Новый SerializedFile v22 extension прочитал external references девяти контейнеров: 39 записей. level1 ссылается на globalgamemanagers.assets, resources.assets, sharedassets1.assets и sharedassets0.assets плюс built-in resource. Добавлен object index с path_id, class_id, file offset и serialized byte size. Candidate names эвристические, не schema-verified.
Texture mip flags, compression formats, meshes, shader bytecode, full PPtr graph, remote Addressables и resource lifetime полностью не восстановлены. Содержимое сохранений не читалось.''',
'Продолжить versioned schema decoding адресуемых объектов, сначала GraphicsSettings/QualitySettings и texture headers. Оптимизация загрузки без layout и invalidation proof преждевременна.',
'Повреждение ресурсов, reference IDs, built-in virtual paths, зависимость от точной Unity версии, загрузка не равна одновременной резидентности.'),
('07-WORLD-SIMULATION','World simulation и игровые объекты',['ScheduleOne.GameTime.TimeManager','ActionList','ScheduleOne.Growing.Plant','ScheduleOne.Growing.GrowContainer'],
'''TimeManager.TickLoop.MoveNext содержит прямой вызов ActionList.InvokeAllStaggered. В игре уже есть инфраструктура распределения событий; не следует объявлять всякую симуляцию синхронной или предлагать staggering как отсутствующую систему.
Plant.MinPass вызывает GrowContainer.GetAverageLightExposure и moisture getter. GetAverageLightExposure обходит список координат, получает Grid.GetTile и LightExposureNode.GetTotalExposure, суммирует и делит на количество; альтернативная ветвь возвращает поле другого объекта. Интерпретация этого поля требует дальнейшего layout audit.
Это вычисление игровой освещённости растений, не замер GPU lighting. Частота подписки каждого Plant и масштаб активных объектов не определены.''',
'Кэширование освещённости только с полной картой инвалидаторов: свет, тайлы, перемещение и конфигурация. Исследовать event subscriptions, не уменьшать скорость роста.',
'Изменение игровой экономики, порядка событий, света, точности float и времени. Наличие метода MinPass не доказывает единственный caller.'),
('08-ANIMATION','Animation и Animator',['ScheduleOne.NPCs.NPCAnimation','ScheduleOne.AvatarFramework.Animation.AvatarAnimation','ScheduleOne.AvatarFramework.Animation.AvatarAnimationId','ScheduleOne.AvatarFramework.Animation.AvatarIKController','ScheduleOne.AvatarFramework.Animation.AvatarLookController'],
'''NPCAnimation.UpdateMovementAnimation получает NPC velocity, переводит в local space через InverseTransformVector и вызывает AvatarAnimation.SetMotion/SetBool/SetFloat.
AvatarAnimation.SetFloat вызывает AvatarAnimationId.Get, затем integer Animator.SetFloat/SetFloatID. Get сначала проверяет s_CustomHashes (Dictionary<string,int>), StringToHash выполняется на miss и результат сохраняется. Отдельные static IDs также вычислены .cctor. Утверждение о повторном StringToHash для каждого знакомого параметра неверно.
AvatarAnimation.Update/standup coroutine управляют transform/bone state и enabled; LateUpdate сохраняет bone transforms. S1Perf уже меняет Animator.cullingMode и повторяет NPC scan раз в 30 секунд после первого прохода спустя 8 секунд в Main.''',
'Исследовать, можно ли передавать уже готовые IDs без dictionary lookup, но только после измерения. Нельзя добавлять второй hash cache как якобы отсутствующий.',
'Root motion, standup, IK, animation events, offscreen gameplay, Animator lifecycle, stale native pointer cache в стороннем моде.'),
('09-MOD-COMPATIBILITY','Mod compatibility и MelonLoader',[],
'''С Cecil прочитаны 15 managed assemblies верхнего уровня Mods/UserLibs/Plugins: 10 Mods и 5 UserLibs. Записаны assembly refs/versions/MVID, 26013 IL call/newobj sites и 103 Harmony attribute records. Это статические записи, не число runtime вызовов или независимых патчей.
Подтверждено пересечение объявленных targets: Schedule1BetterEmployees prefix и WagesManager postfix для PackagerConfiguration.ShouldSave. Это основание для аудита результата и порядка, не доказанный конфликт.
Рекурсивные аргументы атрибутов сохранены. Dynamic Harmony.Patch/TargetMethod/рефлексия и фактический порядок loaders полностью не разрешены. ScheduleRu и XUnity не объявляются полностью дублирующими перевод по именам. Локальный build ScheduleRu ранее не совпал с установленным: не пересобирать вслепую.''',
'Составить точную карту dynamic patch targets, результат prefix/postfix и resolution paths; отдельно измерить UI scan и диагностическую запись.',
'Изменение сохранений и employee configuration, порядок Harmony, сторонние writers, версия IL2CPP interop. Метаданные не гарантируют совместимость.'),
('10-OTHER-COSTS','Дополнительные направления: UI, транспорт, networking',['ScheduleOne.Vehicles.AI.VehicleAgent','ScheduleOne.Vision.PlayerVisibility','FishNet.Managing.Timing.TimeManager'],
'''VehicleAgent.LateUpdate содержит PID.Update и пути String.Concat/Debug.Log; наличие путей логирования не доказывает выполнение каждый кадр. Reverse coroutine обращается к GetWheelSweepCollision и path utilities.
PlayerVisibility.Update вызывает сетевые ApplyState/RemoveState пути. FishNet timing metadata проиндексирована, но полная runtime tick graph не исследована.
Из прежнего установленного ScheduleRu IL: CanvasScanInterval=0 допускает один очередной canvas scan каждый кадр через GetComponentsInChildren<TMP_Text>, НЕ обход всех canvases каждый кадр. DumpUntranslated=true допускает AppendAllText. Это конкретные кандидаты, а не подтверждённая причина FPS.''',
'Разрешённое в будущем измерение UI scan cadence, branch logging и сетевой роли. Изменять только отдельный параметр или узкий компонент после согласования.',
'Задержка перевода UI, потеря диагностик, transport/host behavior. Не трогать Steam/DRM или сторонние сетевые защиты.')]

HANDOFF='''# HANDOFF PROMPT: Schedule I Performance Overhaul

Ты продолжаешь исследование по приложенному AI_RESEARCH_PACKAGE. У тебя может не быть Custom MCP, Windows или доступа к исходной игре. Пакет является источником evidence, а не полным исходным кодом или доказательством ускорения.

## Сначала прочитай
1. PROJECT_OVERVIEW.md, PROJECT_STATE.md, GAME_ARCHITECTURE.md.
2. REVERSE_ENGINEERING/FINDINGS.md и REVERSE_ENGINEERING/EVIDENCE_RULES.md.
3. REVERSE_ENGINEERING/NPC_DESTINATION_CONTRACT.md и PATH_CACHE_OWNERSHIP.md.
4. SUBSYSTEMS/ нужного направления; OPEN_QUESTIONS.md, RISKS.md, OPTIMIZATION_OPPORTUNITIES.md.
5. QA_REPORT.json и FILE_MANIFEST.json. При доступном Python запусти `python ANALYZERS/offline_query.py verify .` из корня пакета. Это не требует игры, сети, MCP, .NET или установки пакетов.

## Условия работы
Не запускать игру, не менять её файлы, настройки, сохранения или установленные моды. Не устанавливать инструменты без необходимости. Не разрабатывать и не применять оптимизационный мод без отдельного согласования. Не удалять прежнее исследование. Не считать это разрешением на runtime profiling. Не обходить защиты или DRM.

## Достоверность
Различай CONFIRMED_STATIC, HISTORICAL, HYPOTHESIS и UNKNOWN. Ссылайся на относительный файл, метод и RVA либо IL offset. При несовпадении GameAssembly/metadata fingerprint не переноси адреса на другую сборку. Preferred VA = 0x180000000 + RVA, не runtime VA из-за ASLR.
Call-site counts не runtime counts. Cpp2IL stubs/interop не исходные C# bodies. Generic sharing и aliases не доказывают тип фактического объекта; даже один символ по адресу может быть representative generic constructor. 0x43FEC0 является shared ret. Не выводи семантику из первых alias labels.
Новые native ranges ограничены Cpp2IL Length; два Astar MoveNext обрываются на INVALID. NPC phase2 roots имеют отдельную unwind проверку и +1 trailing byte. Нет полного CFG/indirect/Burst/UnityPlayer анализа. Candidate resource names эвристические, payload layouts не подтверждены.

## Что уже известно, не предлагай повторно
- NPC avoidance уже 0.5 s со случайным стартом; квадраты расстояний <=625 до Player Avatar.CenterPoint, no-player out distance=0.
- NPCMovement.FixedUpdate серверный; не уменьшать частоту всей симуляции.
- Path cache, NativeArray ring history, Burst Average уже существуют. NavMeshPath.corners кэшируется на объекте.
- AvatarAnimationId уже хранит dictionary name-to-ID; знакомые имена не обязательно повторно StringToHash.
- ShadowLODController уже distance LOD, camera movement events и dedup одинакового mode.
- TimeManager уже использует ActionList.InvokeAllStaggered.
- S1Perf уже меняет Animator culling и collision reuse; ScheduleRu установленный бинарник важнее несовпавшего локального build.
- Измеренного прироста FPS/CPU/GC/GPU нет.

## Первый полезный offline шаг
Выбери ОДНО направление: (A) формальная карта UpdateDestination + EndSetDestination callback reentrancy; (B) владельцы retained NavMeshPath и условия безопасной invalidation; (C) взаимодействие двух PackagerConfiguration.ShouldSave patches; (D) риски действующего Animator culling.
Используй уже включённые листинги и индексы, не повторяй восстановление NPC roots. Для A отдельно сохрани строгий `< threshold`, NaN/equality поведение, branch reset только при hasPath, callback до очистки полей на нормальном возврате, отдельно exception behavior, retry-вызов SetDestination с существующим callback. Для B не делай вывод об утечке только из AddPath/GetPath: внешние writers не полностью найдены.

## Поиск без игры
`python ANALYZERS/offline_query.py methods NPCMovement`
`python ANALYZERS/offline_query.py methods AvatarAnimationId`
`python ANALYZERS/offline_query.py calls GetAverageLightExposure`
`python ANALYZERS/offline_query.py mods PackagerConfiguration`
В EVIDENCE/phase2/evidence/methods-all.json полный ранее извлечённый address-bearing method index. В EVIDENCE/current/selected-types-fields.json поля/сигнатуры выбранных типов, interop-selected-api.json публичная поверхность. В CALL_GRAPHS/ адресные graphs, без заявления о полном графе игры.

## Граница автономности
С пакетом можно продолжать техническую аргументацию, анализ уже извлечённого кода, спецификации и тестовые планы. Нельзя честно получать новые неизвестные native bodies, текстуры, активные scene values или FPS из отсутствующей игры. Если доказательства не хватает, создай DATA_REQUEST.md: точный относительный оригинальный путь, его SHA-256 из original-files-sha256.json, нужные RVA/размеры либо object path_id, read-only способ извлечения и ожидаемый формат. Не требуй постоянный MCP; пользователь сможет передать отдельный небольшой файл позже.

## Требуемый результат следующего этапа
Кратко зафиксируй исследованный scope, новые факты с evidence, гипотезы, противоречия, неизменённые ограничения, список файлов и следующий проверяемый шаг. Не заявляй FPS gain без отдельно разрешённого воспроизводимого runtime test. Сохрани все знания в пакет, не только в разговор.
'''
