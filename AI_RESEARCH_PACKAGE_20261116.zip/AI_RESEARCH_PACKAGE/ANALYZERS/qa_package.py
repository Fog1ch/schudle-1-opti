from pathlib import Path
import json,hashlib,re,csv,ast,collections,subprocess,sys
from urllib.parse import unquote
R=Path(__file__).parent;L=R.parent;P=L/'EXPORT/AI_RESEARCH_PACKAGE';G=Path(r'B:\Schedule I')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
errors=[];checks={}
# All standard Markdown links, including preserved historical docs.
links=[]
for p in P.rglob('*.md'):
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8-sig')):
  target=unquote(target.strip().strip('<>')).split('#')[0]
  if not target or re.match(r'^[a-zA-Z]+://',target):continue
  q=(p.parent/target).resolve();ok=q.exists() and q.is_relative_to(P.resolve());links.append({'file':p.relative_to(P).as_posix(),'target':target,'exists':ok})
  if not ok and q.name not in ['QA_REPORT.json','FILE_MANIFEST.json','CREATED_FILES.txt']:errors.append({'broken_link':links[-1]})
checks['markdown_links_checked']=len(links)
for p in P.rglob('*.json'):
 try:read(p)
 except Exception as e:errors.append({'json_error':str(p.relative_to(P)),'type':type(e).__name__})
for p in P.rglob('*.jsonl'):
 for i,line in enumerate(p.read_text(encoding='utf-8-sig').splitlines()):
  try:json.loads(line)
  except Exception:errors.append({'jsonl_error':str(p.relative_to(P)),'line':i+1})
for p in P.rglob('*.py'):
 try:ast.parse(p.read_text(encoding='utf-8-sig'))
 except Exception as e:errors.append({'python_syntax_error':str(p.relative_to(P)),'type':type(e).__name__})
claims=read(P/'REVERSE_ENGINEERING/claims.json')
for c in claims:
 p=P/c['file'];text=p.read_text(encoding='utf-8-sig') if p.exists() else ''
 if not all(n in text for n in c['needles']):errors.append({'claim_evidence_error':c['id']})
checks['claim_evidence_anchors']=len(claims)
prior=read(L/'phase2-npcmovement/MANIFEST.sha256.json');checks['prior_files_verified']=len(prior)
for row in prior:
 a=L/'phase2-npcmovement'/row['path'];b=P/'EVIDENCE/phase2'/row['path']
 if not a.exists() or sha(a)!=row['sha256'] or not b.exists() or sha(b)!=row['sha256']:errors.append({'prior_integrity':row['path']})
# compare old config fingerprint baseline with current raw files
v=read(L/'phase2-npcmovement/VERIFICATION.json');checks['historical_baseline_comparisons']=v.get('baseline_comparisons')
manifest=read(Path(r'B:\ScheduleI-PerfLab-20261115\prepared\manifest.json'))
config_checks=[]
for cfg in manifest['profiles'].values():
 p=G/cfg['target'];ok=sha(p)==cfg['before'].lower();config_checks.append({'path':cfg['target'],'match_historical_baseline':ok})
 if not ok:errors.append({'config_baseline_changed':cfg['target']})
checks['configuration_baseline']=config_checks
old=read(P/'EVIDENCE/prior/assets.json');new=read(P/'EVIDENCE/current/asset-containers-current.json');oldcounts={x['file']:x['objects'] for x in old};newcounts={x['container']:x['objects'] for x in new};checks['container_object_counts_match']=oldcounts==newcounts
if oldcounts!=newcounts:errors.append({'container_count_mismatch':True})
tot=collections.Counter()
for x in new:
 for k,n in x['class_counts'].items():tot[k]+=n
checks['asset_counts']={'Texture2D':tot['28'],'AudioClip':tot['83'],'Shader':tot['48'],'external_references':sum(len(x['external_references']) for x in new)}
scans=read(P/'EVIDENCE/current/native-scans.json');checks['native_ranges']=len(scans);checks['incomplete_native_ranges']=[x for x in scans if x['Invalid']]
# critical file unchanged; full byte-identical file set gets checked by finalizer
critical=read(P/'EVIDENCE/baseline/critical-fingerprints.json')
for x in critical:
 if sha(G/x['path'])!=x['sha256']:errors.append({'critical_original_changed':x['path']})
checks['critical_original_files_verified']=len(critical)
for p in P.rglob('*'):
 if p.is_file() and p.suffix.lower() in ['.dll','.exe','.dat','.resS','.resource','.png','.jpg','.ogg','.wav']:errors.append({'unexpected_binary_payload':p.relative_to(P).as_posix()})
# Check selected generated asset names and values for credential-shaped data without printing any value.
secret_hits=[]
patterns=[r'(?i)(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password)\s*[=:]\s*["\x27]([^"\x27\r\n]{12,})',r'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}']
for rel in ['EVIDENCE/current/asset-object-index.csv','EVIDENCE/current/performance-config-evidence.json','EVIDENCE/prior/S1Perf.installed.cs','EVIDENCE/prior/ScheduleRu.installed.cs']:
 text=(P/rel).read_text(encoding='utf-8-sig')
 if any(re.search(pattern,text) for pattern in patterns):secret_hits.append(rel)
checks['credential_pattern_scan_files']=4;checks['credential_pattern_hits_paths_only']=secret_hits
if secret_hits:errors.append({'credential_review_required':secret_hits})
# Test offline search against packaged data, without game access.
tests=[]
for cmd,q in [('methods','NPCMovement'),('calls','GetAverageLightExposure'),('mods','PackagerConfiguration')]:
 run=subprocess.run([sys.executable,str(P/'ANALYZERS/offline_query.py'),cmd,q],capture_output=True,text=True,encoding='utf-8',errors='replace');tests.append({'command':cmd,'query':q,'exit':run.returncode,'summary':run.stdout.strip().splitlines()[-1] if run.stdout else ''})
 if run.returncode:errors.append({'offline_test_failed':cmd})
checks['offline_queries']=tests
report={'status':'PASS' if not errors else 'FAIL','errors':errors,'checks':checks,'scope':'Machine consistency/integrity checks plus curated evidence anchors. Does not prove complete reverse engineering or runtime correctness. Textual historical paths are provenance, not portable live links. Two incomplete Astar decodes remain explicitly documented.'}
(P/'QA_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');(R/'QA_STAGE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'status':report['status'],'errors':errors,'checks':checks},ensure_ascii=True))
