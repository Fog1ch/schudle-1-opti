from pathlib import Path
import shutil
R=Path(__file__).parent;P=R.parent/'EXPORT/AI_RESEARCH_PACKAGE'
changes={
'повторный path request; выход':'повторный вызов SetDestination, не доказанный новый path request; выход',
'ResetPath; обнулить поля +0x168 и +0x170 с write barriers':'ResetPath; обнулить поля +0x168 и +0x170, после каждой записи вызван helper 0x316AB0',
'- затем 0x8F44BC: callback = null; write barrier;':'- при нормальном возврате callback затем 0x8F44BC: callback = null; вызов helper 0x316AB0;',
'Факт: callback вызывается до очистки.':'Факт: на пути нормального возврата callback вызывается до очистки. При исключении callback последующая очистка данным листингом не гарантируется.',
'callback вызывается ДО очистки callback и _hasDestination':'на пути нормального возврата callback вызывается ДО очистки callback и _hasDestination',
'callback до очистки полей, retry SetDestination':'callback до очистки полей на нормальном возврате, отдельно exception behavior, retry-вызов SetDestination'
}
for p in list(P.rglob('*.md'))+[R/'build_package.py',R/'package_content.py']:
 if p.is_relative_to(P/'EVIDENCE'):continue
 s=p.read_text(encoding='utf-8')
 for a,b in changes.items():s=s.replace(a,b)
 if p.name=='NPC_DESTINATION_CONTRACT.md':s+='\n## Дополнительное машинное подтверждение distance\n\n[Helper 0x456100](../EVIDENCE/phase2/evidence/helper_456100.asm.txt) содержит покомпонентную разность, квадраты и сумму, затем sqrtpd на 0x456191 и преобразование обратно в float. Поэтому Euclidean distance подтверждено не одним именем call target, а отдельным helper listing. Inspection window заканчивается после ret 0x4561C1; trailing int3 не часть арифметики. Helper 0x316AB0 в этом этапе отдельно не восстановлен, его write-barrier трактовка из предыдущего исследования не является новым доказанным выводом.\n'
 p.write_text(s,encoding='utf-8')
review='''# Независимый read-only review и исправления

Проверены NPC_DESTINATION_CONTRACT против UpdateDestination/EndSetDestination, HANDOFF_PROMPT, ANALYZERS README и evidence rules. Reviewer не выполнял игру, не изменял файлы и не подтверждал весь package QA.

Приняты исправления:
- SetDestination call не объявляется обязательным новым path request.
- Callback-before-clear уточнён как normal-return path; исключения отдельно неизвестны.
- Helper 0x316AB0 назван адресом, а не заново доказанной write barrier.
- Добавлена прямая ссылка на ранее существовавший helper_456100 с sqrtpd. Это закрывает замечание о недостаточности одного caller listing для Euclidean distance.

Подтверждены strict threshold comparison и условный ResetPath/clear только при hasPath. Реентерабельность остаётся гипотезой/обязательством проверки.

Машинный QA отдельно проверяет evidence anchors, links, manifest и исходные хэши; не доказывает полноту reverse engineering или runtime equivalence.
'''
(P/'REVERSE_ENGINEERING/INDEPENDENT_REVIEW.md').write_text(review,encoding='utf-8')
for n in ['build_package.py','package_content.py','qa_package.py','refine_package.py']:shutil.copy2(R/n,P/'ANALYZERS'/n)
with (P/'ANALYZERS/README.md').open('a',encoding='utf-8') as f:f.write('\nqa_package.py и refine_package.py сохранены как recipe текущей проверки/редакции и требуют исходной lab layout. Не запускать refine_package повторно на финальном пакете. Для получателя независимая проверка только offline_query.py verify.\n')
print('Review corrections saved; original phase2 files unchanged.')
