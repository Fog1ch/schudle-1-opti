from pathlib import Path
import json,collections,re,hashlib
R=Path(__file__).parent;E=R/'evidence';L=R.parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
a=read(L/'evidence/audit.json');fps=read(R/'critical-fingerprints.json');by={x['path']:x for x in fps};checks=[{'path':k,'match':k in by and by[k]['sha256']==v} for k,v in a['identity'].items()];assert all(x['match'] for x in checks);(R/'baseline-identity-check.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
scans=read(E/'native-scans.json');edges=read(E/'native-edges.json');out=[]
for x in scans:
 es=[e for e in edges if e['FromRVA']==x['RVA']];resolved=[e for e in es if e.get('AliasCount',0)==1];ind=sum('TargetRVA' not in e for e in es)
 out.append({'root':x['Signature'],'rva':hex(x['RVA']),'invalid':x['Invalid'],'aliases':x['AliasCount'],'indirect':ind,'unique_direct_targets':sorted(set(t for e in resolved for t in e['Targets']))})
(E/'root-summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
mods=read(E/'mod-call-sites.json');interesting=['FindObjectsOfType','GetComponentsInChildren','Collect','AppendAllText','LoadAsset','LoadFrom','Patch','SetFloat','SetBool','SetTrigger','streamingMipmapsMemoryBudget','cullingMode']
sm=[]
for x in mods:
 if any(k in x['Target'] for k in interesting):sm.append(x)
(E/'mod-interesting-sites.json').write_text(json.dumps(sm,indent=2),encoding='utf-8')
lines=['SUMMARY '+json.dumps(read(E/'summary.json')),'INVALID '+json.dumps([x for x in scans if x['Invalid']]),'ROOTS']
for x in out:lines.append(x['root']+' '+x['rva']+' indirect='+str(x['indirect'])+' -> '+ '; '.join(x['unique_direct_targets']))
(R/'root-review.txt').write_text('\n'.join(lines),encoding='utf-8')
patches=read(E/'mod-patch-attributes.json');(R/'patch-review.txt').write_text('\n'.join(json.dumps(x) for x in patches),encoding='utf-8')
print('Identity checks passed; root-review.txt and patch-review.txt saved.')
