# Graph scope

DOT files use RVA nodes and source instruction-site labels. JSON contains signatures and up to eight representative aliases plus AliasCount. Empty graphs mean no selected native root for that category, not no work. Mod-specific relations live in mod-call-sites.json and mod-target-overlaps.json. Asset graph contains container references, not every PPtr.

NPC previous graph: [CALL_GRAPH.md](../EVIDENCE/phase2/CALL_GRAPH.md), [CALL_GRAPH.dot](../EVIDENCE/phase2/CALL_GRAPH.dot). Indirect calls are explicit unresolved nodes. Runtime order/frequency cannot be inferred from graph size.
