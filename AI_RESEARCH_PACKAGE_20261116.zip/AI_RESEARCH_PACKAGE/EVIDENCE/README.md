# Происхождение

phase2: прежние файлы без bin/obj, byte-for-byte копии; исходный manifest проверен. prior: исторические отчёты и небольшой установленный mod IL/decompilation. current: новые statically extracted indices/listings. baseline: контрольная точка до упаковки.

Исходные paths в исторических документах объясняют, где проводилась работа; они не являются переносимыми ссылками. Текущие relative Markdown links проверяются QA. Все новые claims указывают portable evidence. Не интерпретировать числа historical logs как текущий runtime.

Полный original-file hash inventory включает только путь/размер/hash, не содержимое. Saves исключены. Реальные executable DLLs, textures/audio и full logs не включены.
