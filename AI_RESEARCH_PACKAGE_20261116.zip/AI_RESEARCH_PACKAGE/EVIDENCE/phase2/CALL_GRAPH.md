# NPCMovement: проверенный граф вызовов

Легенда: `-->` прямой call/jmp по нативному коду; `-.->` диспетчеризация Unity либо строковый таймер; `[inline]` тело встроено компилятором и hook исходного метода его не перехватит. Условия относятся к ветвям, а не гарантии исполнения в каждой итерации.

```mermaid
flowchart TD
 U[Unity Update dispatch] -.-> A[NPCMovement.Update 8FA630]
 A --> L{currentLadder отсутствует}
 L --> O[NavMeshAgent.isOnOffMeshLink]
 O -->|на OffMeshLink| LD[currentOffMeshLinkData / offMeshLink]
 LD --> GC[GetComponent generic: результат Ladder]
 GC --> TR[inline TraverseLadder setup]
 TR --> AG[SetAgentEnabled false]
 TR --> CO[StopCoroutine при наличии / StartCoroutine]
 F[Unity fixed-step dispatch] -.-> FU[FixedUpdate 8F49E0]
 FU --> SV{FishNet InstanceFinder.IsServer}
 SV --> ST[UpdateStumble]
 ST -->|условно| SM[NavMeshAgent.Move / ActivateRagdoll_Server]
 SV --> D[UpdateDestination]
 D -->|есть цель, не moving/pending и может двигаться| CLOSE[IsAsCloseAsPossible]
 CLOSE -->|условно| REACH[GetClosestReachablePoint]
 REACH -->|cache miss / условия| CALC[NavMesh.CalculatePath]
 D -->|цель не достигнута| SD[SetDestination]
 SD --> PC[NPCPathCache.GetPath]
 SD --> PATH[NavMeshAgent.SetPath или SetDestination]
 SD --> SNAP[agent.path: новый NavMeshPath / corners: ленивый массив]
 D -->|завершение| END[EndSetDestination: callback]
 SV --> VR[inline RecordVelocity: таймер и CircularQueue.Enqueue]
 SV -->|SlipperyMode + agent enabled/onNavMesh| AVG[BurstFunctions.Average]
 AVG --> BI[BurstDirectCall.Invoke]
 BI -.-> BURST[указатель Burst либо встроенный scalar fallback]
 SV -->|slippery| MOVE[NavMeshAgent.Move]
 SV -->|cacheNextPath и пригодный путь| CACHE[inline UpdateCache: PathCache entry + List.Add]
 SV --> RAG[inline ragdoll static counter / recovery checks]
 RAG --> RPC[FishNet writer / RpcLogic DeactivateRagdoll]
 RPC --> RESET[Avatar.DisableRagdoll / Transform / NavMesh / FlushBuffer]
 OS[OnStartServer 8F6130] --> IR[InvokeRepeating: UpdateObstacleAvoidance]
 IR -.->|initial random 0..0.5 s; period 0.5 s| OA[UpdateObstacleAvoidance 8F9E20]
 OA --> SERVER{IsServer}
 SERVER --> POS[transform.position]
 POS --> PLAYER[PlayerManager.GetClosestPlayerSqr]
 PLAYER --> ITER[существующая коллекция игроков, enumerator на стеке]
 ITER --> CENTER[Avatar.CenterPoint: MiddleSpine Transform.position]
 PLAYER --> TH{distance squared <=625 and enabled}
 TH -->|да| DEF[agent.obstacleAvoidanceType = default]
 TH -->|нет| NONE[agent.obstacleAvoidanceType = 0]
 COMBAT[CombatBehaviour.EndCombat] --> SET[SetObstacleAvoidanceEnabled]
 SET --> INLINE[inline obstacle policy: тот же поиск и setter]
 VIS[OnVisibilityChange] --> ACTIVE[capsule GameObject.SetActive]
 VIS --> AE[SetAgentEnabled visible and server]
```

## Входящие вызовы и полнота
В 110399 известных уникальных Cpp2IL диапазонах не обнаружено прямых call/jmp к RVA Update, FixedUpdate и UpdateObstacleAvoidance. Для первых двух ожидается Unity callback dispatch. Для третьего строка таймера извлечена из metadata (literal index 15469), период подтверждён float 0.5 и регистрами вызова OnStartServer.

Отсутствие direct xref не означает, что метод не вызывается. Косвенные вызовы, виртуальная диспетчеризация, делегаты, reflection, вызовы из UnityPlayer и inlined копии не исчерпываются этим графом.

Подтверждённые отдельные связи: FixedUpdate -> UpdateStumble (site 8F4A0E), FixedUpdate -> UpdateDestination (8F4A18), UpdateDestination -> SetDestination overload (8F9C88), CombatBehaviour.EndCombat -> SetObstacleAvoidanceEnabled (98E396). Setter содержит встроенную политику avoidance, а не call UpdateObstacleAvoidance.

UpdateSlippery, UpdateCache, RecordVelocity, UpdateRagdollStaticCounter и UpdateRagdoll существуют как отдельные символы, но соответствующие фрагменты встроены в FixedUpdate. Перехват отдельных методов не гарантирует изменения этих фрагментов.

Полные direct edges: evidence/npc-incoming.json и npc-outgoing.json. CALL_GRAPH.dot содержит граф по RVA всех методов NPCMovement. Символы с одинаковым адресом являются aliases, а не доказательством вызова каждого имени. Например общий ret 43FEC0 не доказывает вызов URPOutlineFeature из движения NPC.
