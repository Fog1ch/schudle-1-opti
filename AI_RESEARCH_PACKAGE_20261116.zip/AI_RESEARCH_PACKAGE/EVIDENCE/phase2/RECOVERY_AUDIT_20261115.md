# Phase 2 NPCMovement: восстановление состояния и аудит evidence

Дата сессии: 2026-11-15. Статус: частичный статический аудит завершён; полное восстановление поведения NPCMovement НЕ завершено. Реализации патча, запуска игры и измерений производительности в этой сессии нет.

## 1. Источники и изменение состояния во время чтения

Проверены прежние REPORT.ru.md и README.ru.md из корня исследования, B:\ScheduleI-PerfLab-20261115\REPORT-RU.md, PROJECT_STATE.md, исторический tests.txt, исходник phase2-npcmovement\analyzer\Program.cs и целевая выдержка существующих карт методов, полей и прямых вызовов. Дополнительно успешно интерпретированы полные листинги UpdateRagdoll_8F9FF0.asm.txt и UpdateRagdollStaticCounter_8F9EE0.asm.txt.

В начале сессии PROJECT_STATE.md описывал незавершённую генерацию evidence. При повторном чтении файл уже содержал более подробное состояние: Phase 2 static research deliverables SAVED AND VERIFIED. Наблюдаемое LastWriteTimeUtc: 2026-11-15 22:58:19; размер 6617 байт. Появились ссылки на REPORT.ru.md, CALL_GRAPH.md/.dot, METHOD_MAP.csv, FIELD_MAP.csv, VERIFICATION.json и MANIFEST.sha256.json внутри phase2-npcmovement. Это изменения, обнаруженные в источнике, а НЕ результат данного аудита. Их происхождение не установлено. Старое состояние не перезаписывалось; перечисленные материалы не пересоздавались.

Новые подробные утверждения PROJECT_STATE.md, например о 0.5-секундном avoidance, unwind-границах и верификации 252 файлов, в этой сессии не прошли независимую полную сверку. Они остаются результатами, заявленными текущим состоянием проекта, а не новым доказательством настоящего отчёта.

## 2. Действительно выполненная прежняя работа

По прежним отчётам выполнены статический аудит установки/модов, анализ установленного IL S1Perf/ScheduleRu, индекс девяти Unity-контейнеров и подготовка внешних конфигурационных экспериментов. Исторический tests.txt корневого C-пакета содержит 7 unit tests и 7 fixture integration tests, обе серии OK. B-пакет отдельно сообщает 10 тестов; эти наборы не складываются в число уникальных проверок и не являются сегодняшним запуском.

Пакеты различаются. C-пакет s1lab.py: ui-scan, quiet-translation, texture-2560; boot.config намеренно не меняется. B-пакет perflab.py: translator-paced и boot-baseline. Нельзя смешивать их профили или считать их взаимозаменяемыми. Нет доказанного прироста FPS/снижения памяти; прежние журналы не являются контролируемым A/B. Локальная сборка ScheduleRu отличается от установленной DLL, слепая пересборка недопустима.

## 3. Что уже извлекает анализатор

Program.cs исследован полностью. Анализатор использует адреса и длины Cpp2IL, линейно декодирует известные диапазоны и сохраняет прямые near call и внешние безусловные jmp. Для совпадающего RVA выбирается одна исходная сигнатура и максимальная длина. Цели разрешаются по точному началу RVA. Косвенные вызовы для NPC сохраняются в отдельных calls.json, но не включены в агрегированный npc-outgoing.json.

Существующая summary, а не новая генерация: 146047 записей методов, 110399 диапазонов, 7541924 попытки декодирования, 205 invalid stops, 105 NPCMovement entries, 441 incoming и 1143 outgoing edges. Это статические callsites, не число runtime-вызовов и не статистика CPU.

Ограничения исходника: нет полной проверки CFG/reachability, перекрытий, executable-секций, thunk-normalization или доказательства границ функции; нет полного virtual/interface/delegate/Unity-callback графа. Anomalies=[] не доказывает корректность всего графа. Отсутствие прямых incoming edges не доказывает неиспользование метода.

## 4. Подтверждённая целевая карта pathfinding

Источник: npc-methods.json, npc-incoming.json, npc-outgoing.json, methods-all.json (узкая выборка, не полный повторный анализ).

- SetDestination(Vector3), RVA 0x8F8050: 11 callsites от 10 методов. Среди них PoliceOfficer.CheckDeactivation, NPCWalkTo.Update и несколько Behaviour; CombatBehaviour/<SearchRoutine>d__97.MoveNext содержит два sites, 0x9B9187 и 0x9B9232.
- Перегрузка SetDestination(Vector3, Action, float, float), RVA 0x8F8C90: callers Employee.SetDestination (site 0x6D6974), Behaviour.SetDestination (0x919D36), NPCAction.SetDestination (0x963E3A).
- Основная SetDestination(Vector3, Action, bool, float, float), RVA 0x8F8110: пять входящих ребер, четыре перегрузки и UpdateDestination.
- UpdateDestination, RVA 0x8F9B70: прямой caller FixedUpdate, site 0x8F4A18; вызов основной SetDestination внутри updater на 0x8F9C88.
- Основная SetDestination содержит sites SmartSampleNavMesh 0x8F8585, GetClosestReachablePoint 0x8F86A1, NPCPathCache.GetPath 0x8F8771, NavMeshAgent.SetPath 0x8F8804 и NavMeshAgent.SetDestination 0x8F8834.
- GetClosestReachablePoint вызывает NavMesh.CalculatePath на 0x8F556F; GetPathTo вызывает NavMeshAgent.CalculatePath на 0x8F5745.
- npc-fields.json: USE_PATH_CACHE=true; _pathCache @0x1B8, _cacheNextPath @0x1C0, _currentPath @0x168, _currentPathCorners @0x170, _hasDestination @0x160, _agent @0x138.

Все 33 ребра целевой incoming-выборки имеют однозначные source/target aliases в существующем каталоге. Это символьная однозначность, НЕ доказательство полной точности границ или полноты callgraph. Наличие cache lookup, SetPath и SetDestination в одном методе не доказывает их совместное выполнение на каждом пути. Условия cache-hit/fallback ещё нуждаются в завершённой проверке.

## 5. Ложная семантическая атрибуция общих адресов

get_FootPosition @0x8FB250 имеет шесть aliases; 34 incoming edges относятся к общему адресу, не обязательно к NPC getter. get_SpeedController @0x6B8870 имеет 33 aliases, get_CurrentStance @0x4E7E70 восемь, NetworkInitializeIfDisabled @0x51FE10 сорок один. Причину sharing/folding одним каталогом установить нельзя. Метки чужих функций при общем адресе нельзя объявлять реальной зависимостью NPCMovement.

## 6. Продолженная часть: ragdoll state maintenance

Источник: полные UpdateRagdollStaticCounter_8F9EE0.asm.txt и UpdateRagdoll_8F9FF0.asm.txt. Эти выводы прошли интерпретацию evidence.

UpdateRagdollStaticCounter:
- Проверяет Avatar.Ragdolled на site 0x8F9F0B. Если false, сбрасывает float [this+0x1B0].
- Проверяет ещё один байт через цепочку [this+0x158] -> [+0x1A0] -> [+0x130] -> [+0x170]. Ненулевое значение тоже обнуляет счётчик. Семантическое имя флага не установлено.
- GetRagdollRootVelocity вызывается на 0x8F9F71; helper 0x4561D0 на 0x8F9F8E. Если результат helper строго меньше float по RVA 0x2E5D840, прибавляется один Time.fixedDeltaTime: вызов на 0x8F9FBF, запись на 0x8F9FCD. Иначе сброс. Имя helper и численное значение порога здесь окончательно не доказаны.

UpdateRagdoll:
- Порядок допуска: NPC.IsConscious -> [this+0x1B0] больше float по RVA 0x2E5CB44 -> Avatar.Ragdolled.
- IsServerInitialized вызывается на 0x8FA099. Серверная ветка содержит сетевые операции и PooledWriter.Store/Dispose; другая ветка ведёт к предупреждению.
- Обе нормальные ветки сходятся к локальному RpcLogic___DeactivateRagdoll_2166136261, site 0x8FA152, target RVA 0x8F6860. Проверку IsServerInitialized в этом методе нельзя описывать как безусловный запрет последующей локальной логики.

Практическое следствие: wholesale tick throttling не доказан безопасным. Пропуск вызовов замедляет накопление счётчика, добавляющего fixedDeltaTime за исполнение, и способен скрыть краткое состояние, которое должно обнулить счётчик. Умножение delta на число пропущенных тиков не восстанавливает потерянные наблюдения. Это риск изменения семантики, не измеренный runtime-баг.

Нельзя автоматически переносить standalone helper-выводы на FixedUpdate: предварительное чтение показывает встроенные эквиваленты части логики. Полная проверка inline paths и сетевого callback ещё не завершена.

## 7. Неполные материалы и открытые вопросы

1. Полные условия и побочные эффекты всех выходов UpdateDestination; enum WalkResult 1/3/4, порядок EndSetDestination callback, реентерабельность и очистка полей.
2. Взаимоисключение cache-hit/SetPath и fallback/SetDestination; path ownership, инвалидация, рост/очистка кэша и сохранение corner arrays.
3. Перекрытия диапазонов methods-all.json и точные границы helper-window, включая alias/shared тела.
4. Полный FixedUpdate inline dataflow и неразрешённый virtual call в деактивации ragdoll; семантика повторного включения NavMeshAgent.
5. Точные поля, константы и helper 0x4561D0; network authority, callback ordering и внешние mod writers.
6. Runtime частоты, CPU/GC стоимость и поведенческая эквивалентность неизвестны. Нельзя выбирать оптимизацию по размеру метода или числу прямых callsites.

Чтение существующих ASM для Update, UpdateDestination, UpdateCache и NPCPathCache.GetPath было выполнено, но обязательный дополнительный анализ через переносимые копии остановился: часть созданных копий перестала открываться, последующие сохранения возвращали пустой список доступных assets. Поэтому в этом отчёте не объявляется завершённой интерпретация этих ветвей. Это ограничение обработки копий, а не недоступность Windows Terminal. Повторное получение disassembly не требуется.

## 8. Следующий шаг с максимальной пользой

Завершить карту исходов UpdateDestination и proof obligations для узкой замены, используя существующие UpdateDestination_8F9B70.asm.txt, EndSetDestination_8F4490.asm.txt, IsAsCloseAsPossible_8F59C0.asm.txt, SetDestination_8F8110.asm.txt и metadata enum/полей. Для каждого выхода зафиксировать guards, изменения _hasDestination/_currentPath/_currentPathCorners, callback и его порядок. Затем проверить ownership/инвалидацию cache. Не заменять весь FixedUpdate и не начинать реализацию до доказательства эквивалентности. Дублирующее вычисление расстояния отмечено текущим PROJECT_STATE.md как кандидат; его частота и выигрыш не измерены.

## 9. Доступные средства и воспроизводимость

Windows x64, PowerShell через cmd; SDK .NET 8.0.403 и 10.0.201. Найдены tools\ilspy\ilspycmd.cmd, локальный Iced.dll и analyzer\bin\Release\net8.0 с Analyzer.dll/.exe, Iced.dll, Mono.Cecil.dll и служебными файлами. Проверено наличие, не исполнение анализатора/ILSpy. Использованы существующие evidence; повторного дизассемблирования, тестов, установки пакетов, изменения DLL/настроек/сохранений и запуска Schedule I не было.

Новые записи этой сессии: данный дополнительный отчёт и добавочная запись в PROJECT_STATE.md. Существующий phase2-npcmovement\REPORT.ru.md, карты, evidence и manifests намеренно не изменены. Старый manifest не удостоверяет новый дополнительный отчёт.
