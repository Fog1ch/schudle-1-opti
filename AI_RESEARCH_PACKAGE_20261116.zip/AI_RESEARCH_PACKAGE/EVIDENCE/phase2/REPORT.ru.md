# S1 Performance Overhaul: Phase 2, NPCMovement

Дата: 15.11.2026. Статическое исследование, без запуска игры и без реализации патчей.

## 1. Главные результаты

1. Update не содержит основной цикл обхода препятствий. Он проверяет текущую лестницу и переход на OffMeshLink, затем запускает корутину лестницы.
2. FixedUpdate серверный: первым проверяет FishNet.InstanceFinder.IsServer. Содержит UpdateStumble, UpdateDestination, выборку истории скорости, slippery movement, запись кэша пути и восстановление ragdoll. Клиент без серверной роли выходит сразу.
3. UpdateObstacleAvoidance УЖЕ вызывается через InvokeRepeating с периодом 0.5 s и случайной начальной задержкой 0..0.5 s. Предлагать перевод с каждого кадра на 2 Hz или первичное распределение нагрузки было бы повторением существующей оптимизации.
4. Политика avoidance: сравнение квадрата расстояния до ближайшего игрока с 625 (25 единиц расстояния). При доступном avoidance и расстоянии <=625 записывается default type, иначе 0. Это переключатель качества встроенного NavMesh avoidance, не собственный raycast solver.
5. Реальный повтор найден в UpdateDestination: две последовательные пары transform.position + вычисление евклидова расстояния при неуспехе первой проверки. Это кандидат на устранение одинаковой работы без изменения частоты симуляции.
6. Кэш путей, кольцевая NativeArray-история и Burst Average уже есть. Нужно улучшать существующие механизмы, а не объявлять их отсутствующими.
7. Прирост FPS, длительность функций, аллокации/сек и частота проблемных ветвей НЕ измерены. Приоритеты ниже исследовательские, не рейтинг измеренной нагрузки.

## 2. Источники и воспроизводимость

Прочитаны предыдущие REPORT.ru.md в корне лаборатории и B:\ScheduleI-PerfLab-20261115\REPORT-RU.md. Их assets/mod evidence повторно не генерировались. PROJECT_STATE.md и прежнее глубокое NPCMovement-исследование не найдены в проверенных путях; новый PROJECT_STATE.md создан в корне этой лаборатории.

GameAssembly: B:\Schedule I\GameAssembly.dll.
SHA256: 61829050e56ca180d67be592e4bfe61ec97d2e9573f720d90a54e318a7e4381d.
Metadata: B:\Schedule I\Schedule I_Data\il2cpp_data\Metadata\global-metadata.dat.
SHA256: e775c97da277da8eb1a90265478f3b65c9c3d6464aff4f7255d45280a1d1181f.
Cpp2IL: B:\Schedule I\MelonLoader\Dependencies\Il2CppAssemblyGenerator\Cpp2IL\cpp2il_out.
Interop: B:\Schedule I\MelonLoader\Il2CppAssemblies.

Использованы уже установленные .NET 8, Mono.Cecil и Iced 1.21.0. Создан отдельный Analyzer.csproj, не игровой мод. Пакеты не устанавливались. Его Program.cs читает DLL как данные, не загружает GameAssembly для исполнения.

Индекс: 146047 записей методов всех Cpp2IL DLL, 110399 уникальных диапазонов, 7541924 декодированных инструкций, 205 остановок на invalid instruction вне листингов NPCMovement. 105 записей методов самого NPCMovement (с aliases), 441 входящее direct-ребро по всему NPC-набору, 1143 исходящих call/tail-jump site. Это не runtime call counts.

Ограничение: проход по известным диапазонам, не доказанный полный CFG всей игры. Не разрешены все virtual/indirect targets, generic MethodInfo, холодные исключительные участки, вызовы из UnityPlayer и Burst binary. Листинги соседних helper inspection windows могут заканчивать следующий метод посередине; использовать только исследованную функцию до её границы.

## 3. Адреса и размеры

Preferred image base: 0x180000000. VA ниже вычислен от preferred base; действительный адрес при запуске зависит от ASLR. Игра не запускалась.

| Метод | RVA | Preferred VA | Файловое смещение | Cpp2IL Length | Покрытие PE unwind |
|---|---|---|---|---:|---:|
| Update | 0x8FA630 | 0x1808FA630 | 0x8F9830 | 0x252 = 594 B | 0x253 = 595 B |
| FixedUpdate | 0x8F49E0 | 0x1808F49E0 | 0x8F3BE0 | 0x6C4 = 1732 B | 0x6C5 = 1733 B |
| UpdateObstacleAvoidance | 0x8F9E20 | 0x1808F9E20 | 0x8F9020 | 0xBE = 190 B | 0xBF = 191 B |

Разница один байт у конца исключительной ветви; не скрыта. Update/FixedUpdate разбиты на несколько непрерывных unwind-записей; длина первой записи НЕ длина всей функции. evidence/method-boundaries.json содержит все сегменты. Дополнительные helper_8FA630, helper_8F49E0, helper_8F9E20 включают весь unwind span. Ни тот, ни другой размер не включает транзитивные callees.

## 4. Update: логика и аллокации

Evidence: Update_8FA630.asm.txt, TraverseLadder_8F9850.asm.txt, npc-fields.json.

- this сохраняется в rdi; +0x1A0 = _currentLadder, +0x138 = _agent, +0x1A8 = _ladderClimbRoutine.
- 8FA6AC: Unity Object inequality для _currentLadder. При существующей лестнице выход.
- 8FA6D3: NavMeshAgent.isOnOffMeshLink. При false выход.
- Далее currentOffMeshLinkData, offMeshLink, generic Component.GetComponent. Результат сохраняется как Ladder. Generic MethodInfo не полностью разрешён, но тип целевого поля подтверждает Ladder-контекст.
- Два создания объектов через runtime helper 317B20 -> 392390, заполнение ссылок/состояния, выключение агента SetAgentEnabled(false), StopCoroutine при существующей корутине, StartCoroutine с IEnumerator, сохранение handle.
- Native helper 392390 выделяет память по размеру типа, записывает class pointer, обнуляет объект. Это сильное машинное подтверждение allocation path. Точные runtime-типы двух объектов окончательно не декодированы; форма соответствует closure + iterator state machine лестницы.

Аллокации условные при начале перехода, НЕ каждокадровые для обычного NPC. Vector3 и OffMeshLinkData в показанном коде на стеке, не самостоятельные heap allocations. Нет прямых Physics.Raycast/Overlap или Animator.Set* в корневом Update. Coroutine body и все Unity native внутренности полностью не исследованы.

GetComponent здесь не массовый поиск сцены и не выполняется каждый кадр при обычной ходьбе. Кэширование Ladder потенциально возможно, но имеет низкий ожидаемый приоритет без счётчика переходов и требует инвалидировать уничтоженные/заменённые ссылки. Не менять своевременность входа на лестницу.

## 5. FixedUpdate: серверная симуляция

Evidence: FixedUpdate_8F49E0.asm.txt и связанные NPC/helper листинги.

### Условная последовательность

1. 8F49F4 IsServer; false -> return.
2. UpdateStumble (8F4A0E) и UpdateDestination (8F4A18).
3. История скорости: +0x1F0 timeSinceLastVelocityHistoryRecord сравнивается с +0x1EC velocityHistorySpacing. Пока <= spacing, добавляется fixedDeltaTime; когда > spacing, таймер сбрасывается и agent.velocity записывается в CircularQueue.
4. SlipperyMode (+0x131), agent.enabled и isOnNavMesh разрешают Average NativeArray, вычисление направления/масштаба и NavMeshAgent.Move.
5. При _cacheNextPath (+0x1C0), _currentPath (+0x168), corners.Length>1 создаётся PathCache entry и добавляется в список. Флаг сбрасывается до записи. Это не обязательная аллокация каждого fixed tick.
6. Проверяется _npc.Avatar.Ragdolled, состояние RagdollBehaviour и скорость корня ragdoll. Счётчик покоя +0x1B0 растёт при выполнении условий, иначе обнуляется.
7. При ragdoll, сознании и покое >1 s формируется сетевой путь деактивации и вызывается RpcLogic___DeactivateRagdoll. Там управление Avatar, Transform, NavMesh, сброс буфера скорости и возможный Warp.

История по конструктору: length=40, spacing=0.05f. Это defaults, не измеренные значения всех объектов. Из-за строгого сравнения > и отдельного reset выборка не равна точно 20 Hz при произвольном fixedDeltaTime. Enqueue пишет в готовую NativeArray и обновляет индексы без выделения heap. Текущее движение не должно терять историю при входе в slippery mode, поэтому нельзя просто отключить сбор в обычном режиме.

Average -> BurstDirectCall.Invoke -> indirect pointer при включённом Burst либо scalar fallback. Scalar fallback суммирует весь NativeArray.Length и делит на длину. Actual Burst function pointer не разрешён. Это не обоснование переписывать уже Burst-оптимизированный код на C#.

UpdateStumble сохраняет эффекты дезориентации, случайный выбор поведения и NavMeshAgent.Move в окне примерно 0.66 s. Пропуск fixed ticks меняет путь, RNG-последовательность и ragdoll. Нельзя распределять такие операции между кадрами без изменения поведения.

Повторные Ragdolled проверки есть, но сам getter: compare _activeRagdoll pointer с нулём и return. Создание внешнего словаря ради его кэширования может быть дороже исходного кода.

## 6. UpdateObstacleAvoidance: установленная политика

Evidence: OnStartServer_8F6130.asm.txt, UpdateObstacleAvoidance_8F9E20.asm.txt, constants-metadata.json, helper_676080.asm.txt.

OnStartServer регистрирует InvokeRepeating("UpdateObstacleAvoidance", Random.Range(0,0.5), 0.5). Строка доказана чтением literal index 15469 через usage slot RVA 39D4388. Это период игрового таймера, не обещание точного wall-clock 2 Hz при pause/timeScale/лагe.

Метод:
- серверный guard;
- transform.position;
- PlayerManager.GetClosestPlayerSqr(position, out distanceSqr, null);
- if distanceSqr <=625 && _obstacleAvoidanceEnabled -> _agent.obstacleAvoidanceType=_defaultObstacleAvoidanceType; else -> 0.

Default enum в конструкторе 4, но поле сериализовано, значит реальные prefabs могут задавать другое значение. Порог 25 относится к евклидову 3D расстоянию до Avatar.CenterPoint игрока, а не обязательно позиции ног. CenterPoint получает transform.position от MiddleSpine.

GetClosestPlayerSqr перебирает существующую коллекцию игроков, не FindObjectsOfType. Enumerator размещён на стеке. На нормальном исследованном пути не обнаружено создания списка, LINQ или массива; exception/init пути отдельно. Стоимость порядка O(P) на проверяемого NPC, а не O(всех объектов сцены).

Важная семантика: при отсутствии найденного игрока out distance остаётся 0; вызывающий метод не проверяет возвращённого Player. Любая будущая замена обязана воспроизвести это поведение, пока отдельное исправление не согласовано.

Setter avoidance вызывается даже при совпадении нужного значения с предыдущим. Но внутренний Unity setter может уже устранять лишнюю работу, это не проверено. Его дедупликация пока гипотеза, не гарантированная оптимизация.

SetObstacleAvoidanceEnabled записывает +0x132 и содержит встроенную копию этой политики. Прямого call UpdateObstacleAvoidance там нет. OnStartClient также пишет avoidance. Hook только UpdateObstacleAvoidance не контролирует все записи. CombatBehaviour.EndCombat вызывает SetObstacleAvoidanceEnabled. Видимость влияет через OnVisibilityChange -> capsule GameObject.SetActive и SetAgentEnabled(visible && server).

## 7. Подтверждённый кандидат: повтор UpdateDestination

RVA 8F9B70. Вызван из FixedUpdate. При отсутствии _hasDestination сразу выходит. Далее учитывает транспорт, движение, pending path, CanMove, лестницу и IsAsCloseAsPossible.

В финальной ветви:
- 8F9D11 + 8F9D2A: transform + position;
- 8F9D57: helper 456100, покомпонентная разность, сумма квадратов, sqrt;
- сравнение с _moveCallbackSuccessThreshold;
- при неуспехе 8F9D80 + 8F9D99 и 8F9DC6 повторяют то же чтение и расстояние;
- затем EndSetDestination с WalkResult.Success=4 или Partial=3. В транспорте Interrupted=1.

Это наиболее конкретное устранение дублирования, но с узкой частотой срабатывания: не весь движущийся NPC проходит эту ветвь. Между проверками не видно явной операции перемещения; тем не менее runtime hooks и возможные сторонние эффекты Unity getters требуют теста эквивалентности. Первым вариантом должна быть одна исходная distance-операция с повторным использованием результата, а не замена sqrt на squared comparison с иными пограничными свойствами float/NaN.

Сложность внедрения: участок внутри UpdateDestination. Prefix/Postfix вокруг него не удаляет середину оригинала. Нужна полная совместимая замена именно UpdateDestination либо низкоуровневое изменение блока. Замена всего FixedUpdate не требуется и не рекомендуется.

## 8. Навигация, Physics, Animator и память

- NavMesh является прямой основной зависимостью. В транзитивной ветви IsAsCloseAsPossible -> GetClosestReachablePoint есть SamplePosition, создание NavMeshPath и CalculatePath. Возможная дорогая ветвь, но её частота неизвестна.
- SetDestination уже обращается к NPCPathCache.GetPath. Кэш использует линейный поиск по Paths и квадраты расстояний до начальной/конечной точки. Нельзя добавлять кэш без понимания существующей семантики и срока жизни NavMeshPath.
- agent.path создаёт новый NavMeshPath object и native path handle. corners лениво получает и сохраняет массив внутри объекта. Повторные get_corners на одном объекте не означают новый массив каждый раз. Это доказано helper_2B1F000 и helper_2B20BF0.
- CacheNextPath создаёт entry и иногда расширяет List; не каждый fixed tick. Pooling требует карты владения retained NavMeshPath и удаления записей, сейчас она неполная.
- В трёх корнях нет прямого raycast/overlap loop или Animator.Set*; не предлагать NonAlloc raycasts или Animator.StringToHash без фактов. Physics есть в соседних collision callbacks/IgnoreCollision, ragdoll зависит от физики, Animator косвенно через Avatar/ladders/seating. Полный Animator подграф не восстановлен.
- Существующий S1Perf периодически ищет NPC/Animator и включает culling. Это отдельно изученная нагрузка мода, не доказанная внутренняя проблема NPCMovement. Расширять culling как безопасную оптимизацию NPC нельзя без проверки анимационных событий/root motion.

## 9. Приоритеты и реализуемость

| Приоритет | Возможность | Доказательство и ожидаемая область | S1Perf / Interop | Перехват / замена | Риск |
|---|---|---|---|---|---|
| P1 research | Убрать второй distance/position в UpdateDestination | Конкретный duplicate в финальной ветви; выигрыш не измерен | Да, API и поля доступны | IL2CPP-aware detour; полная замена небольшого метода, не FixedUpdate | Высокий для callback semantics; floating point и mods |
| P2 | Устранить одинаковые avoidance setter записи | Каждый таймерный вызов пишет enum; Unity внутренняя цена неизвестна | Да | Замена policy в двух путях, lifecycle tracking; native detour под managed hook | Средний/высокий: чужие записи, re-enable, client initialization |
| P2 research | Повторно использовать Average только пока история не менялась | Enqueue реже fixed loop; Average при slippery каждый fixed tick | Технически да | Нельзя полагаться на hook UpdateSlippery из-за inline; нужен узкий native block или замена части fixed loop | Высокий; внешние writers, порядок float суммирования, Burst |
| P3 | Кэшировать стабильные Transform-ссылки | Getter повторяется; _agent и _npc уже сохранены | Да, но interop/dictionary overhead может перекрыть пользу | Требует замены точек вызова, простой Postfix не убирает их | Средний; object lifetime и invalidation |
| P3 | Точный общий поиск ближайших игроков | O(P), уже 2 Hz и staggered | Возможно | Новая policy, сохранение no-player и CenterPoint semantics | Высокий при stale samples; для малой P вероятная малая отдача |
| P3 research | Pooling PathCache/NavMeshPath | Аллокации на создании пути/entry, не на каждом кадре | Частично | Сначала ownership audit, затем hooks в path creation/cache | Высокий: retained references, native handle disposal |
| P3 | Кэш Ladder для OffMeshLink | GetComponent только на входе на link | Да | Замена ladder start path, не обязательна глобальная замена Update | Высокий против небольшой условной пользы |
| Не применять | Замедлить весь Update/FixedUpdate | Нарушает лестницы, движение, ragdoll и callbacks | Не вопрос доступности | Не делать | Критический |
| Не применять | Снизить avoidance до 2 Hz / добавить initial staggering | Уже реализовано | Не нужно | Не делать | Лишняя работа, ложное обещание |
| Не подтверждено | NonAlloc physics, Animator hash optimization, FindObjects устранение в корнях | Соответствующие вызовы не найдены | Нет обоснования | Не делать | Ошибочное направление |

Interop-обёртки Update, FixedUpdate, UpdateObstacleAvoidance, UpdateDestination и поля доступны public. Это даёт доступ к API, но не меняет оригинальный машинный код автоматически. Для перехвата оригинального вызова нужен поддерживаемый IL2CPP detour: C# Harmony-compatible prefix может использовать native detour под капотом, без обязательного отдельного C++ DLL. Поддержка конкретной связки проверяется отдельно; патч IL тела обёртки или обычный transpiler не переписывает нативную реализацию.

## 10. Архитектура будущего модуля, только проект

1. Compatibility gate: SHA256 GameAssembly/metadata, проверка символов/сигнатур, версии MelonLoader/Interop и существующих patches. Не использовать абсолютные preferred VA как runtime адреса.
2. Observation mode по отдельному разрешению: counters числа проходов ветвей, path requests, setter calls, history mutations, измерение overhead. Preallocated buffers, без Log/ToArray/Sort в горячем цикле. Сейчас такого модуля нет.
3. Отдельные feature flags default-off: DestinationDuplicateElimination, AvoidanceWriteDedup, HistoryAverageReuse. Не выпускать все одновременно.
4. State registry на lifecycle NPC, очистка при уничтожении/смене сцены. Не один постоянный IntPtr без защиты от повторного использования адресов. Unity objects и API только main thread.
5. Каждая замена сохраняет server guard, callback ordering и результат, pending path, ladder, vehicle, ragdoll, native object lifetime. При несовместимости до изменения состояния остаётся оригинал. После частично выполненных side effects нельзя просто повторить оригинал в catch: это продублирует действие.
6. Измерения и проверка поведения отдельным этапом: host/client, движение/остановка, недостижимая цель, транспорт, лестницы, бой, ragdoll, slippery, spawn/despawn, смена сцены, отсутствие игроков, соседство границы 25. Ни один сценарий сейчас не запускался.

## 11. Риски и незавершённые границы

- Call graph частичный: direct references не покрывают callbacks, inlining, generic sharing и indirect engine calls. 205 invalid decodes в общем скане не скрыты; корневые NPC-листинги декодированы без INVALID.
- Размер Cpp2IL отличается на один байт от совокупного unwind span. Сохранены оба, не заявляется точность исходного source extent.
- Список aliases при одном адресе не обозначает семантический вызов всех этих методов. Общий ret 43FEC0 особенно опасен для ложных выводов.
- Реальная частота Update зависит от активности компонента; fixed rate не получен из запуска. Таймер 0.5 s не делает всю работу безусловной.
- Нет CPU time, p99, FPS, GC bytes/sec, количества активных NPC или измерений ноутбука. Статический размер функции не метрика стоимости.
- Не завершены полное владение путями/кэшем, все native Unity setter internals, Burst machine target, полный Animator/coroutine subgraph и все writers полей из внешних модов.

## 12. Результаты на диске

- METHOD_MAP.csv: 105 записей методов с RVA/VA/offset/length.
- FIELD_MAP.csv и evidence/related-fields.json: NPCMovement и связанные поля.
- CALL_GRAPH.md: смысловой граф с условиями и границами.
- CALL_GRAPH.dot: direct граф по RVA.
- evidence/*.asm.txt: NPC-листинги и адресные helper-исследования.
- evidence/npc-incoming.json, npc-outgoing.json, methods-all.json: адресная evidence-база.
- evidence/constants-metadata.json, method-boundaries.json, interop-access.json, analysis-summary.json.
- analyzer/: исходники воспроизводимого отдельного анализатора.
- inspect_data.py, finalize_evidence.py: проверка констант/metadata и подготовка карт.
- ../PROJECT_STATE.md: постоянная точка продолжения.

Следующий шаг без реализации: доказать границы безопасной замены UpdateDestination и составить таблицу исходов/side effects каждого пути. Если нужна приоритизация по CPU, статического исследования недостаточно: потребуется отдельно разрешённый runtime observation, без которого ни одна возможность не объявляется доказанным ускорением.
