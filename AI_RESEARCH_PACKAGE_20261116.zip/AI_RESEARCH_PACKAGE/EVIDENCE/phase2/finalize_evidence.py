import pathlib,json,struct,hashlib,re,csv
root=pathlib.Path(__file__).parent;e=root/'evidence';b=pathlib.Path(r'B:\Schedule I\GameAssembly.dll').read_bytes()
u16=lambda p:struct.unpack_from('<H',b,p)[0];u32=lambda p:struct.unpack_from('<I',b,p)[0]
pe=u32(60);opt=pe+24;secs=opt+u16(pe+20);sections=[]
for i in range(u16(pe+6)):
 p=secs+40*i;v,s,r=struct.unpack_from('<III',b,p+12);sections.append((v,s,r))
def off(r):
 for v,s,p in sections:
  if v<=r<v+s:return p+r-v
 raise ValueError(hex(r))
rv,sz=struct.unpack_from('<II',b,opt+112+3*8);unwind={}
for p in range(off(rv),off(rv)+sz,12):
 start,end,info=struct.unpack_from('<III',b,p);unwind[start]=(end,info)
ms=json.loads((e/'npc-methods.json').read_text());fields=json.loads((e/'npc-fields.json').read_text());incoming=json.loads((e/'npc-incoming.json').read_text());outgoing=json.loads((e/'npc-outgoing.json').read_text())
focus=[m for m in ms if m['Name'] in ('Update','FixedUpdate','UpdateObstacleAvoidance')]
bounds=[]
for m in focus:
 r=m['RVA'];end,info=unwind.get(r,(0,0)); segments=[{'start':hex(s),'end':hex(t),'length':t-s} for s,(t,u) in sorted(unwind.items()) if r<=s<r+m['Length']]; bounds.append({'method':m['Name'],'rva':hex(r),'preferred_va':hex(0x180000000+r),'file_offset':hex(off(r)),'cpp2il_length':m['Length'],'unwind_end_rva':hex(end),'unwind_length':end-r if end else None,'first_segment_matches_cpp2il':end-r==m['Length'],'unwind_segments':segments,'unwind_coverage_end':segments[-1]['end'] if segments else None,'sha256_method_bytes':hashlib.sha256(b[off(r):off(r)+m['Length']]).hexdigest(),'note':'Preferred VA only; actual loaded VA depends on ASLR. Unwind boundaries may exclude cold fragments.'})
(e/'method-boundaries.json').write_text(json.dumps(bounds,indent=2),encoding='utf-8')
with (root/'METHOD_MAP.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['name','signature','rva','preferred_va','file_offset','cpp2il_length_bytes']);w.writerows([[m['Name'],m['Signature'],hex(m['RVA']),hex(0x180000000+m['RVA']),hex(m['Offset']),m['Length']] for m in ms])
with (root/'FIELD_MAP.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['field','type','offset','static','literal','constant'])
 for x in fields:
  ofs=[v['Value'] for at in x['Attributes'] if at['Type'].endswith('FieldOffsetAttribute') for v in at['Fields'] if v['Name']=='Offset'];w.writerow([x['Name'],x['Type'],','.join(ofs),x['IsStatic'],x['IsLiteral'],x['Constant']])
# Preserve aliases rather than presenting all names sharing one address as executed.
rows=[]
for x in incoming:
 if any(m['RVA']==x['TargetRVA'] for m in focus):rows.append(x)
(e/'focus-incoming-direct.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
# All static direct NPC edges at RVA level; any alias remains in separate symbol table.
npc={m['RVA']:m['Name'] for m in ms};lines=['digraph NPCMovement {','rankdir=LR;','node [shape=box];']
for r,n in npc.items():lines.append(f'n{r:X} [label="{n}\\nRVA {r:X}"];')
seen=set()
for x in outgoing:
 a,c=x['FromRVA'],x['TargetRVA'];k=(a,c)
 if k in seen:continue
 seen.add(k)
 if c not in npc:
  names=x['Targets'];label=(names[0] if len(names)==1 else f'RVA {c:X}; {len(names)} aliases' if names else f'unresolved {c:X}');label=label.replace('"','').replace('\\','/');lines.append(f'n{c:X} [label="{label}",color=gray];')
 lines.append(f'n{a:X} -> n{c:X};')
lines+=['unity_update [label="Unity Update dispatch; not direct xref"];','unity_fixed [label="Unity fixed-step dispatch; not direct xref"];','unity_update -> n8FA630 [style=dashed];','unity_fixed -> n8F49E0 [style=dashed];','n8F6130 -> timer [label="InvokeRepeating literal resolved"];','timer [label="random initial 0..0.5s; repeat 0.5s"];','timer -> n8F9E20 [style=dashed];','}']
(root/'CALL_GRAPH.dot').write_text('\n'.join(lines),encoding='utf-8')
# Summarized field references are limited to known this register in the three roots.
refs={}
for name,rva,reg in [('Update',0x8FA630,'rdi'),('FixedUpdate',0x8F49E0,'rbx'),('UpdateObstacleAvoidance',0x8F9E20,'rbx')]:
 text=(e/f'{name}_{rva:X}.asm.txt').read_text();refs[name]=sorted(set(re.findall(r'\['+reg+r'\+([0-9A-Fa-f]+)h\]',text)),key=lambda x:int(x,16))
(e/'root-this-offsets.json').write_text(json.dumps(refs,indent=2),encoding='utf-8')
print(json.dumps(bounds,indent=2));print('Saved CSV maps, RVA call graph, root field offsets, direct incoming focus')
