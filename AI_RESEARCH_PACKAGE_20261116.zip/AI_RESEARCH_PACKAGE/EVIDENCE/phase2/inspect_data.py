import pathlib,struct,json,hashlib
root=pathlib.Path(__file__).parent; out=root/'evidence';b=pathlib.Path(r'B:\Schedule I\GameAssembly.dll').read_bytes();md=pathlib.Path(r'B:\Schedule I\Schedule I_Data\il2cpp_data\Metadata\global-metadata.dat').read_bytes()
u16=lambda p:struct.unpack_from('<H',b,p)[0]
u32=lambda p:struct.unpack_from('<I',b,p)[0]
pe=u32(60);n=u16(pe+6);sec=pe+24+u16(pe+20)
def offset(r):
 for i in range(n):
  p=sec+i*40;v,s,raw=struct.unpack_from('<III',b,p+12)
  if v<=r<v+s:return raw+r-v
 raise ValueError(hex(r))
constants={hex(r):struct.unpack_from('<f',b,offset(r))[0] for r in [0x2E5CB40,0x2E5DCE0,0x2E5CB44,0x2E5DA34,0x2E5D840,0x2E5CB58,0x2E5CD40]}
lo,ls,do,ds=struct.unpack_from('<IIII',md,8)
usage=[]
for r in [0x39D4388,0x3991068,0x39AF068,0x39FEE60,0x39AF3C8]:
 v=struct.unpack_from('<Q',b,offset(r))[0];kind=(v>>29)&7;idx=(v&0x1fffffff)>>1;row={'slot_rva':hex(r),'encoded':hex(v),'kind':kind,'index':idx,'encoding_note':'IL2CPP encoded metadata usage: kind bits 29..31, index shifted right one; bounds checked for string literal'}
 if kind==5:
  assert idx*8+8<=ls
  ln,di=struct.unpack_from('<II',md,lo+idx*8);assert di+ln<=ds
  row['literal']=md[do+di:do+di+ln].decode('utf-8')
 usage.append(row)
result={'constants_float32':constants,'metadata_usage':usage,'game_sha256':hashlib.sha256(b).hexdigest()}
(out/'constants-metadata.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
