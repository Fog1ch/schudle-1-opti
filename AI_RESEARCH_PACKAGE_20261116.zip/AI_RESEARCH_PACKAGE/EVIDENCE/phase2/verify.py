import pathlib,json,hashlib,csv
r=pathlib.Path(__file__).parent;game=pathlib.Path(r'B:\Schedule I');m=json.loads(pathlib.Path(r'B:\ScheduleI-PerfLab-20261115\prepared\manifest.json').read_text(encoding='utf-8-sig'));checks=[]
for rel,h in m['identity'].items():
 actual=hashlib.sha256((game/rel).read_bytes()).hexdigest();checks.append({'path':str(game/rel),'baseline_sha256':h,'current_sha256':actual,'match':actual.lower()==h.lower()})
for cfg in m['profiles'].values():
 p=game/cfg['target'];h=hashlib.sha256(p.read_bytes()).hexdigest();checks.append({'path':str(p),'match':h.lower()==cfg['before'].lower()})
for p in (r/'evidence').glob('*.json'):json.loads(p.read_text(encoding='utf-8-sig'))
for name in ['METHOD_MAP.csv','FIELD_MAP.csv']:
 with (r/name).open(encoding='utf-8-sig') as f: assert len(list(csv.reader(f)))>1
for name in ['REPORT.ru.md','CALL_GRAPH.md','CALL_GRAPH.dot']:assert (r/name).stat().st_size>100
for name in ['Update_8FA630.asm.txt','FixedUpdate_8F49E0.asm.txt','UpdateObstacleAvoidance_8F9E20.asm.txt','helper_8FA630.asm.txt','helper_8F49E0.asm.txt','helper_8F9E20.asm.txt']:assert 'INVALID' not in (r/'evidence'/name).read_text()
bounds=json.loads((r/'evidence/method-boundaries.json').read_text())
for x in bounds:
 segs=x['unwind_segments'];assert int(segs[0]['start'],16)==int(x['rva'],16)
 for a,b in zip(segs,segs[1:]):assert a['end']==b['start']
 assert int(segs[-1]['end'],16)-int(x['rva'],16)==x['cpp2il_length']+1
assert all(x['match'] for x in checks)
summary={'baseline_comparisons':checks,'json_parse':'pass','csv_and_deliverables':'pass','root_disassembly':'no INVALID in 6 root listings','unwind':'contiguous coverage, +1 trailing byte versus Cpp2IL','scope':'Does not assert a full game-directory hash; only listed identity/config files compared. No runtime profiling or patch tests.'}
(r/'VERIFICATION.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
files=[]
for p in sorted(r.rglob('*')):
 if p.is_file() and not any(x in p.parts for x in ['bin','obj']) and p.name!='MANIFEST.sha256.json':files.append({'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(r/'MANIFEST.sha256.json').write_text(json.dumps(files,indent=2),encoding='utf-8')
print('PASS: baseline DLL/metadata/config comparisons; all evidence JSON; CSV maps; six root listings; contiguous unwind coverage. Manifest entries:',len(files))
