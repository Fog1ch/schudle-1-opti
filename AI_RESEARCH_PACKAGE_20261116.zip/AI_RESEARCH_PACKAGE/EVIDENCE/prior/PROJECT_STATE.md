# Schedule I Performance Overhaul: project state

Updated: 2026-11-15. Phase 2 static research deliverables SAVED AND VERIFIED. Bounded static investigation, not complete recovery of all indirect/transitive behavior. No implementation or runtime profiling.

## Restrictions
User authorized research outputs only. Never launch game, edit original DLLs, saves or installed mods, or apply patches without a new explicit request. No external packages installed. Research analyzer and reports are separate from game and S1Perf.

## Locations
- Game: `B:\Schedule I`
- Research root: `C:\Users\herob\Documents\notion-code\work\ScheduleI-Performance-Lab-20261115`
- Prior second lab: `B:\ScheduleI-PerfLab-20261115`
- S1Perf source: `C:\Users\herob\Documents\notion-code\work\S1Perf`
- New deliverables: `phase2-npcmovement\REPORT.ru.md`, `CALL_GRAPH.md`, `CALL_GRAPH.dot`, `METHOD_MAP.csv`, `FIELD_MAP.csv`.
- Raw evidence: `phase2-npcmovement\evidence\`.
- Reproducible tools: `phase2-npcmovement\analyzer\`, `inspect_data.py`, `finalize_evidence.py`, `verify.py`.
- Verification: `phase2-npcmovement\VERIFICATION.json`, `MANIFEST.sha256.json` (252 research-file entries, excludes bin/obj).

## Context recovery
No previous PROJECT_STATE.md found under notion-code workspace or B: search. Existing REPORT.ru.md and B:\ScheduleI-PerfLab-20261115\REPORT-RU.md reviewed. Their asset/mod audit was reused, not repeated. Previous code availability audit found Cpp2IL stubs and interop wrappers, not full original source or restored Unity project. S1Perf build matches installed binary; ScheduleRu build differs. Do not blindly rebuild ScheduleRu.

## Binary identity
Unity 2022.3.62f2; game 0.4.7f12 per historical log; IL2CPP x64, D3D11.
GameAssembly SHA256: 61829050e56ca180d67be592e4bfe61ec97d2e9573f720d90a54e318a7e4381d.
Metadata SHA256: e775c97da277da8eb1a90265478f3b65c9c3d6464aff4f7255d45280a1d1181f.
Verification passed for six prior identity hashes plus boot.config and MelonPreferences.cfg baseline hashes. This is not a full game-directory integrity check.

## Phase 2 established findings
- Update RVA 0x8FA630, offset 0x8F9830, Cpp2IL length 594; full contiguous unwind span 595. Update handles OffMeshLink/ladder entry, not obstacle solver. Conditional GetComponent and two object allocations on ladder-start path, not every normal frame.
- FixedUpdate RVA 0x8F49E0, offset 0x8F3BE0, lengths 1732/1733. Server guard, UpdateStumble, UpdateDestination, sampled velocity history, slippery move, cache entry, ragdoll recovery/RPC. Critical movement/physics ticks cannot be arbitrarily skipped.
- UpdateObstacleAvoidance RVA 0x8F9E20, offset 0x8F9020, lengths 190/191. OnStartServer registers InvokeRepeating with proven metadata literal and 0.5 s repeat, random 0..0.5 s initial delay. Already 2 Hz and staggered. Do not propose this as new optimization.
- Avoidance compares distanceSquared<=625 to nearest player's Avatar.CenterPoint (MiddleSpine transform position), and enabled flag. Default enum or 0 is written every invocation. No raycast loop. GetClosestPlayerSqr traverses existing player collection, not FindObjectsOfType. If no player found, distance out remains 0; preserve that behavior unless explicitly fixing it.
- SetObstacleAvoidanceEnabled contains inlined copy of avoidance policy; OnStartClient also writes avoidance. Hooking UpdateObstacleAvoidance alone does not cover all paths. CombatBehaviour.EndCombat directly calls setter.
- Specific duplicate: UpdateDestination (RVA 0x8F9B70) final completion branch repeats transform.position + Euclidean distance at 8F9D57 and 8F9DC6 if first test fails. Candidate only; branch frequency and timing unknown. Prefer same arithmetic reused once, not unproved squared-distance replacement.
- _agent and _npc are already cached; path cache already exists. NativeArray CircularQueue default capacity 40, spacing 0.05, strict > timer means sampling is not exactly 20 Hz. Enqueue allocates nothing on inspected path. Average is BurstDirectCall with scalar fallback; actual Burst pointer unresolved. Reuse average while history unchanged is hypothesis, not safe implementation yet.
- FixedUpdate contains inline equivalents of RecordVelocity, UpdateSlippery, UpdateCache, ragdoll processing. Hooking isolated helper methods may not affect inline work.
- agent.path creates fresh NavMeshPath; corners lazily caches an array per path. Repeated corners getter does not allocate every time on same object. Cache-entry allocations conditional, not every tick. Path ownership needs deeper audit before pooling.
- No direct Physics.Raycast/Overlap loop or Animator.Set* in three roots. Physics/animation are transitive via ragdoll, ladders, seating and neighboring collision callbacks. Do not invent NonAlloc/Animator-hash targets.

## Evidence coverage and caveats
146047 address-bearing method entries, 110399 unique scanned ranges, 7541924 decoded instructions, 205 invalid-decode stops outside NPCMovement root listings. 105 NPCMovement method entries (aliases included). Graph has 441 incoming direct sites for whole NPC set, not runtime calls. All six root listings decode without INVALID. Unwind segments continuous and extend Cpp2IL lengths by one trailing byte, documented.
Direct graph does not resolve all callbacks, virtual/delegate calls, generic sharing, engine-internal calls or inlining. Shared address 0x43FEC0 is common ret/alias code, not evidence that outline rendering runs in NPC movement. Helper windows can include following function and invalid tail; do not treat window length as exact function length.

## Feasibility and continuation
Public interop methods/field access verified and saved. Interop alone cannot replace native bodies. IL2CPP-aware managed hook uses native detour underneath; ordinary IL transpiler on proxy is insufficient. For duplicate distance elimination, replace UpdateDestination only after side-effect and callback equivalence proof, not entire FixedUpdate. Avoidance dedup must account for all writers and unknown Unity setter internal cost.

Next safe static task: map every UpdateDestination outcome/side effect, callback ordering, path recalculation and inline behavior; specify proof obligations for a narrow replacement. Alternatively finish path-cache ownership/lifetime audit. Do not redo completed root disassembly unless binary identity changes.
Remaining unknowns: full indirect/Burst/Animator graph, native Unity setter cost, all external mod writers, runtime call frequencies, CPU/GC timings, visual and NPC equivalence. No measured performance gain. Runtime observation requires separate permission.


## Recovery audit checkpoint, 2026-11-15

Additional report: `phase2-npcmovement\RECOVERY_AUDIT_20261115.md`.

This recovery session reused existing evidence and did not launch Schedule I, rerun disassembly/tests, install packages, or modify game DLLs/settings/saves. The state file changed during inspection: initially it described evidence generation in progress; later it contained the saved-deliverables summary above (observed LastWriteTimeUtc 2026-11-15 22:58:19). These pre-existing/newly observed deliverables were not produced by this audit and were not overwritten. Their broad claims were not all independently reverified here.

Verified in this audit: prior C-lab historical tests are 7 unit + 7 fixture integration; B-lab separately reports 10. Do not merge the counts. Program.cs coverage/limitations and 33 symbolically unambiguous incoming edges for the focused destination/pathfinding set were reviewed. Alias/shared trivial bodies cannot be attributed solely to NPCMovement. Static callsites are not runtime frequencies.

New bounded interpretation: standalone UpdateRagdollStaticCounter resets [this+0x1B0] on ragdoll-off/blocking conditions, and adds one fixedDeltaTime only when its velocity-helper comparison passes (sites 0x8F9FBF/0x8F9FCD). UpdateRagdoll checks consciousness, counter threshold and ragdoll state; normal server/nonserver branches converge to local deactivation logic at site 0x8FA152. Therefore skipping whole ticks is not proven safe: timing and reset observations can change. Exact thresholds, unresolved flag/helper semantics and equivalence of inline FixedUpdate remain open.

Phase 2 remains PARTIAL at behavior-equivalence level. Several existing ASM files were read but their additional interpretation was interrupted by failure to reopen transferred analysis copies; Windows Terminal itself remained usable. Do not mark UpdateDestination/cache branch audit finished on that basis.

Next high-value static task: complete an outcome/side-effect/callback-order map of UpdateDestination using existing UpdateDestination_8F9B70.asm.txt, EndSetDestination_8F4490.asm.txt, IsAsCloseAsPossible_8F59C0.asm.txt, SetDestination_8F8110.asm.txt and enum/field metadata. Then audit cache ownership/invalidation. No implementation until equivalence obligations are addressed; runtime validation requires separate permission.

Only this checkpoint and the additional report were written by this recovery audit. Existing phase2 report/maps/evidence/manifests were left unchanged; old manifests do not certify the additional report.
