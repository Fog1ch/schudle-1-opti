using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Text;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using Il2CppScheduleOne.NPCs;
using MelonLoader;
using MelonLoader.Preferences;
using MelonLoader.Utils;
using Microsoft.CodeAnalysis;
using S1Perf;
using UnityEngine;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: MelonInfo(typeof(Core), "S1Perf", "1.0.0", "notion-code", null)]
[assembly: MelonGame("TVGS", "Schedule I")]
[assembly: TargetFramework(".NETCoreApp,Version=v6.0", FrameworkDisplayName = ".NET 6.0")]
[assembly: AssemblyCompany("S1Perf")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("S1Perf")]
[assembly: AssemblyTitle("S1Perf")]
[assembly: AssemblyVersion("1.0.0.0")]
[module: RefSafetyRules(11)]
namespace Microsoft.CodeAnalysis
{
	[CompilerGenerated]
	[Embedded]
	internal sealed class EmbeddedAttribute : Attribute
	{
	}
}
namespace System.Runtime.CompilerServices
{
	[CompilerGenerated]
	[Embedded]
	[AttributeUsage(AttributeTargets.Module, AllowMultiple = false, Inherited = false)]
	internal sealed class RefSafetyRulesAttribute : Attribute
	{
		public readonly int Version;

		public RefSafetyRulesAttribute(int P_0)
		{
			Version = P_0;
		}
	}
}
namespace S1Perf
{
	public class Core : MelonMod
	{
		private MelonPreferences_Category _cat;

		private MelonPreferences_Entry<bool> _animCull;

		private MelonPreferences_Entry<bool> _texStream;

		private MelonPreferences_Entry<bool> _reuseCb;

		private MelonPreferences_Entry<bool> _frameLog;

		private MelonPreferences_Entry<int> _texBudget;

		private bool _inMain;

		private float _sceneStart;

		private float _nextNpcPass;

		private float _nextReport;

		private readonly HashSet<IntPtr> _culled = new HashSet<IntPtr>();

		private int _culledCount;

		private int _npcCount;

		private readonly List<float> _ft = new List<float>(4096);

		private int _spikes;

		private int _bigSpikes;

		private float _worst;

		private string _logPath;

		public override void OnInitializeMelon()
		{
			_cat = MelonPreferences.CreateCategory("S1Perf", "S1Perf");
			_animCull = _cat.CreateEntry<bool>("NpcAnimatorOffscreenCulling", true, "Не обсчитывать кости анимации NPC вне экрана (логика/движение не меняются)", (string)null, false, false, (ValueValidator)null, (string)null);
			_texStream = _cat.CreateEntry<bool>("TextureStreaming", true, "Mip-стриминг текстур с бюджетом VRAM (только если в игре есть стримящиеся текстуры)", (string)null, false, false, (ValueValidator)null, (string)null);
			_texBudget = _cat.CreateEntry<int>("TextureBudgetMB", 2560, "Бюджет текстур, МБ (для 4 ГБ VRAM)", (string)null, false, false, (ValueValidator)null, (string)null);
			_reuseCb = _cat.CreateEntry<bool>("ReuseCollisionCallbacks", true, "Не создавать новый объект Collision на каждый контакт (меньше мусора)", (string)null, false, false, (ValueValidator)null, (string)null);
			_frameLog = _cat.CreateEntry<bool>("FrametimeReport", true, "Раз в 60 с писать сводку фреймтайма в UserData/S1Perf/frametime.log", (string)null, false, false, (ValueValidator)null, (string)null);
			string text = Path.Combine(MelonEnvironment.UserDataDirectory, "S1Perf");
			Directory.CreateDirectory(text);
			_logPath = Path.Combine(text, "frametime.log");
		}

		public override void OnSceneWasInitialized(int buildIndex, string sceneName)
		{
			_inMain = sceneName == "Main";
			_culled.Clear();
			_culledCount = 0;
			_npcCount = 0;
			_sceneStart = Time.realtimeSinceStartup;
			_nextNpcPass = _sceneStart + 8f;
			_nextReport = _sceneStart + 60f;
			ResetStats();
			if (_inMain)
			{
				Probe();
				ApplyGlobal();
			}
		}

		private void Probe()
		{
			StringBuilder sb = new StringBuilder("Probe: ");
			Try(() =>
			{
				StringBuilder stringBuilder = sb;
				StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(45, 2, stringBuilder);
				handler.AppendLiteral("autoSyncTransforms=");
				handler.AppendFormatted(Physics.autoSyncTransforms);
				handler.AppendLiteral(" reuseCollisionCallbacks=");
				handler.AppendFormatted(Physics.reuseCollisionCallbacks);
				handler.AppendLiteral(" ");
				stringBuilder.Append(ref handler);
			});
			Try(() =>
			{
				StringBuilder stringBuilder = sb;
				StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(16, 2, stringBuilder);
				handler.AppendLiteral("fixedDt=");
				handler.AppendFormatted(Time.fixedDeltaTime, "0.####");
				handler.AppendLiteral(" maxDt=");
				handler.AppendFormatted(Time.maximumDeltaTime, "0.###");
				handler.AppendLiteral(" ");
				stringBuilder.Append(ref handler);
			});
			Try(() =>
			{
				StringBuilder stringBuilder = sb;
				StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(40, 3, stringBuilder);
				handler.AppendLiteral("streamingMips=");
				handler.AppendFormatted(QualitySettings.streamingMipmapsActive);
				handler.AppendLiteral(" streamTex=");
				handler.AppendFormatted(Texture.streamingTextureCount);
				handler.AppendLiteral(" nonStreamTex=");
				handler.AppendFormatted(Texture.nonStreamingTextureCount);
				handler.AppendLiteral(" ");
				stringBuilder.Append(ref handler);
			});
			Try(() =>
			{
				StringBuilder stringBuilder = sb;
				StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(34, 4, stringBuilder);
				handler.AppendLiteral("vSync=");
				handler.AppendFormatted(QualitySettings.vSyncCount);
				handler.AppendLiteral(" targetFps=");
				handler.AppendFormatted(Application.targetFrameRate);
				handler.AppendLiteral(" queued=");
				handler.AppendFormatted(QualitySettings.maxQueuedFrames);
				handler.AppendLiteral(" quality=");
				handler.AppendFormatted(QualitySettings.GetQualityLevel());
				stringBuilder.Append(ref handler);
			});
			((MelonBase)this).LoggerInstance.Msg(sb.ToString());
		}

		private void ApplyGlobal()
		{
			if (_reuseCb.Value)
			{
				Try(() =>
				{
					if (!Physics.reuseCollisionCallbacks)
					{
						Physics.reuseCollisionCallbacks = true;
						((MelonBase)this).LoggerInstance.Msg("reuseCollisionCallbacks -> true");
					}
				});
			}
			if (!_texStream.Value)
			{
				return;
			}
			Try(() =>
			{
				if (Texture.streamingTextureCount != 0)
				{
					QualitySettings.streamingMipmapsActive = true;
					QualitySettings.streamingMipmapsAddAllCameras = true;
					QualitySettings.streamingMipmapsMemoryBudget = Math.Max(1024, _texBudget.Value);
					QualitySettings.streamingMipmapsMaxLevelReduction = 2;
					((MelonBase)this).LoggerInstance.Msg($"Texture streaming ON, budget {_texBudget.Value} MB ({Texture.streamingTextureCount} textures)");
				}
				else
				{
					((MelonBase)this).LoggerInstance.Msg("Texture streaming: в сборке нет стримящихся текстур — пропуск");
				}
			});
		}

		public override void OnUpdate()
		{
			if (_inMain)
			{
				float realtimeSinceStartup = Time.realtimeSinceStartup;
				if (_animCull.Value && realtimeSinceStartup >= _nextNpcPass)
				{
					_nextNpcPass = realtimeSinceStartup + 30f;
					NpcPass();
				}
				if (_frameLog.Value)
				{
					Track(realtimeSinceStartup);
				}
			}
		}

		private void NpcPass()
		{
			//IL_0088: Unknown result type (might be due to invalid IL or missing references)
			try
			{
				Il2CppArrayBase<NPC> val = Object.FindObjectsOfType<NPC>();
				if (val == null)
				{
					return;
				}
				_npcCount = val.Length;
				int culledCount = _culledCount;
				for (int i = 0; i < val.Length; i++)
				{
					NPC val2 = val[i];
					if ((Object)(object)val2 == (Object)null)
					{
						continue;
					}
					Il2CppArrayBase<Animator> componentsInChildren = ((Component)val2).GetComponentsInChildren<Animator>(true);
					if (componentsInChildren == null)
					{
						continue;
					}
					for (int j = 0; j < componentsInChildren.Length; j++)
					{
						Animator val3 = componentsInChildren[j];
						if ((Object)(object)val3 == (Object)null)
						{
							continue;
						}
						IntPtr pointer = ((Il2CppObjectBase)val3).Pointer;
						if (!_culled.Contains(pointer))
						{
							_culled.Add(pointer);
							if ((int)val3.cullingMode == 0)
							{
								val3.cullingMode = (AnimatorCullingMode)1;
								_culledCount++;
							}
						}
					}
				}
				if (_culledCount != culledCount)
				{
					((MelonBase)this).LoggerInstance.Msg($"NPC: {_npcCount}, аниматоров переведено в offscreen-culling: {_culledCount}");
				}
			}
			catch (Exception ex)
			{
				((MelonBase)this).LoggerInstance.Warning("NpcPass: " + ex.Message);
				_animCull.Value = false;
			}
		}

		private void ResetStats()
		{
			_ft.Clear();
			_spikes = 0;
			_bigSpikes = 0;
			_worst = 0f;
		}

		private void Track(float now)
		{
			float num = Time.unscaledDeltaTime * 1000f;
			if (now - _sceneStart < 15f)
			{
				return;
			}
			_ft.Add(num);
			if (num > _worst)
			{
				_worst = num;
			}
			if (num > 50f)
			{
				_spikes++;
			}
			if (num > 100f)
			{
				_bigSpikes++;
			}
			if (now < _nextReport)
			{
				return;
			}
			_nextReport = now + 60f;
			if (_ft.Count != 0)
			{
				float[] array = _ft.ToArray();
				Array.Sort(array);
				float num2 = 0f;
				float[] array2 = array;
				foreach (float num3 in array2)
				{
					num2 += num3;
				}
				num2 /= (float)array.Length;
				float value = array[array.Length / 2];
				float value2 = array[Math.Min(array.Length - 1, (int)((float)array.Length * 0.99f))];
				float num4 = array[Math.Min(array.Length - 1, (int)((float)array.Length * 0.99f))];
				string text = $"{DateTime.Now:HH:mm:ss} frames={array.Length} avgFps={1000f / num2:0.0} p50={value:0.0}ms p99={value2:0.0}ms (1%low {1000f / num4:0.0} fps) worst={_worst:0.0}ms spikes>50ms={_spikes} >100ms={_bigSpikes} npc={_npcCount}";
				try
				{
					File.AppendAllText(_logPath, text + "\n");
				}
				catch
				{
				}
				ResetStats();
			}
		}

		private void Try(Action a)
		{
			try
			{
				a();
			}
			catch (Exception ex)
			{
				((MelonBase)this).LoggerInstance.Warning(ex.GetType().Name + ": " + ex.Message);
			}
		}
	}
}
