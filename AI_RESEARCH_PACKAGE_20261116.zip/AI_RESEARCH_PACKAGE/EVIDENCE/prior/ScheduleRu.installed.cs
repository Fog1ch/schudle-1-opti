using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;
using System.Text;
using System.Text.RegularExpressions;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using Il2CppSystem.Collections.Generic;
using Il2CppTMPro;
using MelonLoader;
using MelonLoader.Preferences;
using MelonLoader.Utils;
using Microsoft.CodeAnalysis;
using ScheduleRu;
using UnityEngine;
using UnityEngine.TextCore.LowLevel;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: MelonInfo(typeof(Core), "ScheduleRu", "1.0.0", "notion-code", null)]
[assembly: MelonGame("TVGS", "Schedule I")]
[assembly: TargetFramework(".NETCoreApp,Version=v6.0", FrameworkDisplayName = ".NET 6.0")]
[assembly: AssemblyCompany("ScheduleRu")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("ScheduleRu")]
[assembly: AssemblyTitle("ScheduleRu")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
[assembly: AssemblyVersion("1.0.0.0")]
[module: UnverifiableCode]
[module: RefSafetyRules(11)]
namespace Microsoft.CodeAnalysis
{
	[CompilerGenerated]
	[Embedded]
	internal sealed class EmbeddedAttribute : Attribute
	{
	}
}
namespace System.Runtime.CompilerServices
{
	[CompilerGenerated]
	[Embedded]
	[AttributeUsage(AttributeTargets.Module, AllowMultiple = false, Inherited = false)]
	internal sealed class RefSafetyRulesAttribute : Attribute
	{
		public readonly int Version;

		public RefSafetyRulesAttribute(int P_0)
		{
			Version = P_0;
		}
	}
}
namespace ScheduleRu
{
	public class Core : MelonMod
	{
		private static readonly Dictionary<string, string> Dict = new Dictionary<string, string>(StringComparer.Ordinal);

		private static readonly List<KeyValuePair<Regex, string>> Rx = new List<KeyValuePair<Regex, string>>();

		private static readonly HashSet<string> Missing = new HashSet<string>(StringComparer.Ordinal);

		private static readonly List<string> MissingQueue = new List<string>();

		private static readonly Dictionary<IntPtr, string> LastSeen = new Dictionary<IntPtr, string>();

		private static readonly HashSet<IntPtr> PatchedFonts = new HashSet<IntPtr>();

		private static readonly Regex Clock = new Regex("^(\\d{1,2}):(\\d{2}) ?(AM|PM)(?: (Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday))?$", RegexOptions.Compiled);

		private static readonly Dictionary<string, string> Days = new Dictionary<string, string>
		{
			{ "Monday", "понедельник" },
			{ "Tuesday", "вторник" },
			{ "Wednesday", "среда" },
			{ "Thursday", "четверг" },
			{ "Friday", "пятница" },
			{ "Saturday", "суббота" },
			{ "Sunday", "воскресенье" }
		};

		private readonly List<TMP_Text> _cache = new List<TMP_Text>();

		private readonly List<IntPtr> _ptrs = new List<IntPtr>();

		private readonly HashSet<IntPtr> _known = new HashSet<IntPtr>();

		private readonly Queue<int> _fresh = new Queue<int>();

		private readonly List<Canvas> _canvases = new List<Canvas>();

		private int _cursor;

		private int _canvasCursor;

		private int _fullInScene;

		private float _nextCanvasList;

		private float _nextCanvasScan;

		private float _nextFull;

		private float _fontRetry;

		private bool _fontReady;

		private TMP_FontAsset _fallback;

		private Font _osFontObj;

		private string _dir;

		private string _missingPath;

		private MelonPreferences_Category _cat;

		private MelonPreferences_Entry<bool> _enabled;

		private MelonPreferences_Entry<bool> _dumpMissing;

		private MelonPreferences_Entry<bool> _fontFix;

		private MelonPreferences_Entry<int> _perFrame;

		private MelonPreferences_Entry<float> _refresh;

		private MelonPreferences_Entry<float> _fullEvery;

		private MelonPreferences_Entry<float> _canvasEvery;

		private MelonPreferences_Entry<string> _osFont;

		public override void OnInitializeMelon()
		{
			_cat = MelonPreferences.CreateCategory("ScheduleRu", "ScheduleRu");
			_enabled = _cat.CreateEntry<bool>("Enabled", true, "Включить перевод TMP", (string)null, false, false, (ValueValidator)null, (string)null);
			_fontFix = _cat.CreateEntry<bool>("CyrillicFallbackFont", true, "Подключать кириллический fallback-шрифт", (string)null, false, false, (ValueValidator)null, (string)null);
			_osFont = _cat.CreateEntry<string>("OsFontName", "Arial", "Системный шрифт с кириллицей", (string)null, false, false, (ValueValidator)null, (string)null);
			_perFrame = _cat.CreateEntry<int>("TextsPerFrame", 48, "Сколько TMP-текстов проверять за кадр", (string)null, false, false, (ValueValidator)null, (string)null);
			_refresh = _cat.CreateEntry<float>("RescanSeconds", 1.5f, "(устарело, не используется) старый интервал полного скана", (string)null, false, false, (ValueValidator)null, (string)null);
			_fullEvery = _cat.CreateEntry<float>("FullRescanSeconds", 20f, "Полный скан сцены (для 3D-текстов), с; 0 = только при загрузке сцены", (string)null, false, false, (ValueValidator)null, (string)null);
			_canvasEvery = _cat.CreateEntry<float>("CanvasScanInterval", 0.05f, "Пауза между проверками канвасов UI (по одному за раз), с", (string)null, false, false, (ValueValidator)null, (string)null);
			_dumpMissing = _cat.CreateEntry<bool>("DumpUntranslated", true, "Записывать непереведённые строки", (string)null, false, false, (ValueValidator)null, (string)null);
			_dir = Path.Combine(MelonEnvironment.UserDataDirectory, "ScheduleRu");
			Directory.CreateDirectory(_dir);
			_missingPath = Path.Combine(_dir, "untranslated.txt");
			LoadAll();
			((MelonBase)this).LoggerInstance.Msg($"Словарь: {Dict.Count} строк, {Rx.Count} шаблонов");
		}

		private void LoadAll()
		{
			string gameRootDirectory = MelonEnvironment.GameRootDirectory;
			string path = Path.Combine(gameRootDirectory, "AutoTranslator", "Translation", "ru", "Text");
			string[] files;
			if (Directory.Exists(path))
			{
				files = Directory.GetFiles(path, "*.txt");
				for (int i = 0; i < files.Length; i++)
				{
					LoadFile(files[i]);
				}
			}
			files = Directory.GetFiles(_dir, "*.txt");
			foreach (string text in files)
			{
				if (!text.EndsWith("untranslated.txt", StringComparison.OrdinalIgnoreCase))
				{
					LoadFile(text);
				}
			}
			if (!File.Exists(_missingPath))
			{
				return;
			}
			files = File.ReadAllLines(_missingPath, Encoding.UTF8);
			foreach (string text2 in files)
			{
				int num = FindSep(text2);
				if (num > 0)
				{
					Missing.Add(Unescape(text2.Substring(0, num)));
				}
			}
		}

		private static void LoadFile(string path)
		{
			string fileName = Path.GetFileName(path);
			if (fileName.StartsWith("_Pre") || fileName.StartsWith("_Post") || fileName.StartsWith("_Sub"))
			{
				return;
			}
			string[] array = File.ReadAllLines(path, Encoding.UTF8);
			for (int i = 0; i < array.Length; i++)
			{
				string text = array[i].TrimEnd('\r');
				if (text.Length == 0 || text.StartsWith("//"))
				{
					continue;
				}
				int num = FindSep(text);
				if (num <= 0)
				{
					continue;
				}
				string text2 = text.Substring(0, num);
				string text3 = Unescape(text.Substring(num + 1));
				if (text3.Length == 0)
				{
					continue;
				}
				if (text2.StartsWith("r:\"") && text2.EndsWith("\""))
				{
					try
					{
						Rx.Add(new KeyValuePair<Regex, string>(new Regex(text2.Substring(3, text2.Length - 4), RegexOptions.Compiled), text3));
					}
					catch
					{
					}
				}
				else if (!text2.StartsWith("sr:"))
				{
					Dict[Unescape(text2)] = text3;
				}
			}
		}

		private static int FindSep(string s)
		{
			for (int i = 0; i < s.Length; i++)
			{
				if (s[i] == '\\')
				{
					i++;
				}
				else if (s[i] == '=')
				{
					return i;
				}
			}
			return -1;
		}

		private static string Unescape(string s)
		{
			if (s.IndexOf('\\') < 0)
			{
				return s;
			}
			StringBuilder stringBuilder = new StringBuilder(s.Length);
			for (int i = 0; i < s.Length; i++)
			{
				char c = s[i];
				if (c == '\\' && i + 1 < s.Length)
				{
					char c2 = s[++i];
					StringBuilder stringBuilder2 = stringBuilder;
					stringBuilder2.Append(c2 switch
					{
						'n' => '\n', 
						'r' => '\r', 
						't' => '\t', 
						_ => c2, 
					});
				}
				else
				{
					stringBuilder.Append(c);
				}
			}
			return stringBuilder.ToString();
		}

		private static string Escape(string s)
		{
			return s.Replace("\\", "\\\\").Replace("=", "\\=").Replace("\n", "\\n")
				.Replace("\r", "\\r");
		}

		private static bool HasLatin(string s)
		{
			foreach (char c in s)
			{
				if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))
				{
					return true;
				}
			}
			return false;
		}

		private static bool HasCyrillic(string s)
		{
			foreach (char c in s)
			{
				if (c >= 'Ѐ' && c <= 'ӿ')
				{
					return true;
				}
			}
			return false;
		}

		private static string Translate(string s)
		{
			if (Dict.TryGetValue(s, out var value))
			{
				return value;
			}
			string text = s.Trim();
			if (text.Length != s.Length && text.Length > 0 && Dict.TryGetValue(text, out value))
			{
				return s.Replace(text, value);
			}
			Match match = Clock.Match(text);
			if (match.Success)
			{
				int num = int.Parse(match.Groups[1].Value) % 12;
				if (match.Groups[3].Value == "PM")
				{
					num += 12;
				}
				string text2 = $"{num:00}:{match.Groups[2].Value}";
				if (match.Groups[4].Success)
				{
					text2 = text2 + ", " + Days[match.Groups[4].Value];
				}
				return s.Replace(text, text2);
			}
			foreach (KeyValuePair<Regex, string> item in Rx)
			{
				if (item.Key.IsMatch(text))
				{
					return s.Replace(text, item.Key.Replace(text, item.Value));
				}
			}
			return null;
		}

		public override void OnSceneWasInitialized(int buildIndex, string sceneName)
		{
			FlushMissing();
			_cache.Clear();
			_ptrs.Clear();
			_known.Clear();
			_fresh.Clear();
			_canvases.Clear();
			LastSeen.Clear();
			_cursor = 0;
			_canvasCursor = 0;
			_fullInScene = 0;
			float realtimeSinceStartup = Time.realtimeSinceStartup;
			_nextFull = realtimeSinceStartup + 0.5f;
			_nextCanvasList = realtimeSinceStartup + 0.25f;
		}

		public override void OnApplicationQuit()
		{
			FlushMissing();
		}

		private void FlushMissing()
		{
			if (MissingQueue.Count == 0)
			{
				return;
			}
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				foreach (string item in MissingQueue)
				{
					stringBuilder.Append(Escape(item)).Append("=\n");
				}
				File.AppendAllText(_missingPath, stringBuilder.ToString(), Encoding.UTF8);
			}
			catch
			{
			}
			MissingQueue.Clear();
		}

		private void Track(TMP_Text t)
		{
			if (!((Object)(object)t == (Object)null))
			{
				IntPtr pointer = ((Il2CppObjectBase)t).Pointer;
				if (_known.Add(pointer))
				{
					_cache.Add(t);
					_ptrs.Add(pointer);
					_fresh.Enqueue(_cache.Count - 1);
				}
			}
		}

		private void RemoveAt(int i)
		{
			IntPtr intPtr = _ptrs[i];
			_known.Remove(intPtr);
			LastSeen.Remove(intPtr);
			int index = _cache.Count - 1;
			_cache[i] = _cache[index];
			_ptrs[i] = _ptrs[index];
			_cache.RemoveAt(index);
			_ptrs.RemoveAt(index);
		}

		public override void OnUpdate()
		{
			if (!_enabled.Value)
			{
				return;
			}
			float realtimeSinceStartup = Time.realtimeSinceStartup;
			if (_fontFix.Value && !_fontReady && realtimeSinceStartup >= _fontRetry)
			{
				EnsureFont(realtimeSinceStartup);
			}
			if (realtimeSinceStartup >= _nextFull)
			{
				FullScan();
				_fullInScene++;
				float value = _fullEvery.Value;
				ref float nextFull = ref _nextFull;
				float num;
				if (_fullInScene == 1)
				{
					num = realtimeSinceStartup + 2.5f;
				}
				else
				{
					num = ((value > 0f) ? (realtimeSinceStartup + Math.Max(5f, value)) : float.MaxValue);
				}
				nextFull = num;
			}
			if (realtimeSinceStartup >= _nextCanvasList)
			{
				_nextCanvasList = realtimeSinceStartup + 1f;
				RefreshCanvases();
			}
			if (_canvases.Count > 0 && realtimeSinceStartup >= _nextCanvasScan)
			{
				_nextCanvasScan = realtimeSinceStartup + Math.Max(0f, _canvasEvery.Value);
				if (_canvasCursor >= _canvases.Count)
				{
					_canvasCursor = 0;
				}
				Canvas val = _canvases[_canvasCursor++];
				try
				{
					if ((Object)(object)val != (Object)null && ((Behaviour)val).isActiveAndEnabled)
					{
						Il2CppArrayBase<TMP_Text> componentsInChildren = ((Component)val).GetComponentsInChildren<TMP_Text>(false);
						if (componentsInChildren != null)
						{
							for (int i = 0; i < componentsInChildren.Length; i++)
							{
								Track(componentsInChildren[i]);
							}
						}
					}
				}
				catch
				{
				}
			}
			int num2 = Math.Max(1, _perFrame.Value);
			while (num2 > 0 && _fresh.Count > 0)
			{
				int num3 = _fresh.Dequeue();
				if (num3 < _cache.Count)
				{
					num2--;
					Step(num3);
				}
			}
			int num4 = Math.Min(_cache.Count, num2 * 4);
			for (int j = 0; j < num4 && num2 > 0 && _cache.Count > 0; j++)
			{
				if (_cursor >= _cache.Count)
				{
					_cursor = 0;
				}
				int num5 = _cursor++;
				TMP_Text val2 = _cache[num5];
				if ((Object)(object)val2 == (Object)null || ((Il2CppObjectBase)val2).WasCollected)
				{
					RemoveAt(num5);
					_cursor = num5;
					continue;
				}
				bool isActiveAndEnabled;
				try
				{
					isActiveAndEnabled = ((Behaviour)val2).isActiveAndEnabled;
				}
				catch
				{
					RemoveAt(num5);
					_cursor = num5;
					continue;
				}
				if (isActiveAndEnabled)
				{
					num2--;
					Step(num5);
				}
			}
			if (_dumpMissing.Value && MissingQueue.Count >= 200)
			{
				FlushMissing();
			}
		}

		private void Step(int i)
		{
			TMP_Text val = _cache[i];
			try
			{
				if ((Object)(object)val == (Object)null || ((Il2CppObjectBase)val).WasCollected)
				{
					RemoveAt(i);
				}
				else
				{
					Process(val);
				}
			}
			catch
			{
			}
		}

		private void RefreshCanvases()
		{
			try
			{
				_canvases.Clear();
				Il2CppArrayBase<Canvas> val = Object.FindObjectsOfType<Canvas>();
				if (val != null)
				{
					for (int i = 0; i < val.Length; i++)
					{
						Canvas val2 = val[i];
						if ((Object)(object)val2 != (Object)null && val2.isRootCanvas)
						{
							_canvases.Add(val2);
						}
					}
				}
				if (_canvasCursor >= _canvases.Count)
				{
					_canvasCursor = 0;
				}
			}
			catch (Exception ex)
			{
				((MelonBase)this).LoggerInstance.Warning("Canvases: " + ex.Message);
			}
		}

		private void FullScan()
		{
			try
			{
				Il2CppArrayBase<TMP_Text> val = Object.FindObjectsOfType<TMP_Text>();
				if (val != null)
				{
					for (int i = 0; i < val.Length; i++)
					{
						Track(val[i]);
					}
				}
			}
			catch (Exception ex)
			{
				((MelonBase)this).LoggerInstance.Warning("FullScan: " + ex.Message);
			}
		}

		private void Process(TMP_Text t)
		{
			IntPtr pointer = ((Il2CppObjectBase)t).Pointer;
			if ((Object)(object)_fallback != (Object)null)
			{
				TMP_FontAsset font = t.font;
				if ((Object)(object)font != (Object)null && !PatchedFonts.Contains(((Il2CppObjectBase)font).Pointer))
				{
					AttachFallback(font);
				}
			}
			string text = t.text;
			if (string.IsNullOrEmpty(text) || (LastSeen.TryGetValue(pointer, out var value) && value == text))
			{
				return;
			}
			if (!HasLatin(text) || HasCyrillic(text))
			{
				LastSeen[pointer] = text;
				return;
			}
			string text2 = Translate(text);
			if (text2 != null && text2 != text)
			{
				t.text = text2;
				LastSeen[pointer] = text2;
				return;
			}
			LastSeen[pointer] = text;
			if (_dumpMissing.Value && text.Length < 2000 && Missing.Count < 50000 && Missing.Add(text))
			{
				MissingQueue.Add(text);
			}
		}

		private void EnsureFont(float now)
		{
			_fontRetry = now + 5f;
			try
			{
				string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.Fonts);
				string[] array = new string[5]
				{
					_osFont.Value + ".ttf",
					"arial.ttf",
					"segoeui.ttf",
					"tahoma.ttf",
					"verdana.ttf"
				};
				foreach (string text in array)
				{
					string text2 = (Path.IsPathRooted(text) ? text : Path.Combine(folderPath, text));
					if (File.Exists(text2))
					{
						try
						{
							_fallback = TMP_FontAsset.CreateFontAsset(text2, 0, 90, 9, (GlyphRenderMode)4165, 1024, 1024, (AtlasPopulationMode)1, true);
						}
						catch (Exception ex)
						{
							((MelonBase)this).LoggerInstance.Warning("Шрифт " + text + ": " + ex.Message);
						}
						if ((Object)(object)_fallback != (Object)null)
						{
							break;
						}
					}
				}
				if ((Object)(object)_fallback == (Object)null)
				{
					try
					{
						_fallback = TMP_FontAsset.CreateFontAsset(_osFont.Value, "Regular", 90);
					}
					catch (Exception ex2)
					{
						((MelonBase)this).LoggerInstance.Warning("Шрифт (family): " + ex2.Message);
					}
				}
				if (!((Object)(object)_fallback == (Object)null))
				{
					((Object)_fallback).name = "ScheduleRu Cyrillic Fallback";
					((Object)_fallback).hideFlags = (HideFlags)32;
					List<TMP_FontAsset> fallbackFontAssets = TMP_Settings.fallbackFontAssets;
					if (fallbackFontAssets != null && !fallbackFontAssets.Contains(_fallback))
					{
						fallbackFontAssets.Add(_fallback);
					}
					_fontReady = true;
					((MelonBase)this).LoggerInstance.Msg("Кириллический fallback-шрифт подключён (" + _osFont.Value + ")");
				}
			}
			catch (Exception ex3)
			{
				((MelonBase)this).LoggerInstance.Warning("Шрифт: " + ex3.Message);
			}
		}

		private void AttachFallback(TMP_FontAsset f)
		{
			PatchedFonts.Add(((Il2CppObjectBase)f).Pointer);
			if (((Il2CppObjectBase)f).Pointer == ((Il2CppObjectBase)_fallback).Pointer)
			{
				return;
			}
			try
			{
				List<TMP_FontAsset> val = f.fallbackFontAssetTable;
				if (val == null)
				{
					val = (f.fallbackFontAssetTable = new List<TMP_FontAsset>());
				}
				if (!val.Contains(_fallback))
				{
					val.Add(_fallback);
				}
			}
			catch
			{
			}
		}
	}
}
