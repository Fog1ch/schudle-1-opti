# Архитектура и связи

## Native Player и IL2CPP
Unity 2022.3.62f2 подтверждается предыдущим аудитом Player/контейнеров; девять контейнеров повторно сообщают эту версию. Game 0.4.7f12 и MelonLoader 0.7.3 Open-Beta происходят из исторического журнала, не проверки обновлений Steam. Текущий gate: SHA-256 оригинальных файлов.

Schedule I.exe загружает UnityPlayer; GameAssembly.dll содержит native IL2CPP code. global-metadata.dat имеет magic 0xFAB11BAF и version 31. Это не доказательство отсутствия защит во всём файле. PE image base 0x180000000; RVA, file offsets и sections: [PE layout](EVIDENCE/current/pe-layout.json).

Cpp2IL output содержит восстановленные типы/атрибуты Address/FieldOffset и заглушки. MelonLoader/Il2CppAssemblies содержит Interop proxies. Ни тот, ни другой слой не заменяет реальные machine bodies. Методы интерпретируются совместно с native listings.

## Основные связи
- NPCMovement → Unity NavMeshAgent/Path → Unity native engine; ragdoll → Rigidbody/ConstantForce; network guards/RPC → FishNet.
- NPCAnimation → AvatarAnimation → AvatarAnimationId → integer Animator API. IK/standup/bones связаны с ragdoll и visibility.
- TimeManager → ActionList staggered callbacks; NPC schedules и world simulation подписываются на события. Полный dispatch graph не восстановлен.
- Plant.MinPass → GrowContainer light/moisture → Grid.Tile → LightExposureNode. Это simulation lighting, не GPU pass.
- ShadowLODController → PlayerCamera movement events → distance policy → Light.shadows, запись только при смене mode.
- LoadManager coroutine → SceneManager.LoadSceneAsync → LoadRequest/events/network readiness; CleanUp → GUID/NavMeshUtility caches.
- Mods → MelonLoader/.NET runtime → Il2CppInterop → IL2CPP-aware hooks/proxies. Actual patch order не установлен.

## Ресурсы
Serialized scene files level0/1/2 используют sharedassets/resources containers. .resS/.resource хранят внешние payloads. External reference index связывает containers, но не доказывает наличие всех объектных PPtr edges. `Library/unity default resources` является специальным engine reference, не обязательным физическим путём под игрой.

URP, AmplifyImpostors, Astar, RootMotion, TextMeshPro и FishNet присутствуют в assembly indices. Наличие сборки/кода не равно активному компоненту сцены. Experimental OcclusionManager не объявляется включённым.

[Assembly references](EVIDENCE/current/assembly-index.json), [managed/interop layers](EVIDENCE/current/managed-interop-assembly-index.json), [type inheritance](EVIDENCE/current/types.jsonl), [asset dependencies](CALL_GRAPHS/ASSET_DEPENDENCIES.dot).
