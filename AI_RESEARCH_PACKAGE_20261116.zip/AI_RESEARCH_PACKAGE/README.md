# AI Research Package

[Overview](PROJECT_OVERVIEW.md) • [State](PROJECT_STATE.md) • [Handoff prompt](HANDOFF_PROMPT.md) • [Findings](REVERSE_ENGINEERING/FINDINGS.md) • [Open questions](OPEN_QUESTIONS.md) • [Risks](RISKS.md)

Read documents and included evidence offline. Verify with `python ANALYZERS/offline_query.py verify .`. No MCP, game, network or package installation is needed for that verification/query.

This is a bounded static research package, not the entire game source or a measured performance improvement. Runtime/GPU and unextracted functions require explicitly requested additional evidence.

Full file listing: [CREATED_FILES.txt](CREATED_FILES.txt). Integrity: [FILE_MANIFEST.json](FILE_MANIFEST.json), [QA_REPORT.json](QA_REPORT.json).
