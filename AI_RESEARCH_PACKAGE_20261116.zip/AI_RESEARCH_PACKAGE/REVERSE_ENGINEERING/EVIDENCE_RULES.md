# Правила достоверности

CONFIRMED_STATIC: bytes/IL/metadata прямо подтверждают ограниченный вывод. HISTORICAL: прежний журнал или отчёт, не новый runtime. HYPOTHESIS: возможная стоимость/оптимизация. UNKNOWN: нет достаточного evidence.

Native edge означает machine call или внешнюю jump instruction в выбранном range. Не call frequency, не полный CFG. Косвенные вызовы, Unity callbacks и inlining требуют дополнительной карты. Cpp2IL Length не доказанная граница исходной функции. В phase2 сохранён unwind audit +1 byte для корней; новые roots такой общей гарантии не имеют.

Aliases по RVA неоднозначны. Даже единственное именованное попадание может быть generic representative (пример delegate constructor с именем IsBurstEnabledDelegate в обычной coroutine); не утверждать Burst activation из этого имени. Shared ret 0x43FEC0 не вызов всех aliased подсистем. Автоматический root-summary показывает адресные метки, не окончательное семантическое толкование.

Сигнатуры/поля stubs и interop не являются восстановленными C# bodies. Предпочтительный VA не runtime VA. Native hex в листингах есть RVA, если не указано иное.

Serialized tables проверены на bounds/type indices; extension external refs не прошёл независимую проверку зрелым asset reader. Candidate m_Name получен эвристикой начала payload. ClassID и offsets надёжнее candidate name. Нет доказательства active renderer/pipeline по одному assembly name.

Уровень полноты указан в SUBSYSTEMS. Не путать завершённую поставку пакета с полным reverse engineering игры. Для новых данных использовать [reproduction guide](REPRODUCTION.md).
