# Подтверждённые статические находки

## F01: EndSetDestination invokes callback before clearing callback/destination state

[Evidence](../EVIDENCE/phase2/evidence/EndSetDestination_8F4490.asm.txt). Статический вывод ограничен приведённым методом/таблицей; runtime frequency и ускорение не измерены.

## F02: AvatarAnimationId has cache-hit return; StringToHash is on miss path

[Evidence](../EVIDENCE/current/native/7C51B0.asm.txt). Статический вывод ограничен приведённым методом/таблицей; runtime frequency и ускорение не измерены.

## F03: ShadowLODController skips setter loop when applied mode matches

[Evidence](../EVIDENCE/current/native/723040.asm.txt). Статический вывод ограничен приведённым методом/таблицей; runtime frequency и ускорение не измерены.

## F04: TimeManager tick coroutine directly calls staggered ActionList

[Evidence](../EVIDENCE/current/native/9CE410.asm.txt). Статический вывод ограничен приведённым методом/таблицей; runtime frequency и ускорение не измерены.

## F05: AddPath stores input path pointer in entry

[Evidence](../EVIDENCE/current/native/8FB4A0.asm.txt). Статический вывод ограничен приведённым методом/таблицей; runtime frequency и ускорение не измерены.

## F06: GetPath returns retained path reference from matching entry

[Evidence](../EVIDENCE/current/native/8FB5B0.asm.txt). Статический вывод ограничен приведённым методом/таблицей; runtime frequency и ускорение не измерены.

## F07: GrowContainer light loop uses Grid and LightExposureNode

[Evidence](../EVIDENCE/current/native/7E4BB0.asm.txt). Статический вывод ограничен приведённым методом/таблицей; runtime frequency и ускорение не измерены.

## F08: Two installed mods declare PackagerConfiguration.ShouldSave targets

[Evidence](../EVIDENCE/current/mod-target-overlaps.json). Статический вывод ограничен приведённым методом/таблицей; runtime frequency и ускорение не измерены.

## F09: LoadManager load routine has LoadSceneAsync call

[Evidence](../EVIDENCE/current/native/590A80.asm.txt). Статический вывод ограничен приведённым методом/таблицей; runtime frequency и ускорение не измерены.

## F10: PhysicsManager gravity RPC writes Physics.gravity

[Evidence](../EVIDENCE/current/native/58B420.asm.txt). Статический вывод ограничен приведённым методом/таблицей; runtime frequency и ускорение не измерены.

## F11: NPC animation routes local velocity to SetMotion and animation parameters

[Evidence](../EVIDENCE/current/native/8E9870.asm.txt). Статический вывод ограничен приведённым методом/таблицей; runtime frequency и ускорение не измерены.

## F12: Container dependency table includes level1 sharedassets links

[Evidence](../EVIDENCE/current/asset-containers-current.json). Статический вывод ограничен приведённым методом/таблицей; runtime frequency и ускорение не измерены.

Предыдущие подтверждённые NPC результаты сохранены в [phase2 report](../EVIDENCE/phase2/REPORT.ru.md). Старые claims не объявляются новыми.
