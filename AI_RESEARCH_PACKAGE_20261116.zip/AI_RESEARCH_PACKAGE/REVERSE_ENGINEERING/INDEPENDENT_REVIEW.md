# Независимый read-only review и исправления

Проверены NPC_DESTINATION_CONTRACT против UpdateDestination/EndSetDestination, HANDOFF_PROMPT, ANALYZERS README и evidence rules. Reviewer не выполнял игру, не изменял файлы и не подтверждал весь package QA.

Приняты исправления:
- SetDestination call не объявляется обязательным новым path request.
- Callback-before-clear уточнён как normal-return path; исключения отдельно неизвестны.
- Helper 0x316AB0 назван адресом, а не заново доказанной write barrier.
- Добавлена прямая ссылка на ранее существовавший helper_456100 с sqrtpd. Это закрывает замечание о недостаточности одного caller listing для Euclidean distance.

Подтверждены strict threshold comparison и условный ResetPath/clear только при hasPath. Реентерабельность остаётся гипотезой/обязательством проверки.

Машинный QA отдельно проверяет evidence anchors, links, manifest и исходные хэши; не доказывает полноту reverse engineering или runtime equivalence.
