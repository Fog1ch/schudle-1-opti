# UpdateDestination: границы безопасной замены

Источник: [листинг UpdateDestination](../EVIDENCE/phase2/evidence/UpdateDestination_8F9B70.asm.txt), [EndSetDestination](../EVIDENCE/phase2/evidence/EndSetDestination_8F4490.asm.txt), [поля](../EVIDENCE/phase2/evidence/npc-fields.json).

| Условие в порядке проверки | Наблюдаемое поведение |
|---|---|
| _hasDestination=false | Выход |
| NPC.IsInVehicle=true | EndSetDestination(Interrupted=1) |
| IsMoving=true либо pathPending=true | Выход без завершения |
| CanMove=false либо IsOnLadder=true | Выход без завершения |
| !IsAsCloseAsPossible(destination,constant) | SetDestination с текущей целью, callback и threshold; повторный вызов SetDestination, не доказанный новый path request; выход |
| Достижимость удовлетворена и agent.hasPath | ResetPath; обнулить поля +0x168 и +0x170, после каждой записи вызван helper 0x316AB0 |
| Финальная проверка distance < threshold | EndSetDestination(Success=4) |
| Первая distance не прошла | Снова прочитать destination/transform.position и пересчитать ту же Euclidean distance |
| Вторая distance < threshold | Success=4; иначе Partial=3 |

Условие native `comiss threshold,distance; ja` означает строгий `<`, не `<=`; unordered/NaN не проходит ветку ja. Не заменять sqrt на squared comparison без float proof.

## Callback before clear
В EndSetDestination 0x8F4490:
- проверить callback +0x178;
- 0x8F44B2: indirect delegate call с result;
- при нормальном возврате callback затем 0x8F44BC: callback = null; вызов helper 0x316AB0;
- 0x8F44CE: _hasDestination=false;
- 0x8F4506/0x8F450E: запись vector constant в destination +0x11C/+0x124.

Факт: на пути нормального возврата callback вызывается до очистки. При исключении callback последующая очистка данным листингом не гарантируется. Риск/гипотеза: callback может реентерабельно поставить новую цель, которая затем будет затёрта текущим завершением; наличие такой реентерабельности в runtime не доказано. Нельзя незаметно переставлять очистку до callback под видом оптимизации.

## Ещё не доказано
Все callback implementations, exception paths/действия сторонних hooks, полный SetDestination retry contract, native getter side effects. Между двумя distance checks нет явного перемещения в листинге, но этого недостаточно для гарантированной equivalence. Безопасная работа сейчас: формальный контракт, не мод.

## Дополнительное машинное подтверждение distance

[Helper 0x456100](../EVIDENCE/phase2/evidence/helper_456100.asm.txt) содержит покомпонентную разность, квадраты и сумму, затем sqrtpd на 0x456191 и преобразование обратно в float. Поэтому Euclidean distance подтверждено не одним именем call target, а отдельным helper listing. Inspection window заканчивается после ret 0x4561C1; trailing int3 не часть арифметики. Helper 0x316AB0 в этом этапе отдельно не восстановлен, его write-barrier трактовка из предыдущего исследования не является новым доказанным выводом.
