# NPCPathCache: владение и открытые вопросы

[AddPath 0x8FB4A0](../EVIDENCE/current/native/8FB4A0.asm.txt), [GetPath 0x8FB5B0](../EVIDENCE/current/native/8FB5B0.asm.txt), [phase2 agent.path](../EVIDENCE/phase2/evidence/helper_2B1F000.asm.txt), [corners](../EVIDENCE/phase2/evidence/helper_2B20BF0.asm.txt).

Подтверждено: PathCache entry Start +0x10, End +0x1C, Path +0x28. AddPath выделяет entry, сохраняет переданный path reference и добавляет в list; GetPath возвращает reference первого подходящего entry. Start/end squared distance должны быть строго меньше переданного порога; переданный float в теле не возводится в квадрат. Не менять его единицы по имени параметра.

NavMeshAgent.path создаёт отдельный NavMeshPath с native handle. Corners array lazily cached per object. Путь может удерживаться NPCMovement и PathCache, поэтому return-to-pool/dispose при локальном завершении нельзя считать безопасным.

Нет eviction/Dispose в двух рассмотренных методах. Это НЕ доказанная утечка. Открыты: все изменения Paths, scene/NPC destruction, общий доступ нескольких consumers, actual native path lifetime и моды. LoadManager.CleanUp → NavMeshUtility.ClearCache не доказывает очистку NPCPathCache, это другой символ.

Следующий offline шаг: проследить SetDestination_8F8110, UpdateCache и FixedUpdate retained writes; составить ownership table. Следующий data request: все прямые/indirect callers и field writers Paths, native NavMeshPath destruction path. Ничего не внедрять до завершения.
