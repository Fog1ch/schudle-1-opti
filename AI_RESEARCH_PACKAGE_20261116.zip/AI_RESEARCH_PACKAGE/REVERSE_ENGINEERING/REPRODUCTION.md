# Воспроизводимость

## Offline, без игры/MCP
Python 3.11+ standard library. Из корня пакета:
```
python ANALYZERS/offline_query.py verify .
python ANALYZERS/offline_query.py methods NPCMovement
python ANALYZERS/offline_query.py calls GetAverageLightExposure
python ANALYZERS/offline_query.py mods PackagerConfiguration
```
Все документы/JSON/CSV/DOT читаются и без запуска Python. Не требуется .NET или установка tooling для offline reasoning.

## Новый статический native extract, только у владельца игры
Требуются уже имеющиеся .NET 8 SDK, Mono.Cecil и Iced из MelonLoader/net6, Cpp2IL outputs указанной сборки и GameAssembly. Никакая зависимость в пакет не скопирована. Версии/hashes в assembly index. Это не запускает игру.
```
dotnet build ANALYZERS/native-index/Analyzer.csproj -c Release -p:GameRoot="B:\Schedule I" --ignore-failed-sources
dotnet ANALYZERS/native-index/bin/Release/net8.0/Analyzer.dll "B:\Schedule I" "EVIDENCE/phase2/evidence/methods-all.json" "C:\Temp\ScheduleI-new-static-evidence"
```
Output обязан быть вне game root. Использовать новую пустую папку: analyser skips existing listing files, поэтому нельзя подменять game version и оставлять старые listing files. Перед запуском сверить fingerprints, не переносить старый method index на другую сборку.

## Asset extension
ANALYZERS/asset_links.py имеет явный локальный game path и лабораторный output. Для нового компьютера перенести copy в отдельную lab, изменить только input/output paths. Парсер read-only, v22 only; не считать candidate name schema validated.

## Архивные анализаторы
EVIDENCE/phase2/analyzer и его scripts сохранены как исторические исходники. Они имеют hardcoded paths/output и могут перезаписать evidence: не запускать прямо внутри пакета. ANALYZERS/archive/static_inventory.py зависит от старого s1lab и не standalone; включён для аудита старого алгоритма, а не как команда к исполнению. Новый offline_query standalone.

Сборщики baseline/checkpoint/build_package фиксируют происхождение текущей поставки, рассчитаны на исходную lab layout и не нужны получателю для продолжения. Полные game binaries/dependencies не включены. Не объявлять сам пакет воспроизводимой сборкой игры.
