# Риски

1. Бинарная версия: RVA/offset переносимы только при matching hashes. Хэши и metadata обязательны.
2. Native aliasing/inlining/indirect calls: автоматические labels могут вводить в заблуждение.
3. NPC callbacks: EndSetDestination вызывает callback до очистки; изменение порядка меняет семантику.
4. Path lifetime: retained reference запрещает преждевременный pooling/dispose.
5. Host/client и physics: пропуск fixed ticks меняет поведение, RNG, ragdoll, движение.
6. Animator culling: уже установленный S1Perf воздействует на offscreen bones; root motion/events/IK не проверены runtime.
7. Resources: versioned layout, references и streaming flags не восстановлены полностью; перепаковка небезопасна.
8. Mod overlap: ShouldSave влияет на сохранение employee configuration. Два declared targets не равны доказанному конфликту.
9. Measurement: размеры файлов, число методов и call sites не стоимость. Нельзя обещать FPS.
10. Exposure: пакет содержит имена файлов/типов, локальные пути и reverse-engineering snippets. Не включает saves, полные логи, API credentials или игровые binaries. Перед публичным распространением проверить права на derived материалы.
11. Tool failures: при сборке вспомогательные чтения требовали UTF-8; extension потребовал local assembly resolver. Исправлено, финальные outputs проверяются отдельно. Незавершённые Astar decodes явно оставлены в coverage.
12. Старые REPORT/README являются историческим контекстом: команды apply/rollback и отсутствующие из пакета profiles не инструкции к выполнению. Текущий handoff имеет приоритет для безопасного продолжения.
