# Pathfinding и obstacle avoidance

## Scope и подтверждённые наблюдения
Подтверждено phase2: avoidance уже InvokeRepeating 0.5 s с random initial delay 0..0.5 s; сравнение distanceSquared <=625 с ближайшим Player Avatar.CenterPoint. Это не raycast loop. SetObstacleAvoidanceEnabled содержит inline policy, OnStartClient также writer.
NPCPathCache.AddPath сохраняет переданную ссылку NavMeshPath в entry +0x28, не копирует путь на исследованном прямом пути. GetPath возвращает ту же ссылку из первого подходящего entry; start/end сравниваются квадратами расстояний со строгим порогом. В этих двух методах нет eviction/Dispose, но это НЕ доказывает утечку: другие владельцы и lifecycle не полностью исследованы.
AstarPath.Update содержит NavmeshUpdates.Update, TickNonMultithreaded и ReturnPaths. Наличие этой реализации не доказывает, что NPCMovement использует Astar: его прямой backend Unity NavMesh. Два Astar iterator ranges имеют INVALID и считаются неполными.

## Возможности, пока гипотезы
Сначала аудит владения кэшем и writers. Условная дедупликация avoidance setter требует проверки внутренних Unity setters и всех writer paths.

## Риски и неизвестное
Retained native handles, устаревшие пути, отключение агента, server/client, no-player distance=0. Pooling пока небезопасен.

## Адресуемые методы
| Метод | RVA | Offset | Cpp2IL bytes |
|---|---|---|---|
| System.Collections.Generic.List`1<ScheduleOne.NPCs.NPCPathCache/PathCache> ScheduleOne.NPCs.NPCPathCache::get_Paths() | 0x423EA0 | 0x4230A0 | 5 |
| System.Void ScheduleOne.NPCs.NPCPathCache::set_Paths(System.Collections.Generic.List`1<ScheduleOne.NPCs.NPCPathCache/PathCache>) | 0x469210 | 0x468410 | 13 |
| UnityEngine.AI.NavMeshPath ScheduleOne.NPCs.NPCPathCache::GetPath(UnityEngine.Vector3,UnityEngine.Vector3,System.Single) | 0x8FB5B0 | 0x8FA7B0 | 437 |
| System.Void ScheduleOne.NPCs.NPCPathCache::AddPath(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.AI.NavMeshPath) | 0x8FB4A0 | 0x8FA6A0 | 263 |
| System.Void ScheduleOne.NPCs.NPCPathCache::.ctor() | 0x8FB770 | 0x8FA970 | 119 |
| System.Void ScheduleOne.NPCs.NPCPathCache/PathCache::.ctor(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.AI.NavMeshPath) | 0x8FF4B0 | 0x8FE6B0 | 82 |
| System.Type[] AstarPath::get_graphTypes() | 0x4F5A20 | 0x4F4C20 | 27 |
| Pathfinding.AstarData AstarPath::get_astarData() | 0x421DF0 | 0x420FF0 | 5 |
| Pathfinding.NavGraph[] AstarPath::get_graphs() | 0xB290D0 | 0xB282D0 | 126 |
| System.Single AstarPath::get_maxNearestNodeDistanceSqr() | 0xB29150 | 0xB28350 | 10 |
| System.Boolean AstarPath::get_limitGraphUpdates() | 0x4AD890 | 0x4ACA90 | 5 |
| System.Void AstarPath::set_limitGraphUpdates(System.Boolean) | 0x4ADD50 | 0x4ACF50 | 4 |
| System.Single AstarPath::get_maxGraphUpdateFreq() | 0x7D1EB0 | 0x7D10B0 | 6 |
| System.Void AstarPath::set_maxGraphUpdateFreq(System.Single) | 0x6FADC0 | 0x6F9FC0 | 6 |
| System.Single AstarPath::get_lastScanTime() | 0x544AB0 | 0x543CB0 | 9 |
| System.Void AstarPath::set_lastScanTime(System.Single) | 0xB29160 | 0xB28360 | 9 |
| System.Boolean AstarPath::get_isScanning() | 0x544A50 | 0x543C50 | 8 |
| System.Void AstarPath::set_isScanning(System.Boolean) | 0xB1B680 | 0xB1A880 | 510 |
| System.Int32 AstarPath::get_NumParallelThreads() | 0xB290A0 | 0xB282A0 | 32 |
| System.Boolean AstarPath::get_IsUsingMultithreading() | 0xB29070 | 0xB28270 | 32 |
| System.Boolean AstarPath::get_IsAnyGraphUpdatesQueued() | 0xB29000 | 0xB28200 | 32 |
| System.Boolean AstarPath::get_IsAnyGraphUpdateQueued() | 0xB29000 | 0xB28200 | 32 |
| System.Boolean AstarPath::get_IsAnyGraphUpdateInProgress() | 0xB28FE0 | 0xB281E0 | 30 |
| System.Boolean AstarPath::get_IsAnyWorkItemInProgress() | 0xB29030 | 0xB28230 | 30 |
| System.Boolean AstarPath::get_IsInsideWorkItem() | 0xB29050 | 0xB28250 | 30 |
| System.Void AstarPath::.ctor() | 0xB28CF0 | 0xB27EF0 | 743 |
| System.String[] AstarPath::GetTagNames() | 0xB263B0 | 0xB255B0 | 300 |
| System.Void AstarPath::FindAstarPath() | 0xB254E0 | 0xB246E0 | 576 |
| System.String[] AstarPath::FindTagNames() | 0xB25730 | 0xB24930 | 591 |
| System.UInt16 AstarPath::GetNextPathID() | 0xB262D0 | 0xB254D0 | 219 |
| System.Void AstarPath::RecalculateDebugLimits() | 0xB275F0 | 0xB267F0 | 706 |
| System.Void AstarPath::OnDrawGizmos() | 0xB26F40 | 0xB26140 | 774 |
| System.Void AstarPath::OnGUI() | 0xB27250 | 0xB26450 | 144 |
| System.Void AstarPath::LogPathResults(Pathfinding.Path) | 0xB26910 | 0xB25B10 | 335 |
| System.Void AstarPath::Update() | 0xB28940 | 0xB27B40 | 167 |
| System.Void AstarPath::PerformBlockingActions(System.Boolean) | 0xB27360 | 0xB26560 | 146 |
| System.Void AstarPath::QueueWorkItemFloodFill() | 0xB275A0 | 0xB267A0 | 78 |
| System.Void AstarPath::EnsureValidFloodFill() | 0xB25490 | 0xB24690 | 78 |
| System.Void AstarPath::AddWorkItem(System.Action) | 0xB244F0 | 0xB236F0 | 164 |
| System.Void AstarPath::AddWorkItem(System.Action`1<Pathfinding.IWorkItemContext>) | 0xB24440 | 0xB23640 | 164 |
| System.Void AstarPath::AddWorkItem(Pathfinding.AstarWorkItem) | 0xB245A0 | 0xB237A0 | 137 |
| System.Void AstarPath::QueueGraphUpdates() | 0xB27400 | 0xB26600 | 406 |
| System.Collections.IEnumerator AstarPath::DelayedGraphUpdate() | 0xB253F0 | 0xB245F0 | 103 |
| System.Void AstarPath::UpdateGraphs(UnityEngine.Bounds,System.Single) | 0xB28710 | 0xB27910 | 238 |
| System.Void AstarPath::UpdateGraphs(Pathfinding.GraphUpdateObject,System.Single) | 0xB28670 | 0xB27870 | 160 |
| System.Collections.IEnumerator AstarPath::UpdateGraphsInternal(Pathfinding.GraphUpdateObject,System.Single) | 0xB28550 | 0xB27750 | 150 |
| System.Void AstarPath::UpdateGraphs(UnityEngine.Bounds) | 0xB285F0 | 0xB277F0 | 128 |
| System.Void AstarPath::UpdateGraphs(Pathfinding.GraphUpdateObject) | 0xB28800 | 0xB27A00 | 306 |
| System.Void AstarPath::FlushGraphUpdates() | 0xB259C0 | 0xB24BC0 | 68 |
| System.Void AstarPath::FlushWorkItems() | 0xB25A90 | 0xB24C90 | 112 |
| System.Void AstarPath::FlushWorkItems(System.Boolean,System.Boolean) | 0xB25A20 | 0xB24C20 | 104 |
| System.Void AstarPath::FlushThreadSafeCallbacks() | 0xB25A10 | 0xB24C10 | 7 |
| System.Int32 AstarPath::CalculateThreadCount(Pathfinding.ThreadCount) | 0xB25170 | 0xB24370 | 366 |
| System.Void AstarPath::Awake() | 0xB24630 | 0xB23830 | 1252 |
| System.Void AstarPath::InitializePathProcessor() | 0xB26560 | 0xB25760 | 941 |
| System.Void AstarPath::VerifyIntegrity() | 0xB289F0 | 0xB27BF0 | 379 |
| System.Void AstarPath::ConfigureReferencesInternal() | 0xB252E0 | 0xB244E0 | 268 |
| System.Void AstarPath::InitializeProfiler() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Void AstarPath::InitializeAstarData() | 0xB264E0 | 0xB256E0 | 67 |
| System.Void AstarPath::OnDisable() | 0xB26F10 | 0xB26110 | 32 |
| System.Void AstarPath::OnDestroy() | 0xB26A60 | 0xB25C60 | 1195 |
| System.Void AstarPath::FloodFill(Pathfinding.GraphNode) | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Void AstarPath::FloodFill(Pathfinding.GraphNode,System.UInt32) | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Void AstarPath::FloodFill() | 0xB25980 | 0xB24B80 | 57 |
| System.Int32 AstarPath::GetNewNodeIndex() | 0xB262A0 | 0xB254A0 | 32 |
| System.Void AstarPath::InitializeNode(Pathfinding.GraphNode) | 0xB26530 | 0xB25730 | 33 |
| System.Void AstarPath::DestroyNode(Pathfinding.GraphNode) | 0xB25460 | 0xB24660 | 33 |
| System.Void AstarPath::BlockUntilPathQueueBlocked() | 0x43FEC0 | 0x43F0C0 | 3 |
| Pathfinding.PathProcessor/GraphUpdateLock AstarPath::PausePathfinding() | 0xB27320 | 0xB26520 | 57 |
| Pathfinding.PathProcessor/GraphUpdateLock AstarPath::PausePathfindingSoon() | 0xB272E0 | 0xB264E0 | 57 |
| System.Void AstarPath::Scan(Pathfinding.NavGraph) | 0xB27D90 | 0xB26F90 | 238 |
| System.Void AstarPath::Scan(Pathfinding.NavGraph[]) | 0xB27BC0 | 0xB26DC0 | 452 |
| System.Collections.Generic.IEnumerable`1<Pathfinding.Progress> AstarPath::ScanAsync(Pathfinding.NavGraph) | 0xB27A50 | 0xB26C50 | 238 |
| System.Collections.Generic.IEnumerable`1<Pathfinding.Progress> AstarPath::ScanAsync(Pathfinding.NavGraph[]) | 0xB279C0 | 0xB26BC0 | 142 |
| System.Collections.Generic.IEnumerable`1<Pathfinding.Progress> AstarPath::ScanGraph(Pathfinding.NavGraph) | 0xB27B40 | 0xB26D40 | 113 |
| System.Void AstarPath::WaitForPath(Pathfinding.Path) | 0xB28B70 | 0xB27D70 | 73 |
| System.Void AstarPath::BlockUntilCalculated(Pathfinding.Path) | 0xB24B20 | 0xB23D20 | 1601 |
| System.Void AstarPath::RegisterSafeUpdate(System.Action) | 0xB278C0 | 0xB26AC0 | 251 |
| System.Void AstarPath::StartPath(Pathfinding.Path,System.Boolean) | 0xB27E80 | 0xB27080 | 1088 |
| Pathfinding.NNInfo AstarPath::GetNearest(UnityEngine.Vector3) | 0xB25F30 | 0xB25130 | 177 |
| Pathfinding.NNInfo AstarPath::GetNearest(UnityEngine.Vector3,Pathfinding.NNConstraint) | 0xB26250 | 0xB25450 | 80 |
| Pathfinding.NNInfo AstarPath::GetNearest(UnityEngine.Vector3,Pathfinding.NNConstraint,Pathfinding.GraphNode) | 0xB25B10 | 0xB24D10 | 1042 |
| Pathfinding.GraphNode AstarPath::GetNearest(UnityEngine.Ray) | 0xB25FF0 | 0xB251F0 | 597 |
| System.Void AstarPath::.cctor() | 0xB28BC0 | 0xB27DC0 | 299 |
| System.Void AstarPath::<.ctor>b__92_0() | 0xB284B0 | 0xB276B0 | 147 |
| System.Void AstarPath::<InitializePathProcessor>b__122_1(Pathfinding.Path) | 0xB282D0 | 0xB274D0 | 430 |
| System.Void AstarPath::<InitializePathProcessor>b__122_2() | 0xB28480 | 0xB27680 | 46 |
| System.Void AstarPath/<>c::.cctor() | 0xB35740 | 0xB34940 | 103 |
| System.Void AstarPath/<>c::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Void AstarPath/<>c::<InitializePathProcessor>b__122_0(Pathfinding.Path) | 0xB352F0 | 0xB344F0 | 110 |
| System.Void AstarPath/<>c__DisplayClass109_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Void AstarPath/<>c__DisplayClass109_0::<QueueGraphUpdates>b__0() | 0xB35360 | 0xB34560 | 89 |
| System.Void AstarPath/<>c__DisplayClass142_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Void AstarPath/<>c__DisplayClass142_0::<ScanGraph>b__0(Pathfinding.GraphNode) | 0xB353C0 | 0xB345C0 | 44 |
| System.Void AstarPath/<>c__DisplayClass152_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Void AstarPath/<>c__DisplayClass152_0::<GetNearest>b__0(Pathfinding.GraphNode) | 0xB353F0 | 0xB345F0 | 289 |
| System.Void AstarPath/<>c__DisplayClass97_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Void AstarPath/<>c__DisplayClass97_0::<RecalculateDebugLimits>b__0(Pathfinding.GraphNode) | 0xB35520 | 0xB34720 | 543 |
| System.Void AstarPath/<DelayedGraphUpdate>d__110::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void AstarPath/<DelayedGraphUpdate>d__110::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean AstarPath/<DelayedGraphUpdate>d__110::MoveNext() | 0xB33470 | 0xB32670 | 262 |
| System.Object AstarPath/<DelayedGraphUpdate>d__110::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void AstarPath/<DelayedGraphUpdate>d__110::System.Collections.IEnumerator.Reset() | 0xB33580 | 0xB32780 | 62 |
| System.Object AstarPath/<DelayedGraphUpdate>d__110::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void AstarPath/<ScanAsync>d__141::.ctor(System.Int32) | 0xB34430 | 0xB33630 | 46 |
| System.Void AstarPath/<ScanAsync>d__141::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean AstarPath/<ScanAsync>d__141::MoveNext() | 0xB335C0 | 0xB327C0 | 404 |
| Pathfinding.Progress AstarPath/<ScanAsync>d__141::System.Collections.Generic.IEnumerator<Pathfinding.Progress>.get_Current() | 0x4F03E0 | 0x4EF5E0 | 11 |
| System.Void AstarPath/<ScanAsync>d__141::System.Collections.IEnumerator.Reset() | 0xB343A0 | 0xB335A0 | 62 |
| System.Object AstarPath/<ScanAsync>d__141::System.Collections.IEnumerator.get_Current() | 0xB343E0 | 0xB335E0 | 69 |
| System.Collections.Generic.IEnumerator`1<Pathfinding.Progress> AstarPath/<ScanAsync>d__141::System.Collections.Generic.IEnumerable<Pathfinding.Progress>.GetEnumerator() | 0xB342F0 | 0xB334F0 | 173 |
| System.Collections.IEnumerator AstarPath/<ScanAsync>d__141::System.Collections.IEnumerable.GetEnumerator() | 0xB342F0 | 0xB334F0 | 173 |
| System.Void AstarPath/<ScanGraph>d__142::.ctor(System.Int32) | 0xB34430 | 0xB33630 | 46 |
| System.Void AstarPath/<ScanGraph>d__142::System.IDisposable.Dispose() | 0xB34C60 | 0xB33E60 | 140 |
| System.Boolean AstarPath/<ScanGraph>d__142::MoveNext() | 0xB34460 | 0xB33660 | 252 |
| System.Void AstarPath/<ScanGraph>d__142::<>m__Finally1() | 0xB34CF0 | 0xB33EF0 | 80 |
| Pathfinding.Progress AstarPath/<ScanGraph>d__142::System.Collections.Generic.IEnumerator<Pathfinding.Progress>.get_Current() | 0x4F03E0 | 0x4EF5E0 | 11 |
| System.Void AstarPath/<ScanGraph>d__142::System.Collections.IEnumerator.Reset() | 0xB34BD0 | 0xB33DD0 | 62 |
| System.Object AstarPath/<ScanGraph>d__142::System.Collections.IEnumerator.get_Current() | 0xB34C10 | 0xB33E10 | 69 |
| System.Collections.Generic.IEnumerator`1<Pathfinding.Progress> AstarPath/<ScanGraph>d__142::System.Collections.Generic.IEnumerable<Pathfinding.Progress>.GetEnumerator() | 0xB34B30 | 0xB33D30 | 156 |
| System.Collections.IEnumerator AstarPath/<ScanGraph>d__142::System.Collections.IEnumerable.GetEnumerator() | 0xB34B30 | 0xB33D30 | 156 |
| System.Void AstarPath/<UpdateGraphsInternal>d__113::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void AstarPath/<UpdateGraphsInternal>d__113::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean AstarPath/<UpdateGraphsInternal>d__113::MoveNext() | 0xB357B0 | 0xB349B0 | 182 |
| System.Object AstarPath/<UpdateGraphsInternal>d__113::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void AstarPath/<UpdateGraphsInternal>d__113::System.Collections.IEnumerator.Reset() | 0xB35870 | 0xB34A70 | 62 |
| System.Object AstarPath/<UpdateGraphsInternal>d__113::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void Pathfinding.AIPath::Teleport(UnityEngine.Vector3,System.Boolean) | 0xB23B80 | 0xB22D80 | 46 |
| System.Single Pathfinding.AIPath::get_remainingDistance() | 0xB24070 | 0xB23270 | 495 |
| System.Boolean Pathfinding.AIPath::get_reachedDestination() | 0xB23D20 | 0xB22F20 | 838 |
| System.Boolean Pathfinding.AIPath::get_reachedEndOfPath() | 0x582C60 | 0x581E60 | 8 |
| System.Void Pathfinding.AIPath::set_reachedEndOfPath(System.Boolean) | 0x9D34F0 | 0x9D26F0 | 7 |
| System.Boolean Pathfinding.AIPath::get_hasPath() | 0xB23CE0 | 0xB22EE0 | 32 |
| System.Boolean Pathfinding.AIPath::get_pathPending() | 0xB23D10 | 0xB22F10 | 8 |
| UnityEngine.Vector3 Pathfinding.AIPath::get_steeringTarget() | 0xB24260 | 0xB23460 | 204 |
| System.Single Pathfinding.AIPath::Pathfinding.IAstarAI.get_radius() | 0x4F03D0 | 0x4EF5D0 | 6 |
| System.Void Pathfinding.AIPath::Pathfinding.IAstarAI.set_radius(System.Single) | 0x514B10 | 0x513D10 | 6 |
| System.Single Pathfinding.AIPath::Pathfinding.IAstarAI.get_height() | 0x463B00 | 0x462D00 | 6 |
| System.Void Pathfinding.AIPath::Pathfinding.IAstarAI.set_height(System.Single) | 0x58A110 | 0x589310 | 6 |
| System.Single Pathfinding.AIPath::Pathfinding.IAstarAI.get_maxSpeed() | 0x463B80 | 0x462D80 | 6 |
| System.Void Pathfinding.AIPath::Pathfinding.IAstarAI.set_maxSpeed(System.Single) | 0x81A860 | 0x819A60 | 6 |
| System.Boolean Pathfinding.AIPath::Pathfinding.IAstarAI.get_canSearch() | 0xB1EC00 | 0xB1DE00 | 33 |
| System.Void Pathfinding.AIPath::Pathfinding.IAstarAI.set_canSearch(System.Boolean) | 0xB1F030 | 0xB1E230 | 60 |
| System.Boolean Pathfinding.AIPath::Pathfinding.IAstarAI.get_canMove() | 0x465080 | 0x464280 | 5 |
| System.Void Pathfinding.AIPath::Pathfinding.IAstarAI.set_canMove(System.Boolean) | 0x49A650 | 0x499850 | 4 |
| System.Void Pathfinding.AIPath::GetRemainingPath(System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Boolean&) | 0xB227C0 | 0xB219C0 | 333 |
| System.Void Pathfinding.AIPath::OnDisable() | 0xB23380 | 0xB22580 | 112 |
| System.Void Pathfinding.AIPath::OnTargetReached() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Void Pathfinding.AIPath::OnPathComplete(Pathfinding.Path) | 0xB23400 | 0xB22600 | 1870 |
| System.Void Pathfinding.AIPath::ClearPath() | 0xB22740 | 0xB21940 | 112 |
| System.Void Pathfinding.AIPath::MovementUpdateInternal(System.Single,UnityEngine.Vector3&,UnityEngine.Quaternion&) | 0xB22910 | 0xB21B10 | 2670 |
| System.Void Pathfinding.AIPath::CalculateNextRotation(System.Single,UnityEngine.Quaternion&) | 0xB21FF0 | 0xB211F0 | 591 |
| UnityEngine.Vector3 Pathfinding.AIPath::ClampToNavmesh(UnityEngine.Vector3,System.Boolean&) | 0xB22330 | 0xB21530 | 1035 |
| System.Int32 Pathfinding.AIPath::OnUpgradeSerializedData(System.Int32,System.Boolean) | 0xB23B50 | 0xB22D50 | 37 |
| System.Boolean Pathfinding.AIPath::get_TargetReached() | 0x582C60 | 0x581E60 | 8 |
| System.Single Pathfinding.AIPath::get_turningSpeed() | 0xB24400 | 0xB23600 | 17 |
| System.Void Pathfinding.AIPath::set_turningSpeed(System.Single) | 0xB24420 | 0xB23620 | 17 |
| System.Single Pathfinding.AIPath::get_speed() | 0x463B80 | 0x462D80 | 6 |
| System.Void Pathfinding.AIPath::set_speed(System.Single) | 0x81A860 | 0x819A60 | 6 |
| UnityEngine.Vector3 Pathfinding.AIPath::get_targetDirection() | 0xB24330 | 0xB23530 | 197 |
| UnityEngine.Vector3 Pathfinding.AIPath::CalculateVelocity(UnityEngine.Vector3) | 0xB22240 | 0xB21440 | 226 |
| System.Void Pathfinding.AIPath::.ctor() | 0xB23C10 | 0xB22E10 | 198 |
| System.Void Pathfinding.AIPath::.cctor() | 0xB23BB0 | 0xB22DB0 | 82 |
| System.Void Pathfinding.Seeker::.ctor() | 0xB332D0 | 0xB324D0 | 403 |
| System.Void Pathfinding.Seeker::Awake() | 0xB31ED0 | 0xB310D0 | 46 |
| Pathfinding.Path Pathfinding.Seeker::GetCurrentPath() | 0x498CF0 | 0x497EF0 | 5 |
| System.Void Pathfinding.Seeker::CancelCurrentPathRequest(System.Boolean) | 0xB31F00 | 0xB31100 | 143 |
| System.Void Pathfinding.Seeker::OnDestroy() | 0xB320A0 | 0xB312A0 | 95 |
| System.Void Pathfinding.Seeker::ReleaseClaimedPath() | 0xB32880 | 0xB31A80 | 76 |
| System.Void Pathfinding.Seeker::RegisterModifier(Pathfinding.IPathModifier) | 0xB326D0 | 0xB318D0 | 419 |
| System.Void Pathfinding.Seeker::DeregisterModifier(Pathfinding.IPathModifier) | 0xB31F90 | 0xB31190 | 86 |
| System.Void Pathfinding.Seeker::PostProcess(Pathfinding.Path) | 0xB326C0 | 0xB318C0 | 16 |
| System.Void Pathfinding.Seeker::RunModifiers(Pathfinding.Seeker/ModifierPass,Pathfinding.Path) | 0xB328D0 | 0xB31AD0 | 613 |
| System.Boolean Pathfinding.Seeker::IsDone() | 0xB32080 | 0xB31280 | 22 |
| System.Void Pathfinding.Seeker::OnPathComplete(Pathfinding.Path) | 0xB325B0 | 0xB317B0 | 30 |
| System.Void Pathfinding.Seeker::OnPathComplete(Pathfinding.Path,System.Boolean,System.Boolean) | 0xB32440 | 0xB31640 | 364 |
| System.Void Pathfinding.Seeker::OnPartialPathComplete(Pathfinding.Path) | 0xB323A0 | 0xB315A0 | 149 |
| System.Void Pathfinding.Seeker::OnMultiPathComplete(Pathfinding.Path) | 0xB32380 | 0xB31580 | 29 |
| Pathfinding.ABPath Pathfinding.Seeker::GetNewPath(UnityEngine.Vector3,UnityEngine.Vector3) | 0xB31FF0 | 0xB311F0 | 131 |
| Pathfinding.Path Pathfinding.Seeker::StartPath(UnityEngine.Vector3,UnityEngine.Vector3) | 0xB33040 | 0xB32240 | 198 |
| Pathfinding.Path Pathfinding.Seeker::StartPath(UnityEngine.Vector3,UnityEngine.Vector3,Pathfinding.OnPathDelegate) | 0xB33110 | 0xB32310 | 189 |
| Pathfinding.Path Pathfinding.Seeker::StartPath(UnityEngine.Vector3,UnityEngine.Vector3,Pathfinding.OnPathDelegate,Pathfinding.GraphMask) | 0xB331D0 | 0xB323D0 | 187 |
| Pathfinding.Path Pathfinding.Seeker::StartPath(Pathfinding.Path,Pathfinding.OnPathDelegate) | 0xB33290 | 0xB32490 | 61 |
| Pathfinding.Path Pathfinding.Seeker::StartPath(Pathfinding.Path,Pathfinding.OnPathDelegate,Pathfinding.GraphMask) | 0xB33000 | 0xB32200 | 49 |
| System.Void Pathfinding.Seeker::StartPathInternal(Pathfinding.Path,Pathfinding.OnPathDelegate) | 0xB32CE0 | 0xB31EE0 | 791 |
| Pathfinding.MultiTargetPath Pathfinding.Seeker::StartMultiTargetPath(UnityEngine.Vector3,UnityEngine.Vector3[],System.Boolean,Pathfinding.OnPathDelegate,System.Int32) | 0xB32BA0 | 0xB31DA0 | 151 |
| Pathfinding.MultiTargetPath Pathfinding.Seeker::StartMultiTargetPath(UnityEngine.Vector3[],UnityEngine.Vector3,System.Boolean,Pathfinding.OnPathDelegate,System.Int32) | 0xB32C40 | 0xB31E40 | 153 |
| Pathfinding.MultiTargetPath Pathfinding.Seeker::StartMultiTargetPath(Pathfinding.MultiTargetPath,Pathfinding.OnPathDelegate,System.Int32) | 0xB32B40 | 0xB31D40 | 92 |
| System.Void Pathfinding.Seeker::OnDrawGizmos() | 0xB32100 | 0xB31300 | 634 |
| System.Int32 Pathfinding.Seeker::OnUpgradeSerializedData(System.Int32,System.Boolean) | 0xB325D0 | 0xB317D0 | 237 |
| System.Void Pathfinding.Seeker/<>c::.cctor() | 0xB45E10 | 0xB45010 | 103 |
| System.Void Pathfinding.Seeker/<>c::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Int32 Pathfinding.Seeker/<>c::<RegisterModifier>b__26_0(Pathfinding.IPathModifier,Pathfinding.IPathModifier) | 0xB454E0 | 0xB446E0 | 123 |
| System.Boolean UnityEngine.AI.NavMeshAgent::SetDestination(UnityEngine.Vector3) | 0x2B1EBE0 | 0x2B1DDE0 | 66 |
| System.Single UnityEngine.AI.NavMeshAgent::get_stoppingDistance() | 0x2B1F0E0 | 0x2B1E2E0 | 51 |
| UnityEngine.Vector3 UnityEngine.AI.NavMeshAgent::get_velocity() | 0x2B1F170 | 0x2B1E370 | 77 |
| System.Void UnityEngine.AI.NavMeshAgent::set_velocity(UnityEngine.Vector3) | 0x2B1F3C0 | 0x2B1E5C0 | 66 |
| UnityEngine.Vector3 UnityEngine.AI.NavMeshAgent::get_desiredVelocity() | 0x2B1EEB0 | 0x2B1E0B0 | 77 |
| System.Single UnityEngine.AI.NavMeshAgent::get_remainingDistance() | 0x2B1F0A0 | 0x2B1E2A0 | 51 |
| System.Boolean UnityEngine.AI.NavMeshAgent::get_isOnOffMeshLink() | 0x2B1EF80 | 0x2B1E180 | 51 |
| UnityEngine.AI.OffMeshLinkData UnityEngine.AI.NavMeshAgent::get_currentOffMeshLinkData() | 0x2B1EDE0 | 0x2B1DFE0 | 119 |
| UnityEngine.AI.OffMeshLinkData UnityEngine.AI.NavMeshAgent::GetCurrentOffMeshLinkDataInternal() | 0x2B1EA50 | 0x2B1DC50 | 85 |
| System.Void UnityEngine.AI.NavMeshAgent::CompleteOffMeshLink() | 0x2B1E970 | 0x2B1DB70 | 51 |
| System.Boolean UnityEngine.AI.NavMeshAgent::get_hasPath() | 0x2B1EF00 | 0x2B1E100 | 51 |
| System.Boolean UnityEngine.AI.NavMeshAgent::get_pathPending() | 0x2B1EFC0 | 0x2B1E1C0 | 51 |
| System.Boolean UnityEngine.AI.NavMeshAgent::Warp(UnityEngine.Vector3) | 0x2B1ECD0 | 0x2B1DED0 | 66 |
| System.Void UnityEngine.AI.NavMeshAgent::Move(UnityEngine.Vector3) | 0x2B1EB00 | 0x2B1DD00 | 66 |
| System.Void UnityEngine.AI.NavMeshAgent::set_isStopped(System.Boolean) | 0x2B1F290 | 0x2B1E490 | 66 |
| System.Void UnityEngine.AI.NavMeshAgent::ResetPath() | 0x2B1EB50 | 0x2B1DD50 | 51 |
| System.Boolean UnityEngine.AI.NavMeshAgent::SetPath(UnityEngine.AI.NavMeshPath) | 0x2B1EC30 | 0x2B1DE30 | 66 |
| UnityEngine.AI.NavMeshPath UnityEngine.AI.NavMeshAgent::get_path() | 0x2B1F000 | 0x2B1E200 | 156 |
| System.Void UnityEngine.AI.NavMeshAgent::CopyPathTo(UnityEngine.AI.NavMeshPath) | 0x2B1E9B0 | 0x2B1DBB0 | 66 |
| System.Boolean UnityEngine.AI.NavMeshAgent::CalculatePath(UnityEngine.Vector3,UnityEngine.AI.NavMeshPath) | 0x2B1E8C0 | 0x2B1DAC0 | 170 |
| System.Boolean UnityEngine.AI.NavMeshAgent::CalculatePathInternal(UnityEngine.Vector3,UnityEngine.AI.NavMeshPath) | 0x2B1E860 | 0x2B1DA60 | 82 |
| System.Int32 UnityEngine.AI.NavMeshAgent::get_agentTypeID() | 0x2B1ED20 | 0x2B1DF20 | 51 |
| System.Void UnityEngine.AI.NavMeshAgent::set_agentTypeID(System.Int32) | 0x2B1F1C0 | 0x2B1E3C0 | 64 |
| System.Int32 UnityEngine.AI.NavMeshAgent::get_areaMask() | 0x2B1EDA0 | 0x2B1DFA0 | 51 |
| System.Void UnityEngine.AI.NavMeshAgent::set_speed(System.Single) | 0x2B1F320 | 0x2B1E520 | 67 |
| System.Single UnityEngine.AI.NavMeshAgent::get_angularSpeed() | 0x2B1ED60 | 0x2B1DF60 | 51 |
| System.Void UnityEngine.AI.NavMeshAgent::set_angularSpeed(System.Single) | 0x2B1F200 | 0x2B1E400 | 67 |
| System.Void UnityEngine.AI.NavMeshAgent::set_obstacleAvoidanceType(UnityEngine.AI.ObstacleAvoidanceType) | 0x2B1F2E0 | 0x2B1E4E0 | 64 |
| System.Void UnityEngine.AI.NavMeshAgent::set_avoidancePriority(System.Int32) | 0x2B1F250 | 0x2B1E450 | 64 |
| System.Boolean UnityEngine.AI.NavMeshAgent::get_isOnNavMesh() | 0x2B1EF40 | 0x2B1E140 | 51 |
| System.Void UnityEngine.AI.NavMeshAgent::.ctor() | 0x41D490 | 0x41C690 | 7 |
| System.Boolean UnityEngine.AI.NavMeshAgent::SetDestination_Injected(UnityEngine.Vector3&) | 0x2B1EB90 | 0x2B1DD90 | 66 |
| System.Void UnityEngine.AI.NavMeshAgent::get_velocity_Injected(UnityEngine.Vector3&) | 0x2B1F120 | 0x2B1E320 | 66 |
| System.Void UnityEngine.AI.NavMeshAgent::set_velocity_Injected(UnityEngine.Vector3&) | 0x2B1F370 | 0x2B1E570 | 66 |
| System.Void UnityEngine.AI.NavMeshAgent::get_desiredVelocity_Injected(UnityEngine.Vector3&) | 0x2B1EE60 | 0x2B1E060 | 66 |
| System.Void UnityEngine.AI.NavMeshAgent::GetCurrentOffMeshLinkDataInternal_Injected(UnityEngine.AI.OffMeshLinkData&) | 0x2B1EA00 | 0x2B1DC00 | 66 |
| System.Boolean UnityEngine.AI.NavMeshAgent::Warp_Injected(UnityEngine.Vector3&) | 0x2B1EC80 | 0x2B1DE80 | 66 |
| System.Void UnityEngine.AI.NavMeshAgent::Move_Injected(UnityEngine.Vector3&) | 0x2B1EAB0 | 0x2B1DCB0 | 66 |
| System.Boolean UnityEngine.AI.NavMeshAgent::CalculatePathInternal_Injected(UnityEngine.Vector3&,UnityEngine.AI.NavMeshPath) | 0x2B1E800 | 0x2B1DA00 | 82 |
| System.Void UnityEngine.AI.NavMeshPath::.ctor() | 0x2B20BB0 | 0x2B1FDB0 | 59 |
| System.Void UnityEngine.AI.NavMeshPath::Finalize() | 0x2B20AF0 | 0x2B1FCF0 | 134 |
| System.IntPtr UnityEngine.AI.NavMeshPath::InitializeNavMeshPath() | 0x2B20B80 | 0x2B1FD80 | 42 |
| System.Void UnityEngine.AI.NavMeshPath::DestroyNavMeshPath(System.IntPtr) | 0x2B20AB0 | 0x2B1FCB0 | 51 |
| UnityEngine.Vector3[] UnityEngine.AI.NavMeshPath::CalculateCornersInternal() | 0x2B20990 | 0x2B1FB90 | 51 |
| System.Void UnityEngine.AI.NavMeshPath::ClearCornersInternal() | 0x2B20A20 | 0x2B1FC20 | 51 |
| System.Void UnityEngine.AI.NavMeshPath::ClearCorners() | 0x2B20A60 | 0x2B1FC60 | 69 |
| System.Void UnityEngine.AI.NavMeshPath::CalculateCorners() | 0x2B209D0 | 0x2B1FBD0 | 79 |
| UnityEngine.Vector3[] UnityEngine.AI.NavMeshPath::get_corners() | 0x2B20BF0 | 0x2B1FDF0 | 88 |
| UnityEngine.AI.NavMeshPathStatus UnityEngine.AI.NavMeshPath::get_status() | 0x2B20C50 | 0x2B1FE50 | 51 |

Полные поля и offsets: [selected-types-fields](../EVIDENCE/current/selected-types-fields.json). Public proxy API: [interop-selected-api](../EVIDENCE/current/interop-selected-api.json).

## Сохранённые native roots
- [System.Collections.Generic.List`1<ScheduleOne.NPCs.NPCPathCache/PathCache> ScheduleOne.NPCs.NPCPathCache::get_Paths()](../EVIDENCE/current/native/423EA0.asm.txt)
- [System.Void ScheduleOne.NPCs.NPCPathCache::set_Paths(System.Collections.Generic.List`1<ScheduleOne.NPCs.NPCPathCache/PathCache>)](../EVIDENCE/current/native/469210.asm.txt)
- [UnityEngine.AI.NavMeshPath ScheduleOne.NPCs.NPCPathCache::GetPath(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)](../EVIDENCE/current/native/8FB5B0.asm.txt)
- [System.Void ScheduleOne.NPCs.NPCPathCache::AddPath(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.AI.NavMeshPath)](../EVIDENCE/current/native/8FB4A0.asm.txt)
- [System.Void ScheduleOne.NPCs.NPCPathCache::.ctor()](../EVIDENCE/current/native/8FB770.asm.txt)
- [System.Void AstarPath::Update()](../EVIDENCE/current/native/B28940.asm.txt)
- [System.Void AstarPath::OnDestroy()](../EVIDENCE/current/native/B26A60.asm.txt)
- [System.Boolean AstarPath/<DelayedGraphUpdate>d__110::MoveNext()](../EVIDENCE/current/native/B33470.asm.txt)
- [System.Boolean AstarPath/<ScanAsync>d__141::MoveNext()](../EVIDENCE/current/native/B335C0.asm.txt) **INVALID: неполный range**
- [System.Boolean AstarPath/<ScanGraph>d__142::MoveNext()](../EVIDENCE/current/native/B34460.asm.txt) **INVALID: неполный range**
- [System.Boolean AstarPath/<UpdateGraphsInternal>d__113::MoveNext()](../EVIDENCE/current/native/B357B0.asm.txt)
- [System.Void Pathfinding.Seeker::OnDestroy()](../EVIDENCE/current/native/B320A0.asm.txt)

[Native edge records](../EVIDENCE/current/native-edges.json). [Правила aliasing и scope](../REVERSE_ENGINEERING/EVIDENCE_RULES.md). [Исторический NPC report](../EVIDENCE/phase2/REPORT.ru.md). [Mod call sites](../EVIDENCE/current/mod-call-sites.json).
