# Physics и взаимодействия

## Scope и подтверждённые наблюдения
PhysicsManager.RpcLogic___SetGravityMultiplier вызывает UnityEngine.Physics.set_gravity. Ragdoll.SetGravityMultiplier читает Rigidbody.mass и Physics.gravity, записывает ConstantForce.force. Следовательно, эти параметры несут игровую семантику, а не только настройки производительности.
Phase2 покрывает NPC collision callbacks, ragdoll recovery и NavMeshAgent.Move; прямого Raycast/Overlap loop в трёх исходных NPC roots нет. Установленный S1Perf.ApplyGlobal условно включает Physics.reuseCollisionCallbacks, что уже является существующим изменением поведения объекта Collision.
Глубина: выборочные native roots, не полный PhysX solver и не карта всех контактов.

## Возможности, пока гипотезы
Исследовать lifetime Collision у потребителей перед любым расширением reuse; фиксировать контактные counters только при отдельно разрешённом runtime.

## Риски и неизвестное
Нельзя менять fixed timestep, gravity, autoSyncTransforms или collision reuse вслепую. Ссылки Collision могут сохраняться обработчиками.

## Адресуемые методы
| Метод | RVA | Offset | Cpp2IL bytes |
|---|---|---|---|
| System.Single ScheduleOne.GamePhysics.PhysicsManager::get_GravityMultiplier() | 0x58BB40 | 0x58AD40 | 9 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::set_GravityMultiplier(System.Single) | 0x58BB60 | 0x58AD60 | 9 |
| UnityEngine.LayerMask ScheduleOne.GamePhysics.PhysicsManager::get_GroundDetectionLayerMask() | 0x58BB50 | 0x58AD50 | 7 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::set_GroundDetectionLayerMask(UnityEngine.LayerMask) | 0x58BB70 | 0x58AD70 | 7 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::Awake() | 0x58AFC0 | 0x58A1C0 | 273 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::OnSpawnServer(FishNet.Connection.NetworkConnection) | 0x58B3C0 | 0x58A5C0 | 95 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::SetGravityMultiplier(FishNet.Connection.NetworkConnection,System.Single) | 0x58B880 | 0x58AA80 | 608 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::.ctor() | 0x58BAF0 | 0x58ACF0 | 67 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::NetworkInitialize___Early() | 0x58B130 | 0x58A330 | 652 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::NetworkInitialize__Late() | 0x58B0E0 | 0x58A2E0 | 79 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::NetworkInitializeIfDisabled() | 0x51FE10 | 0x51F010 | 50 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::RpcWriter___Observers_SetGravityMultiplier_530160725(FishNet.Connection.NetworkConnection,System.Single) | 0x58B5E0 | 0x58A7E0 | 319 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::RpcLogic___SetGravityMultiplier_530160725(FishNet.Connection.NetworkConnection,System.Single) | 0x58B420 | 0x58A620 | 236 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::RpcReader___Observers_SetGravityMultiplier_530160725(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel) | 0x58B510 | 0x58A710 | 98 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::RpcWriter___Target_SetGravityMultiplier_530160725(FishNet.Connection.NetworkConnection,System.Single) | 0x58B720 | 0x58A920 | 346 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::RpcReader___Target_SetGravityMultiplier_530160725(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel) | 0x58B580 | 0x58A780 | 95 |
| System.Void ScheduleOne.GamePhysics.PhysicsManager::Awake_UserLogic_ScheduleOne.GamePhysics.PhysicsManager_Assembly-CSharp.dll() | 0x58AED0 | 0x58A0D0 | 229 |
| UnityEngine.Rigidbody ScheduleOne.AvatarFramework.Ragdoll::get_RootRigidbody() | 0x421DC0 | 0x420FC0 | 5 |
| UnityEngine.Rigidbody[] ScheduleOne.AvatarFramework.Ragdoll::get_Rigidbodies() | 0x423EA0 | 0x4230A0 | 5 |
| System.Void ScheduleOne.AvatarFramework.Ragdoll::.ctor(UnityEngine.Rigidbody[],UnityEngine.CharacterJoint[],UnityEngine.Rigidbody,UnityEngine.Rigidbody[]) | 0x7D9060 | 0x7D8260 | 882 |
| System.Void ScheduleOne.AvatarFramework.Ragdoll::Destroy() | 0x7D8D20 | 0x7D7F20 | 340 |
| System.Void ScheduleOne.AvatarFramework.Ragdoll::SetGravityMultiplier(System.Single) | 0x7D8EC0 | 0x7D80C0 | 401 |
| System.Void ScheduleOne.AvatarFramework.Ragdoll::ApplyRagdollForce(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.ForceMode) | 0x7D8BE0 | 0x7D7DE0 | 308 |
| UnityEngine.Vector3 ScheduleOne.AvatarFramework.Ragdoll::GetRootVelocity() | 0x7D8E80 | 0x7D8080 | 59 |
| System.Void ScheduleOne.AvatarFramework.Ragdoll/<>c__DisplayClass13_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Single ScheduleOne.AvatarFramework.Ragdoll/<>c__DisplayClass13_0::<ApplyRagdollForce>b__0(UnityEngine.Rigidbody) | 0x7DC840 | 0x7DBA40 | 87 |
| UnityEngine.Rigidbody ScheduleOne.Combat.PhysicsDamageable::get_Rb() | 0x421DC0 | 0x420FC0 | 5 |
| System.Void ScheduleOne.Combat.PhysicsDamageable::set_Rb(UnityEngine.Rigidbody) | 0x421E00 | 0x421000 | 13 |
| System.Void ScheduleOne.Combat.PhysicsDamageable::add_OnImpacted(System.Action`1<ScheduleOne.Combat.Impact>) | 0x99BCE0 | 0x99AEE0 | 161 |
| System.Void ScheduleOne.Combat.PhysicsDamageable::remove_OnImpacted(System.Action`1<ScheduleOne.Combat.Impact>) | 0x99BD90 | 0x99AF90 | 161 |
| System.Void ScheduleOne.Combat.PhysicsDamageable::Awake() | 0x99BA40 | 0x99AC40 | 73 |
| System.Void ScheduleOne.Combat.PhysicsDamageable::SendImpact(ScheduleOne.Combat.Impact) | 0x99BC40 | 0x99AE40 | 17 |
| System.Void ScheduleOne.Combat.PhysicsDamageable::ReceiveImpact(ScheduleOne.Combat.Impact) | 0x99BA90 | 0x99AC90 | 423 |
| System.Void ScheduleOne.Combat.PhysicsDamageable::.ctor() | 0x99BC60 | 0x99AE60 | 126 |
| UnityEngine.GameObject ScheduleOne.Combat.PhysicsDamageable::ScheduleOne.Combat.IDamageable.get_gameObject() | 0x6328F0 | 0x631AF0 | 7 |

Полные поля и offsets: [selected-types-fields](../EVIDENCE/current/selected-types-fields.json). Public proxy API: [interop-selected-api](../EVIDENCE/current/interop-selected-api.json).

## Сохранённые native roots
- [System.Void ScheduleOne.GamePhysics.PhysicsManager::SetGravityMultiplier(FishNet.Connection.NetworkConnection,System.Single)](../EVIDENCE/current/native/58B880.asm.txt)
- [System.Void ScheduleOne.GamePhysics.PhysicsManager::RpcLogic___SetGravityMultiplier_530160725(FishNet.Connection.NetworkConnection,System.Single)](../EVIDENCE/current/native/58B420.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Ragdoll::SetGravityMultiplier(System.Single)](../EVIDENCE/current/native/7D8EC0.asm.txt)

[Native edge records](../EVIDENCE/current/native-edges.json). [Правила aliasing и scope](../REVERSE_ENGINEERING/EVIDENCE_RULES.md). [Исторический NPC report](../EVIDENCE/phase2/REPORT.ru.md). [Mod call sites](../EVIDENCE/current/mod-call-sites.json).
