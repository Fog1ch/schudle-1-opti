# Rendering и GPU workload

## Scope и подтверждённые наблюдения
Новый подтверждённый механизм: ShadowLODController регистрирует movement event камеры. UpdateShadows вычисляет squared distance, выбирает soft/hard/none, затем сравнивает _appliedShadowsMode (+0x40). При совпадении setter loop не выполняется. Дедупликация shadow setters уже реализована.
OcclusionManager.Update в experimental namespace вызывает GetObjectVisiblityState, WorldPositionToOcclusionIndex и OcclusionObject.SetActive. Это наличие кода, НЕ доказательство активного компонента в level1.
URP и AmplifyImpostors присутствуют в assembly metadata. Активный pipeline asset, render passes, shader variants, draw calls, GPU time и resident VRAM не декодированы/не измерены. Исторический D3D11/3965 MB и BC6H fallback из phase1 помечены историческими, не текущими измерениями.

## Возможности, пока гипотезы
Сначала установить активные renderer/volume/light assets. Не предлагать существующие LOD/dedup как новые. Texture budget 8000 MB требует измерения всей GPU памяти, не только texture counters.

## Риски и неизвестное
Качество теней, pop-in, visual parity, ложное отождествление serialized object counts с активной GPU нагрузкой.

## Адресуемые методы
| Метод | RVA | Offset | Cpp2IL bytes |
|---|---|---|---|
| System.Void ScheduleOne.Lighting.ShadowLODController::Awake() | 0x722B00 | 0x721D00 | 449 |
| System.Void ScheduleOne.Lighting.ShadowLODController::OnEnable() | 0x722DD0 | 0x721FD0 | 104 |
| System.Void ScheduleOne.Lighting.ShadowLODController::OnDestroy() | 0x722CD0 | 0x721ED0 | 245 |
| System.Void ScheduleOne.Lighting.ShadowLODController::UpdateShadows() | 0x723040 | 0x722240 | 434 |
| System.Void ScheduleOne.Lighting.ShadowLODController::RecalculateDistances() | 0x722E40 | 0x722040 | 29 |
| System.Void ScheduleOne.Lighting.ShadowLODController::.ctor() | 0x723200 | 0x722400 | 21 |
| System.Void ScheduleOne.Lighting.ShadowLODController::<Awake>g__Register\|8_0() | 0x722E60 | 0x722060 | 469 |
| System.Void ScheduleOne.Avatar.Impostors.AvatarImpostor::Awake() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Void ScheduleOne.Avatar.Impostors.AvatarImpostor::SetTexture(UnityEngine.Texture2D) | 0x799DE0 | 0x798FE0 | 151 |
| System.Void ScheduleOne.Avatar.Impostors.AvatarImpostor::LateUpdate() | 0x799D00 | 0x798F00 | 99 |
| System.Void ScheduleOne.Avatar.Impostors.AvatarImpostor::UpdatePosition() | 0x799D00 | 0x798F00 | 99 |
| System.Void ScheduleOne.Avatar.Impostors.AvatarImpostor::Enable() | 0x799C80 | 0x798E80 | 126 |
| System.Void ScheduleOne.Avatar.Impostors.AvatarImpostor::Disable() | 0x70A140 | 0x709340 | 38 |
| System.Void ScheduleOne.Avatar.Impostors.AvatarImpostor::SetRotation(System.Single) | 0x799D70 | 0x798F70 | 102 |
| System.Void ScheduleOne.Avatar.Impostors.AvatarImpostor::.ctor() | 0x41D490 | 0x41C690 | 7 |
| System.Void ScheduleOne.AvatarFramework.AvatarLODBoundsUpdater::Awake() | 0x7CC0E0 | 0x7CB2E0 | 361 |
| System.Void ScheduleOne.AvatarFramework.AvatarLODBoundsUpdater::InfrequentUpdate() | 0x7CC250 | 0x7CB450 | 416 |
| System.Void ScheduleOne.AvatarFramework.AvatarLODBoundsUpdater::OnRagdollChange(System.Boolean) | 0x7CC400 | 0x7CB600 | 7 |
| System.Void ScheduleOne.AvatarFramework.AvatarLODBoundsUpdater::Recalculate() | 0x7CC410 | 0x7CB610 | 328 |
| System.Void ScheduleOne.AvatarFramework.AvatarLODBoundsUpdater::.ctor() | 0x7CC560 | 0x7CB760 | 81 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::RunOcclusionBake() | 0x9B1420 | 0x9B0620 | 7 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::Update() | 0x9B16F0 | 0x9B08F0 | 458 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::SetActive(System.Boolean) | 0x9B1430 | 0x9B0630 | 374 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::DoOcclusionBakeRoutine() | 0x9AEE00 | 0x9AE000 | 2786 |
| System.Boolean ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::IsObjectVisible(UnityEngine.Vector3,ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject) | 0x9AFDA0 | 0x9AEFA0 | 2328 |
| System.Boolean ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::IsObjectCornersVisible(UnityEngine.Vector3,UnityEngine.Vector3[]) | 0x9AF9D0 | 0x9AEBD0 | 161 |
| System.Boolean ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::IsObjectFaceVisible(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single,System.Int32) | 0x9AFA80 | 0x9AEC80 | 787 |
| System.Boolean ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::IsPointVisible(UnityEngine.Vector3,UnityEngine.Vector3) | 0x9B06C0 | 0x9AF8C0 | 855 |
| UnityEngine.Vector3Int ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::WorldToCellIndex(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3) | 0x9B1BE0 | 0x9B0DE0 | 320 |
| System.Boolean ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::GetObjectVisiblityState(System.Int32,System.Int32) | 0x9AF8F0 | 0x9AEAF0 | 71 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::SetObjectStateBasedOnPosition(UnityEngine.Vector3) | 0x9B15B0 | 0x9B07B0 | 304 |
| System.Boolean ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::GetStateAtWorldPosition(UnityEngine.Vector3,System.Int32) | 0x9AF940 | 0x9AEB40 | 134 |
| System.Int32 ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::WorldPositionToOcclusionIndex(UnityEngine.Vector3) | 0x9B18C0 | 0x9B0AC0 | 786 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::DebugCellRays() | 0x9AE200 | 0x9AD400 | 1324 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::CalculateCells() | 0x9ADB40 | 0x9ACD40 | 1420 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::OnDrawGizmos() | 0x9B0A20 | 0x9AFC20 | 2548 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::DebugSpecifiedObjectState() | 0x9AE730 | 0x9AD930 | 1740 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::CheckData() | 0x9AE0D0 | 0x9AD2D0 | 295 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::.ctor() | 0x9B1D20 | 0x9B0F20 | 334 |
| UnityEngine.Vector3 ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::get_Size() | 0x4A57D0 | 0x4A49D0 | 19 |
| System.Int32 ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::get_Subdivisions() | 0x482440 | 0x481640 | 4 |
| System.Boolean ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::get_IncludeLeft() | 0x99DD10 | 0x99CF10 | 5 |
| System.Boolean ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::get_IncludeRight() | 0x9B3600 | 0x9B2800 | 5 |
| System.Boolean ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::get_IncludeTop() | 0x9B3610 | 0x9B2810 | 5 |
| System.Boolean ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::get_IncludeBottom() | 0x9B35F0 | 0x9B27F0 | 5 |
| System.Boolean ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::get_IncludeFront() | 0x465080 | 0x464280 | 5 |
| System.Boolean ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::get_IncludeBack() | 0x4994C0 | 0x4986C0 | 5 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::Start() | 0x9B3540 | 0x9B2740 | 12 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::OnDrawGizmos() | 0x9B2A60 | 0x9B1C60 | 2116 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::DrawFaceChunks(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single,System.Single,System.Int32) | 0x9B1F50 | 0x9B1150 | 1009 |
| UnityEngine.Vector3[] ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::GetCornerPositions() | 0x9B2350 | 0x9B1550 | 1710 |
| System.Int32 ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::GetNumberOfVertices(System.Int32) | 0x9B2A00 | 0x9B1C00 | 92 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::SetObjectOcclusion(System.Boolean) | 0x9B3530 | 0x9B2730 | 14 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::SetActive(System.Boolean) | 0x9B32B0 | 0x9B24B0 | 628 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::CalculateNumberOfVertices() | 0x9B1E70 | 0x9B1070 | 223 |
| System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::.ctor() | 0x9B3550 | 0x9B2750 | 145 |

Полные поля и offsets: [selected-types-fields](../EVIDENCE/current/selected-types-fields.json). Public proxy API: [interop-selected-api](../EVIDENCE/current/interop-selected-api.json).

## Сохранённые native roots
- [System.Void ScheduleOne.Lighting.ShadowLODController::OnDestroy()](../EVIDENCE/current/native/722CD0.asm.txt)
- [System.Void ScheduleOne.Avatar.Impostors.AvatarImpostor::LateUpdate()](../EVIDENCE/current/native/799D00.asm.txt)
- [System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionManager::Update()](../EVIDENCE/current/native/9B16F0.asm.txt)
- [System.Void ScheduleOne.Development.Experimental.OcclusionCulling.OcclusionObject::Start()](../EVIDENCE/current/native/9B3540.asm.txt)
- [System.Void ScheduleOne.Lighting.ShadowLODController::Awake()](../EVIDENCE/current/native/722B00.asm.txt)
- [System.Void ScheduleOne.Lighting.ShadowLODController::OnEnable()](../EVIDENCE/current/native/722DD0.asm.txt)
- [System.Void ScheduleOne.Lighting.ShadowLODController::UpdateShadows()](../EVIDENCE/current/native/723040.asm.txt)
- [System.Void ScheduleOne.Lighting.ShadowLODController::RecalculateDistances()](../EVIDENCE/current/native/722E40.asm.txt)
- [System.Void ScheduleOne.Lighting.ShadowLODController::.ctor()](../EVIDENCE/current/native/723200.asm.txt)
- [System.Void ScheduleOne.Lighting.ShadowLODController::<Awake>g__Register|8_0()](../EVIDENCE/current/native/722E60.asm.txt)

[Native edge records](../EVIDENCE/current/native-edges.json). [Правила aliasing и scope](../REVERSE_ENGINEERING/EVIDENCE_RULES.md). [Исторический NPC report](../EVIDENCE/phase2/REPORT.ru.md). [Mod call sites](../EVIDENCE/current/mod-call-sites.json).
