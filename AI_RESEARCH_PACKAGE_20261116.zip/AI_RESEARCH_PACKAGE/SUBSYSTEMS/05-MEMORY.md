# Memory management и allocations

## Scope и подтверждённые наблюдения
Phase2: NativeArray CircularQueue.Enqueue не выделяет heap на исследованном пути; agent.path создаёт новый NavMeshPath, corners кэшируется на конкретном path object. Ladder allocation условная при переходе, не каждый Update.
Новые roots ObjectPool.Get/Return показывают существующий generic pool API, не его все call sites. GoonPool.Update совпадает с общим ret RVA 0x43FEC0 и не является горячей работой.
TimeManager tick coroutine содержит allocation helper и WaitForSecondsRealtime path; ActionList имеет собственную staggered routine. Типы некоторых generic shared constructors не следует угадывать по единственному символу адреса.
Увеличенные native allocator blocks в boot.config и GC time slice известны как конфигурация. Их польза, peak/fallback и GC bytes/sec неизвестны.

## Возможности, пока гипотезы
Предварительная исследовательская возможность: уменьшать ненужные временные объекты только после аудита lifetime и branch frequency. Pooling NavMeshPath пока не обоснован.

## Риски и неизвестное
Native/managed ownership, shared handles, mutation, GC timing, ложный вывод по размеру файла или аллокациям на редкой ветви.

## Адресуемые методы
| Метод | RVA | Offset | Cpp2IL bytes |
|---|---|---|---|
| System.Void ActionList::.ctor(System.Boolean) | 0x519E70 | 0x519070 | 137 |
| System.Void ActionList::InvokeAll() | 0x519C90 | 0x518E90 | 255 |
| System.Void ActionList::InvokeAllStaggered(System.Single) | 0x519B50 | 0x518D50 | 304 |
| System.Void ActionList::CancelStaggeredInvoke() | 0x519A40 | 0x518C40 | 162 |
| System.Void ActionList::Clear() | 0x519AF0 | 0x518CF0 | 95 |
| System.Void ActionList::Add(System.Action) | 0x519990 | 0x518B90 | 173 |
| System.Void ActionList::Remove(System.Action) | 0x519D90 | 0x518F90 | 83 |
| ActionList ActionList::op_Addition(ActionList,System.Action) | 0x519F00 | 0x519100 | 185 |
| ActionList ActionList::op_Subtraction(ActionList,System.Action) | 0x519FC0 | 0x5191C0 | 97 |
| System.Collections.IEnumerator ActionList::<InvokeAllStaggered>g__StaggeredInvoke\|6_0(System.Single) | 0x519DF0 | 0x518FF0 | 121 |
| System.Void ActionList/<<InvokeAllStaggered>g__StaggeredInvoke\|6_0>d::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void ActionList/<<InvokeAllStaggered>g__StaggeredInvoke\|6_0>d::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean ActionList/<<InvokeAllStaggered>g__StaggeredInvoke\|6_0>d::MoveNext() | 0x52E6A0 | 0x52D8A0 | 735 |
| System.Object ActionList/<<InvokeAllStaggered>g__StaggeredInvoke\|6_0>d::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ActionList/<<InvokeAllStaggered>g__StaggeredInvoke\|6_0>d::System.Collections.IEnumerator.Reset() | 0x52E990 | 0x52DB90 | 62 |
| System.Object ActionList/<<InvokeAllStaggered>g__StaggeredInvoke\|6_0>d::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.DevUtilities.ObjectPool`1::.ctor(T,System.Int32,UnityEngine.Transform,FishNet.Object.NetworkBehaviour,System.Action`1<T>,System.Action`1<T>) | 0x1067710 | 0x1066910 | 217 |
| System.Void ScheduleOne.DevUtilities.ObjectPool`1::Prewarm(System.Int32) | 0x1066790 | 0x1065990 | 20 |
| System.Void ScheduleOne.DevUtilities.ObjectPool`1::Create(System.Int32) | 0x1065B20 | 0x1064D20 | 349 |
| T ScheduleOne.DevUtilities.ObjectPool`1::Get(UnityEngine.Transform) | 0x1065FE0 | 0x10651E0 | 133 |
| T ScheduleOne.DevUtilities.ObjectPool`1::Get(UnityEngine.Vector3,UnityEngine.Quaternion,UnityEngine.Transform) | 0x1066250 | 0x1065450 | 234 |
| System.Void ScheduleOne.DevUtilities.ObjectPool`1::Return(T) | 0x1066E40 | 0x1066040 | 193 |
| System.Int32 ScheduleOne.Cartel.GoonPool::get_UnspawnedGoonCount() | 0x76F910 | 0x76EB10 | 60 |
| System.Void ScheduleOne.Cartel.GoonPool::Awake() | 0x76E9B0 | 0x76DBB0 | 344 |
| System.Void ScheduleOne.Cartel.GoonPool::Update() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Collections.Generic.List`1<ScheduleOne.Cartel.CartelGoon> ScheduleOne.Cartel.GoonPool::SpawnMultipleGoons(UnityEngine.Vector3,System.Int32,System.Boolean) | 0x76F660 | 0x76E860 | 503 |
| ScheduleOne.Cartel.CartelGoonAppearance ScheduleOne.Cartel.GoonPool::GetRandomAppearance() | 0x76EF10 | 0x76E110 | 513 |
| ScheduleOne.Cartel.CartelGoon ScheduleOne.Cartel.GoonPool::SpawnGoon(UnityEngine.Vector3) | 0x76F390 | 0x76E590 | 712 |
| System.Void ScheduleOne.Cartel.GoonPool::ReturnToPool(ScheduleOne.Cartel.CartelGoon) | 0x76F230 | 0x76E430 | 343 |
| ScheduleOne.Map.NPCEnterableBuilding ScheduleOne.Cartel.GoonPool::GetNearestExitBuilding(UnityEngine.Vector3) | 0x76EC20 | 0x76DE20 | 474 |
| ScheduleOne.Core.Avatar.NakedAppearanceObject ScheduleOne.Cartel.GoonPool::GetAppearanceAtIndex(System.Boolean,System.Int32) | 0x76EB10 | 0x76DD10 | 258 |
| ScheduleOne.Core.Avatar.Outfit ScheduleOne.Cartel.GoonPool::GetOutfitAtIndex(System.Boolean,System.Int32) | 0x76EE00 | 0x76E000 | 258 |
| ScheduleOne.VoiceOver.VODatabase ScheduleOne.Cartel.GoonPool::GetVoiceAtIndex(System.Boolean,System.Int32) | 0x76F120 | 0x76E320 | 258 |
| System.Void ScheduleOne.Cartel.GoonPool::.ctor() | 0x76F860 | 0x76EA60 | 165 |
| System.Collections.Generic.List`1<ScheduleOne.NPCs.NPCPathCache/PathCache> ScheduleOne.NPCs.NPCPathCache::get_Paths() | 0x423EA0 | 0x4230A0 | 5 |
| System.Void ScheduleOne.NPCs.NPCPathCache::set_Paths(System.Collections.Generic.List`1<ScheduleOne.NPCs.NPCPathCache/PathCache>) | 0x469210 | 0x468410 | 13 |
| UnityEngine.AI.NavMeshPath ScheduleOne.NPCs.NPCPathCache::GetPath(UnityEngine.Vector3,UnityEngine.Vector3,System.Single) | 0x8FB5B0 | 0x8FA7B0 | 437 |
| System.Void ScheduleOne.NPCs.NPCPathCache::AddPath(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.AI.NavMeshPath) | 0x8FB4A0 | 0x8FA6A0 | 263 |
| System.Void ScheduleOne.NPCs.NPCPathCache::.ctor() | 0x8FB770 | 0x8FA970 | 119 |
| System.Void ScheduleOne.NPCs.NPCPathCache/PathCache::.ctor(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.AI.NavMeshPath) | 0x8FF4B0 | 0x8FE6B0 | 82 |

Полные поля и offsets: [selected-types-fields](../EVIDENCE/current/selected-types-fields.json). Public proxy API: [interop-selected-api](../EVIDENCE/current/interop-selected-api.json).

## Сохранённые native roots
- [T ScheduleOne.DevUtilities.ObjectPool`1::Get(UnityEngine.Transform)](../EVIDENCE/current/native/1065FE0.asm.txt)
- [T ScheduleOne.DevUtilities.ObjectPool`1::Get(UnityEngine.Vector3,UnityEngine.Quaternion,UnityEngine.Transform)](../EVIDENCE/current/native/1066250.asm.txt)
- [System.Void ScheduleOne.DevUtilities.ObjectPool`1::Return(T)](../EVIDENCE/current/native/1066E40.asm.txt)
- [System.Void ScheduleOne.Cartel.GoonPool::Update()](../EVIDENCE/current/native/43FEC0.asm.txt)
- [System.Collections.Generic.List`1<ScheduleOne.NPCs.NPCPathCache/PathCache> ScheduleOne.NPCs.NPCPathCache::get_Paths()](../EVIDENCE/current/native/423EA0.asm.txt)
- [System.Void ScheduleOne.NPCs.NPCPathCache::set_Paths(System.Collections.Generic.List`1<ScheduleOne.NPCs.NPCPathCache/PathCache>)](../EVIDENCE/current/native/469210.asm.txt)
- [UnityEngine.AI.NavMeshPath ScheduleOne.NPCs.NPCPathCache::GetPath(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)](../EVIDENCE/current/native/8FB5B0.asm.txt)
- [System.Void ScheduleOne.NPCs.NPCPathCache::AddPath(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.AI.NavMeshPath)](../EVIDENCE/current/native/8FB4A0.asm.txt)
- [System.Void ScheduleOne.NPCs.NPCPathCache::.ctor()](../EVIDENCE/current/native/8FB770.asm.txt)
- [System.Void ActionList::InvokeAllStaggered(System.Single)](../EVIDENCE/current/native/519B50.asm.txt)
- [System.Boolean ActionList/<<InvokeAllStaggered>g__StaggeredInvoke|6_0>d::MoveNext()](../EVIDENCE/current/native/52E6A0.asm.txt)

[Native edge records](../EVIDENCE/current/native-edges.json). [Правила aliasing и scope](../REVERSE_ENGINEERING/EVIDENCE_RULES.md). [Исторический NPC report](../EVIDENCE/phase2/REPORT.ru.md). [Mod call sites](../EVIDENCE/current/mod-call-sites.json).
