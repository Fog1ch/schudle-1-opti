# Asset loading и resource management

## Scope и подтверждённые наблюдения
LoadManager StartGame coroutine содержит SceneManager.LoadSceneAsync и проверку AsyncOperation.isDone, LoadRequest и UnityEvent callbacks. CleanUp вызывает GUIDManager.Clear и NavMeshUtility.ClearCache. Это не доказательство очистки именно NPCPathCache.
Новый SerializedFile v22 extension прочитал external references девяти контейнеров: 39 записей. level1 ссылается на globalgamemanagers.assets, resources.assets, sharedassets1.assets и sharedassets0.assets плюс built-in resource. Добавлен object index с path_id, class_id, file offset и serialized byte size. Candidate names эвристические, не schema-verified.
Texture mip flags, compression formats, meshes, shader bytecode, full PPtr graph, remote Addressables и resource lifetime полностью не восстановлены. Содержимое сохранений не читалось.

## Возможности, пока гипотезы
Продолжить versioned schema decoding адресуемых объектов, сначала GraphicsSettings/QualitySettings и texture headers. Оптимизация загрузки без layout и invalidation proof преждевременна.

## Риски и неизвестное
Повреждение ресурсов, reference IDs, built-in virtual paths, зависимость от точной Unity версии, загрузка не равна одновременной резидентности.

## Адресуемые методы
| Метод | RVA | Offset | Cpp2IL bytes |
|---|---|---|---|
| System.String ScheduleOne.Persistence.LoadManager::get_DefaultTutorialSaveFolder() | 0x589E80 | 0x589080 | 133 |
| System.Boolean ScheduleOne.Persistence.LoadManager::get_IsInGameScene() | 0x589F10 | 0x589110 | 196 |
| System.Boolean ScheduleOne.Persistence.LoadManager::get_IsGameLoaded() | 0x45FBC0 | 0x45EDC0 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager::set_IsGameLoaded(System.Boolean) | 0x45FBD0 | 0x45EDD0 | 4 |
| System.Boolean ScheduleOne.Persistence.LoadManager::get_IsLoading() | 0x589FE0 | 0x5891E0 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager::set_IsLoading(System.Boolean) | 0x58A0F0 | 0x5892F0 | 4 |
| System.Single ScheduleOne.Persistence.LoadManager::get_TimeSinceGameLoaded() | 0x463B00 | 0x462D00 | 6 |
| System.Void ScheduleOne.Persistence.LoadManager::set_TimeSinceGameLoaded(System.Single) | 0x58A110 | 0x589310 | 6 |
| System.Boolean ScheduleOne.Persistence.LoadManager::get_DebugMode() | 0x465080 | 0x464280 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager::set_DebugMode(System.Boolean) | 0x49A650 | 0x499850 | 4 |
| ScheduleOne.Persistence.LoadManager/ELoadStatus ScheduleOne.Persistence.LoadManager::get_LoadStatus() | 0x499500 | 0x498700 | 4 |
| System.Void ScheduleOne.Persistence.LoadManager::set_LoadStatus(ScheduleOne.Persistence.LoadManager/ELoadStatus) | 0x4ADFB0 | 0x4AD1B0 | 4 |
| System.String ScheduleOne.Persistence.LoadManager::get_LoadedGameFolderPath() | 0x421DE0 | 0x420FE0 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager::set_LoadedGameFolderPath(System.String) | 0x421E20 | 0x421020 | 13 |
| ScheduleOne.Persistence.SaveInfo ScheduleOne.Persistence.LoadManager::get_ActiveSaveInfo() | 0x4610C0 | 0x4602C0 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager::set_ActiveSaveInfo(ScheduleOne.Persistence.SaveInfo) | 0x49EF90 | 0x49E190 | 13 |
| ScheduleOne.Persistence.SaveInfo ScheduleOne.Persistence.LoadManager::get_StoredSaveInfo() | 0x48DD60 | 0x48CF60 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager::set_StoredSaveInfo(ScheduleOne.Persistence.SaveInfo) | 0x58A100 | 0x589300 | 13 |
| System.Void ScheduleOne.Persistence.LoadManager::add_onLoadConfigurations(System.Action) | 0x589D80 | 0x588F80 | 242 |
| System.Void ScheduleOne.Persistence.LoadManager::remove_onLoadConfigurations(System.Action) | 0x589FF0 | 0x5891F0 | 242 |
| System.Void ScheduleOne.Persistence.LoadManager::Awake() | 0x585E20 | 0x585020 | 57 |
| System.Void ScheduleOne.Persistence.LoadManager::Start() | 0x5885E0 | 0x5877E0 | 1544 |
| System.Void ScheduleOne.Persistence.LoadManager::Bananas() | 0x585E60 | 0x585060 | 1001 |
| System.Void ScheduleOne.Persistence.LoadManager::InitializeItemLoaders() | 0x587340 | 0x586540 | 436 |
| System.Void ScheduleOne.Persistence.LoadManager::InitializeObjectLoaders() | 0x5876C0 | 0x5868C0 | 810 |
| System.Void ScheduleOne.Persistence.LoadManager::InitializeNPCLoaders() | 0x587500 | 0x586700 | 436 |
| System.Void ScheduleOne.Persistence.LoadManager::Update() | 0x589760 | 0x588960 | 751 |
| System.Void ScheduleOne.Persistence.LoadManager::QueueLoadRequest(ScheduleOne.Persistence.LoadRequest) | 0x587C80 | 0x586E80 | 170 |
| System.Void ScheduleOne.Persistence.LoadManager::DequeueLoadRequest(ScheduleOne.Persistence.LoadRequest) | 0x586890 | 0x585A90 | 83 |
| ScheduleOne.Persistence.ItemLoaders.ItemLoader ScheduleOne.Persistence.LoadManager::GetItemLoader(System.String) | 0x586C90 | 0x585E90 | 306 |
| ScheduleOne.Persistence.Loaders.BuildableItemLoader ScheduleOne.Persistence.LoadManager::GetObjectLoader(System.String) | 0x587200 | 0x586400 | 306 |
| ScheduleOne.Persistence.Loaders.LegacyNPCLoader ScheduleOne.Persistence.LoadManager::GetLegacyNPCLoader(System.String) | 0x586DD0 | 0x585FD0 | 306 |
| ScheduleOne.Persistence.Loaders.NPCLoader ScheduleOne.Persistence.LoadManager::GetNPCLoader(System.String) | 0x5870C0 | 0x5862C0 | 306 |
| System.String ScheduleOne.Persistence.LoadManager::GetLoadStatusText() | 0x586F10 | 0x586110 | 408 |
| System.Void ScheduleOne.Persistence.LoadManager::StartGame(ScheduleOne.Persistence.SaveInfo,System.Boolean,System.Boolean) | 0x5881C0 | 0x5873C0 | 926 |
| System.Void ScheduleOne.Persistence.LoadManager::LoadTutorialAsClient() | 0x587B90 | 0x586D90 | 227 |
| System.Void ScheduleOne.Persistence.LoadManager::LoadAsClient(System.String) | 0x5879F0 | 0x586BF0 | 260 |
| System.Void ScheduleOne.Persistence.LoadManager::StartLoadErrorAutosubmit() | 0x588560 | 0x587760 | 113 |
| System.Void ScheduleOne.Persistence.LoadManager::SetWaitingForHostLoad() | 0x5881B0 | 0x5873B0 | 12 |
| System.Void ScheduleOne.Persistence.LoadManager::LoadLastSave() | 0x587B00 | 0x586D00 | 133 |
| System.Void ScheduleOne.Persistence.LoadManager::CleanUp() | 0x586250 | 0x585450 | 1589 |
| System.Void ScheduleOne.Persistence.LoadManager::ExitToMenu(ScheduleOne.Persistence.SaveInfo,ScheduleOne.UI.MainMenu.MainMenuPopup/Data,System.Boolean) | 0x5868F0 | 0x585AF0 | 927 |
| System.Boolean ScheduleOne.Persistence.LoadManager::TryLoadSaveInfo(System.String,System.Int32,ScheduleOne.Persistence.SaveInfo&,System.Boolean) | 0x588BF0 | 0x587DF0 | 2436 |
| System.Void ScheduleOne.Persistence.LoadManager::RefreshSaveInfo() | 0x587D30 | 0x586F30 | 1149 |
| System.Void ScheduleOne.Persistence.LoadManager::AddStaggeredReplicator(ScheduleOne.Networking.IStaggeredReplicator) | 0x585CF0 | 0x584EF0 | 291 |
| System.Void ScheduleOne.Persistence.LoadManager::.ctor() | 0x589BB0 | 0x588DB0 | 462 |
| System.Void ScheduleOne.Persistence.LoadManager::.cctor() | 0x589A50 | 0x588C50 | 350 |
| System.Void ScheduleOne.Persistence.LoadManager::<LoadAsClient>g__PlayerSpawned\|76_8() | 0x589580 | 0x588780 | 353 |
| System.Collections.IEnumerator ScheduleOne.Persistence.LoadManager::<StartLoadErrorAutosubmit>g__Wait\|77_0() | 0x5896F0 | 0x5888F0 | 103 |
| System.Void ScheduleOne.Persistence.LoadManager/<<StartLoadErrorAutosubmit>g__Wait\|77_0>d::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void ScheduleOne.Persistence.LoadManager/<<StartLoadErrorAutosubmit>g__Wait\|77_0>d::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<<StartLoadErrorAutosubmit>g__Wait\|77_0>d::MoveNext() | 0x5925D0 | 0x5917D0 | 211 |
| System.Object ScheduleOne.Persistence.LoadManager/<<StartLoadErrorAutosubmit>g__Wait\|77_0>d::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager/<<StartLoadErrorAutosubmit>g__Wait\|77_0>d::System.Collections.IEnumerator.Reset() | 0x5926B0 | 0x5918B0 | 62 |
| System.Object ScheduleOne.Persistence.LoadManager/<<StartLoadErrorAutosubmit>g__Wait\|77_0>d::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c::.cctor() | 0x593020 | 0x592220 | 103 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c::<StartGame>b__74_6() | 0x592960 | 0x591B60 | 7 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c::<StartGame>b__74_1() | 0x592970 | 0x591B70 | 35 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c::<StartGame>b__74_2() | 0x592A20 | 0x591C20 | 127 |
| System.Int32 ScheduleOne.Persistence.LoadManager/<>c::<StartGame>b__74_3(ScheduleOne.Persistence.IBaseSaveable) | 0x592AA0 | 0x591CA0 | 173 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c::<StartGame>b__74_4() | 0x592B50 | 0x591D50 | 96 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c::<LoadTutorialAsClient>b__75_2() | 0x592960 | 0x591B60 | 7 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c::<LoadTutorialAsClient>b__75_3() | 0x592970 | 0x591B70 | 35 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c::<LoadTutorialAsClient>b__75_4() | 0x5929A0 | 0x591BA0 | 127 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c::<LoadAsClient>b__76_4() | 0x592730 | 0x591930 | 111 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c::<LoadAsClient>b__76_5() | 0x5927A0 | 0x5919A0 | 127 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c::<LoadAsClient>b__76_6() | 0x592820 | 0x591A20 | 96 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c::<LoadAsClient>b__76_7() | 0x592890 | 0x591A90 | 206 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass69_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass69_0::<GetItemLoader>b__0(ScheduleOne.Persistence.ItemLoaders.ItemLoader) | 0x592E50 | 0x592050 | 61 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass70_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass70_0::<GetObjectLoader>b__0(ScheduleOne.Persistence.Loaders.BuildableItemLoader) | 0x592E90 | 0x592090 | 61 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass71_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass71_0::<GetLegacyNPCLoader>b__0(ScheduleOne.Persistence.Loaders.LegacyNPCLoader) | 0x592E90 | 0x592090 | 61 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass72_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass72_0::<GetNPCLoader>b__0(ScheduleOne.Persistence.Loaders.NPCLoader) | 0x592E90 | 0x592090 | 61 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass74_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Collections.IEnumerator ScheduleOne.Persistence.LoadManager/<>c__DisplayClass74_0::<StartGame>g__LoadRoutine\|0() | 0x592ED0 | 0x5920D0 | 103 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass74_0/<<StartGame>g__LoadRoutine\|0>d::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass74_0/<<StartGame>g__LoadRoutine\|0>d::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass74_0/<<StartGame>g__LoadRoutine\|0>d::MoveNext() | 0x590A80 | 0x58FC80 | 6880 |
| System.Object ScheduleOne.Persistence.LoadManager/<>c__DisplayClass74_0/<<StartGame>g__LoadRoutine\|0>d::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass74_0/<<StartGame>g__LoadRoutine\|0>d::System.Collections.IEnumerator.Reset() | 0x592590 | 0x591790 | 62 |
| System.Object ScheduleOne.Persistence.LoadManager/<>c__DisplayClass74_0/<<StartGame>g__LoadRoutine\|0>d::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass74_1::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass74_1::<StartGame>g__Done\|5(FishNet.Transporting.ServerConnectionStateArgs) | 0x5B3290 | 0x5B2490 | 647 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass75_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Collections.IEnumerator ScheduleOne.Persistence.LoadManager/<>c__DisplayClass75_0::<LoadTutorialAsClient>g__LoadRoutine\|0() | 0x5B35C0 | 0x5B27C0 | 103 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass75_0::<LoadTutorialAsClient>b__1() | 0x5B3520 | 0x5B2720 | 145 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass75_0/<<LoadTutorialAsClient>g__LoadRoutine\|0>d::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass75_0/<<LoadTutorialAsClient>g__LoadRoutine\|0>d::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass75_0/<<LoadTutorialAsClient>g__LoadRoutine\|0>d::MoveNext() | 0x5AFAB0 | 0x5AECB0 | 4352 |
| System.Object ScheduleOne.Persistence.LoadManager/<>c__DisplayClass75_0/<<LoadTutorialAsClient>g__LoadRoutine\|0>d::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass75_0/<<LoadTutorialAsClient>g__LoadRoutine\|0>d::System.Collections.IEnumerator.Reset() | 0x5B0BE0 | 0x5AFDE0 | 62 |
| System.Object ScheduleOne.Persistence.LoadManager/<>c__DisplayClass75_0/<<LoadTutorialAsClient>g__LoadRoutine\|0>d::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Collections.IEnumerator ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_0::<LoadAsClient>g__LoadRoutine\|0() | 0x5B38A0 | 0x5B2AA0 | 103 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_0::<LoadAsClient>b__1() | 0x5B3630 | 0x5B2830 | 145 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_0::<LoadAsClient>g__AbortLoadAsClient\|9(System.String) | 0x5B36D0 | 0x5B28D0 | 461 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_0/<<LoadAsClient>g__LoadRoutine\|0>d::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_0/<<LoadAsClient>g__LoadRoutine\|0>d::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_0/<<LoadAsClient>g__LoadRoutine\|0>d::MoveNext() | 0x5AEAE0 | 0x5ADCE0 | 3940 |
| System.Object ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_0/<<LoadAsClient>g__LoadRoutine\|0>d::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_0/<<LoadAsClient>g__LoadRoutine\|0>d::System.Collections.IEnumerator.Reset() | 0x5AFA70 | 0x5AEC70 | 62 |
| System.Object ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_0/<<LoadAsClient>g__LoadRoutine\|0>d::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_1::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_1::<LoadAsClient>g__OnLocalConnectionStateChange\|2(FishNet.Transporting.ClientConnectionStateArgs) | 0x5B3920 | 0x5B2B20 | 12 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_1::<LoadAsClient>b__3() | 0x5B3910 | 0x5B2B10 | 8 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_2::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_2::<LoadAsClient>g__OnAuthResult\|10(System.Boolean) | 0x5B3930 | 0x5B2B30 | 147 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass81_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Collections.IEnumerator ScheduleOne.Persistence.LoadManager/<>c__DisplayClass81_0::<ExitToMenu>g__Load\|0() | 0x5B39D0 | 0x5B2BD0 | 103 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass81_0/<<ExitToMenu>g__Load\|0>d::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass81_0/<<ExitToMenu>g__Load\|0>d::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass81_0/<<ExitToMenu>g__Load\|0>d::MoveNext() | 0x5AE1A0 | 0x5AD3A0 | 2295 |
| System.Object ScheduleOne.Persistence.LoadManager/<>c__DisplayClass81_0/<<ExitToMenu>g__Load\|0>d::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass81_0/<<ExitToMenu>g__Load\|0>d::System.Collections.IEnumerator.Reset() | 0x5AEAA0 | 0x5ADCA0 | 62 |
| System.Object ScheduleOne.Persistence.LoadManager/<>c__DisplayClass81_0/<<ExitToMenu>g__Load\|0>d::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.Persistence.LoadManager/<>c__DisplayClass81_1::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass81_1::<ExitToMenu>b__1() | 0x5B3A40 | 0x5B2C40 | 131 |

Полные поля и offsets: [selected-types-fields](../EVIDENCE/current/selected-types-fields.json). Public proxy API: [interop-selected-api](../EVIDENCE/current/interop-selected-api.json).

## Сохранённые native roots
- [System.Void ScheduleOne.Persistence.LoadManager::Start()](../EVIDENCE/current/native/5885E0.asm.txt)
- [System.Void ScheduleOne.Persistence.LoadManager::Update()](../EVIDENCE/current/native/589760.asm.txt)
- [System.Void ScheduleOne.Persistence.LoadManager::QueueLoadRequest(ScheduleOne.Persistence.LoadRequest)](../EVIDENCE/current/native/587C80.asm.txt)
- [System.Void ScheduleOne.Persistence.LoadManager::DequeueLoadRequest(ScheduleOne.Persistence.LoadRequest)](../EVIDENCE/current/native/586890.asm.txt)
- [System.Void ScheduleOne.Persistence.LoadManager::CleanUp()](../EVIDENCE/current/native/586250.asm.txt)
- [System.Boolean ScheduleOne.Persistence.LoadManager/<<StartLoadErrorAutosubmit>g__Wait|77_0>d::MoveNext()](../EVIDENCE/current/native/5925D0.asm.txt)
- [System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass74_0/<<StartGame>g__LoadRoutine|0>d::MoveNext()](../EVIDENCE/current/native/590A80.asm.txt)
- [System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass75_0/<<LoadTutorialAsClient>g__LoadRoutine|0>d::MoveNext()](../EVIDENCE/current/native/5AFAB0.asm.txt)
- [System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass76_0/<<LoadAsClient>g__LoadRoutine|0>d::MoveNext()](../EVIDENCE/current/native/5AEAE0.asm.txt)
- [System.Boolean ScheduleOne.Persistence.LoadManager/<>c__DisplayClass81_0/<<ExitToMenu>g__Load|0>d::MoveNext()](../EVIDENCE/current/native/5AE1A0.asm.txt)

[Native edge records](../EVIDENCE/current/native-edges.json). [Правила aliasing и scope](../REVERSE_ENGINEERING/EVIDENCE_RULES.md). [Исторический NPC report](../EVIDENCE/phase2/REPORT.ru.md). [Mod call sites](../EVIDENCE/current/mod-call-sites.json).
