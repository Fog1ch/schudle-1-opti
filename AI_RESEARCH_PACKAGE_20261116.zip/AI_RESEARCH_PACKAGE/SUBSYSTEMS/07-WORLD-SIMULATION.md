# World simulation и игровые объекты

## Scope и подтверждённые наблюдения
TimeManager.TickLoop.MoveNext содержит прямой вызов ActionList.InvokeAllStaggered. В игре уже есть инфраструктура распределения событий; не следует объявлять всякую симуляцию синхронной или предлагать staggering как отсутствующую систему.
Plant.MinPass вызывает GrowContainer.GetAverageLightExposure и moisture getter. GetAverageLightExposure обходит список координат, получает Grid.GetTile и LightExposureNode.GetTotalExposure, суммирует и делит на количество; альтернативная ветвь возвращает поле другого объекта. Интерпретация этого поля требует дальнейшего layout audit.
Это вычисление игровой освещённости растений, не замер GPU lighting. Частота подписки каждого Plant и масштаб активных объектов не определены.

## Возможности, пока гипотезы
Кэширование освещённости только с полной картой инвалидаторов: свет, тайлы, перемещение и конфигурация. Исследовать event subscriptions, не уменьшать скорость роста.

## Риски и неизвестное
Изменение игровой экономики, порядка событий, света, точности float и времени. Наличие метода MinPass не доказывает единственный caller.

## Адресуемые методы
| Метод | RVA | Offset | Cpp2IL bytes |
|---|---|---|---|
| System.Void ActionList::.ctor(System.Boolean) | 0x519E70 | 0x519070 | 137 |
| System.Void ActionList::InvokeAll() | 0x519C90 | 0x518E90 | 255 |
| System.Void ActionList::InvokeAllStaggered(System.Single) | 0x519B50 | 0x518D50 | 304 |
| System.Void ActionList::CancelStaggeredInvoke() | 0x519A40 | 0x518C40 | 162 |
| System.Void ActionList::Clear() | 0x519AF0 | 0x518CF0 | 95 |
| System.Void ActionList::Add(System.Action) | 0x519990 | 0x518B90 | 173 |
| System.Void ActionList::Remove(System.Action) | 0x519D90 | 0x518F90 | 83 |
| ActionList ActionList::op_Addition(ActionList,System.Action) | 0x519F00 | 0x519100 | 185 |
| ActionList ActionList::op_Subtraction(ActionList,System.Action) | 0x519FC0 | 0x5191C0 | 97 |
| System.Collections.IEnumerator ActionList::<InvokeAllStaggered>g__StaggeredInvoke\|6_0(System.Single) | 0x519DF0 | 0x518FF0 | 121 |
| System.Void ActionList/<<InvokeAllStaggered>g__StaggeredInvoke\|6_0>d::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void ActionList/<<InvokeAllStaggered>g__StaggeredInvoke\|6_0>d::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean ActionList/<<InvokeAllStaggered>g__StaggeredInvoke\|6_0>d::MoveNext() | 0x52E6A0 | 0x52D8A0 | 735 |
| System.Object ActionList/<<InvokeAllStaggered>g__StaggeredInvoke\|6_0>d::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ActionList/<<InvokeAllStaggered>g__StaggeredInvoke\|6_0>d::System.Collections.IEnumerator.Reset() | 0x52E990 | 0x52DB90 | 62 |
| System.Object ActionList/<<InvokeAllStaggered>g__StaggeredInvoke\|6_0>d::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Single ScheduleOne.GameTime.TimeManager::get_MinuteDuration() | 0x9CC040 | 0x9CB240 | 87 |
| System.Int32 ScheduleOne.GameTime.TimeManager::get_DefaultTime() | 0x4ED680 | 0x4EC880 | 7 |
| System.Void ScheduleOne.GameTime.TimeManager::set_DefaultTime(System.Int32) | 0x6103E0 | 0x60F5E0 | 7 |
| System.Int32 ScheduleOne.GameTime.TimeManager::get_CurrentTime() | 0x4E7E70 | 0x4E7070 | 7 |
| System.Void ScheduleOne.GameTime.TimeManager::set_CurrentTime(System.Int32) | 0x6103F0 | 0x60F5F0 | 7 |
| ScheduleOne.GameTime.EDay ScheduleOne.GameTime.TimeManager::get_CurrentDay() | 0x9CBFC0 | 0x9CB1C0 | 38 |
| System.Int32 ScheduleOne.GameTime.TimeManager::get_ElapsedDays() | 0x5FE3A0 | 0x5FD5A0 | 7 |
| System.Void ScheduleOne.GameTime.TimeManager::set_ElapsedDays(System.Int32) | 0x5FE460 | 0x5FD660 | 7 |
| System.Boolean ScheduleOne.GameTime.TimeManager::get_IsEndOfDay() | 0x9CC000 | 0x9CB200 | 14 |
| System.Boolean ScheduleOne.GameTime.TimeManager::get_IsNight() | 0x9CC010 | 0x9CB210 | 29 |
| System.Single ScheduleOne.GameTime.TimeManager::get_NormalizedTimeOfDay() | 0x9CC0A0 | 0x9CB2A0 | 213 |
| System.Int32 ScheduleOne.GameTime.TimeManager::get_DayIndex() | 0x9CBFC0 | 0x9CB1C0 | 38 |
| System.Single ScheduleOne.GameTime.TimeManager::get_Playtime() | 0x5E73A0 | 0x5E65A0 | 9 |
| System.Void ScheduleOne.GameTime.TimeManager::set_Playtime(System.Single) | 0x5E74F0 | 0x5E66F0 | 9 |
| System.Single ScheduleOne.GameTime.TimeManager::get_TimeSpeedMultiplier() | 0x65A4A0 | 0x6596A0 | 9 |
| System.Void ScheduleOne.GameTime.TimeManager::set_TimeSpeedMultiplier(System.Single) | 0x9CC2B0 | 0x9CB4B0 | 9 |
| System.Int32 ScheduleOne.GameTime.TimeManager::get_DailyMinSum() | 0x9CBFF0 | 0x9CB1F0 | 7 |
| System.Void ScheduleOne.GameTime.TimeManager::set_DailyMinSum(System.Int32) | 0x9CC2A0 | 0x9CB4A0 | 7 |
| System.Single ScheduleOne.GameTime.TimeManager::get__minuteStaggerTime() | 0x9CC1E0 | 0x9CB3E0 | 165 |
| System.Single ScheduleOne.GameTime.TimeManager::get__tickStaggerTime() | 0x9CC290 | 0x9CB490 | 9 |
| System.String ScheduleOne.GameTime.TimeManager::get_SaveFolderName() | 0x9CC1B0 | 0x9CB3B0 | 44 |
| System.String ScheduleOne.GameTime.TimeManager::get_SaveFileName() | 0x9CC180 | 0x9CB380 | 44 |
| ScheduleOne.Persistence.Loaders.Loader ScheduleOne.GameTime.TimeManager::get_Loader() | 0x8DAD60 | 0x8D9F60 | 8 |
| System.Boolean ScheduleOne.GameTime.TimeManager::get_ShouldSaveUnderFolder() | 0x45FA60 | 0x45EC60 | 3 |
| System.Collections.Generic.List`1<System.String> ScheduleOne.GameTime.TimeManager::get_LocalExtraFiles() | 0x6A60C0 | 0x6A52C0 | 8 |
| System.Void ScheduleOne.GameTime.TimeManager::set_LocalExtraFiles(System.Collections.Generic.List`1<System.String>) | 0x6A6200 | 0x6A5400 | 19 |
| System.Collections.Generic.List`1<System.String> ScheduleOne.GameTime.TimeManager::get_LocalExtraFolders() | 0x6A60D0 | 0x6A52D0 | 8 |
| System.Void ScheduleOne.GameTime.TimeManager::set_LocalExtraFolders(System.Collections.Generic.List`1<System.String>) | 0x6A6220 | 0x6A5420 | 19 |
| System.Boolean ScheduleOne.GameTime.TimeManager::get_HasChanged() | 0x6A6090 | 0x6A5290 | 8 |
| System.Void ScheduleOne.GameTime.TimeManager::set_HasChanged(System.Boolean) | 0x6A61D0 | 0x6A53D0 | 7 |
| System.Int32 ScheduleOne.GameTime.TimeManager::get_LoadOrder() | 0x9CC030 | 0x9CB230 | 7 |
| System.Void ScheduleOne.GameTime.TimeManager::Awake() | 0x9C8CE0 | 0x9C7EE0 | 303 |
| System.Void ScheduleOne.GameTime.TimeManager::Start() | 0x9CBB30 | 0x9CAD30 | 256 |
| System.Void ScheduleOne.GameTime.TimeManager::InitializeSaveable() | 0x9C93C0 | 0x9C85C0 | 129 |
| System.Void ScheduleOne.GameTime.TimeManager::OnSpawnServer(FishNet.Connection.NetworkConnection) | 0x9C9950 | 0x9C8B50 | 116 |
| System.Void ScheduleOne.GameTime.TimeManager::OnStartServer() | 0x9C9A60 | 0x9C8C60 | 142 |
| System.Void ScheduleOne.GameTime.TimeManager::OnStartClient() | 0x9C99D0 | 0x9C8BD0 | 142 |
| System.Void ScheduleOne.GameTime.TimeManager::Clean() | 0x9C8E10 | 0x9C8010 | 450 |
| System.Void ScheduleOne.GameTime.TimeManager::SetTimeData_Client(FishNet.Connection.NetworkConnection,System.Int32,System.Int32,System.UInt32) | 0x9CB210 | 0x9CA410 | 832 |
| System.Void ScheduleOne.GameTime.TimeManager::Update() | 0x9CBD40 | 0x9CAF40 | 127 |
| System.Void ScheduleOne.GameTime.TimeManager::FixedUpdate() | 0x9C8FE0 | 0x9C81E0 | 30 |
| System.Collections.IEnumerator ScheduleOne.GameTime.TimeManager::TickLoop() | 0x9CBC40 | 0x9CAE40 | 103 |
| System.Collections.IEnumerator ScheduleOne.GameTime.TimeManager::TimeLoop() | 0x9CBCB0 | 0x9CAEB0 | 103 |
| System.Boolean ScheduleOne.GameTime.TimeManager::ShouldMinutePass() | 0x9CB890 | 0x9CAA90 | 123 |
| System.Void ScheduleOne.GameTime.TimeManager::PassMinute() | 0x9C9DC0 | 0x9C8FC0 | 328 |
| System.Void ScheduleOne.GameTime.TimeManager::PassMinute_Client(System.Int32) | 0x9C9C70 | 0x9C8E70 | 324 |
| System.Void ScheduleOne.GameTime.TimeManager::SetTime_Server(System.Int32) | 0x9CB5F0 | 0x9CA7F0 | 193 |
| System.Void ScheduleOne.GameTime.TimeManager::SkipToTimeAndSync(System.Int32) | 0x9CB910 | 0x9CAB10 | 541 |
| System.Void ScheduleOne.GameTime.TimeManager::OnTimeSkip_Client(System.Int32,System.Int32) | 0x9C9AF0 | 0x9C8CF0 | 371 |
| System.Void ScheduleOne.GameTime.TimeManager::SetTime(System.Int32) | 0x9CB6C0 | 0x9CA8C0 | 456 |
| System.Boolean ScheduleOne.GameTime.TimeManager::IsCurrentTimeWithinRange(System.Int32,System.Int32) | 0x9C9560 | 0x9C8760 | 147 |
| System.Boolean ScheduleOne.GameTime.TimeManager::IsCurrentDateWithinRange(ScheduleOne.GameTime.GameDateTime,ScheduleOne.GameTime.GameDateTime) | 0x9C9450 | 0x9C8650 | 258 |
| ScheduleOne.GameTime.GameDateTime ScheduleOne.GameTime.TimeManager::GetDateTime() | 0x9C9210 | 0x9C8410 | 26 |
| System.Int32 ScheduleOne.GameTime.TimeManager::GetTotalMinSum() | 0x9C93A0 | 0x9C85A0 | 17 |
| System.Void ScheduleOne.GameTime.TimeManager::SetTimeSpeedMultiplier(System.Single) | 0x9CB560 | 0x9CA760 | 142 |
| System.Void ScheduleOne.GameTime.TimeManager::SetCycleDuration(System.Single) | 0x9CB0B0 | 0x9CA2B0 | 351 |
| System.Single ScheduleOne.GameTime.TimeManager::Normalized24HourTime(System.Int32) | 0x9C98E0 | 0x9C8AE0 | 102 |
| System.Boolean ScheduleOne.GameTime.TimeManager::IsGivenTimeWithinRange(System.Int32,System.Int32,System.Int32) | 0x9C9600 | 0x9C8800 | 26 |
| System.Boolean ScheduleOne.GameTime.TimeManager::IsValid24HourTime(System.String) | 0x9C9660 | 0x9C8860 | 105 |
| System.Boolean ScheduleOne.GameTime.TimeManager::IsValid24HourTime(System.Int32) | 0x9C9620 | 0x9C8820 | 56 |
| System.String ScheduleOne.GameTime.TimeManager::Get12HourTime(System.Single,System.Boolean) | 0x9C9000 | 0x9C8200 | 447 |
| System.Int32 ScheduleOne.GameTime.TimeManager::Get24HourTimeFromMinSum(System.Int32) | 0x9C91C0 | 0x9C83C0 | 80 |
| System.Int32 ScheduleOne.GameTime.TimeManager::GetMinSumFrom24HourTime(System.Int32) | 0x9C9230 | 0x9C8430 | 27 |
| System.String ScheduleOne.GameTime.TimeManager::GetMinutesToDisplayTime(System.Int32) | 0x9C9250 | 0x9C8450 | 166 |
| System.Int32 ScheduleOne.GameTime.TimeManager::AddMinutesTo24HourTime(System.Int32,System.Int32) | 0x9C8AF0 | 0x9C7CF0 | 210 |
| System.String ScheduleOne.GameTime.TimeManager::GetSaveString() | 0x9C9300 | 0x9C8500 | 151 |
| System.Void ScheduleOne.GameTime.TimeManager::Load(ScheduleOne.Persistence.Datas.TimeData) | 0x9C96D0 | 0x9C88D0 | 68 |
| System.Void ScheduleOne.GameTime.TimeManager::.ctor() | 0x9CBE00 | 0x9CB000 | 435 |
| System.Void ScheduleOne.GameTime.TimeManager::.cctor() | 0x9CBDC0 | 0x9CAFC0 | 57 |
| System.Boolean ScheduleOne.GameTime.TimeManager::<TimeLoop>b__96_1() | 0x9CBD20 | 0x9CAF20 | 18 |
| System.Void ScheduleOne.GameTime.TimeManager::NetworkInitialize___Early() | 0x9C9770 | 0x9C8970 | 365 |
| System.Void ScheduleOne.GameTime.TimeManager::NetworkInitialize__Late() | 0x9C9720 | 0x9C8920 | 79 |
| System.Void ScheduleOne.GameTime.TimeManager::NetworkInitializeIfDisabled() | 0x51FE10 | 0x51F010 | 50 |
| System.Void ScheduleOne.GameTime.TimeManager::RpcWriter___Observers_SetTimeData_Client_1794730778(FishNet.Connection.NetworkConnection,System.Int32,System.Int32,System.UInt32) | 0x9CAD40 | 0x9C9F40 | 438 |
| System.Void ScheduleOne.GameTime.TimeManager::RpcLogic___SetTimeData_Client_1794730778(FishNet.Connection.NetworkConnection,System.Int32,System.Int32,System.UInt32) | 0x9CA530 | 0x9C9730 | 677 |
| System.Void ScheduleOne.GameTime.TimeManager::RpcReader___Observers_SetTimeData_Client_1794730778(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel) | 0x9CA8F0 | 0x9C9AF0 | 185 |
| System.Void ScheduleOne.GameTime.TimeManager::RpcWriter___Target_SetTimeData_Client_1794730778(FishNet.Connection.NetworkConnection,System.Int32,System.Int32,System.UInt32) | 0x9CAF00 | 0x9CA100 | 428 |
| System.Void ScheduleOne.GameTime.TimeManager::RpcReader___Target_SetTimeData_Client_1794730778(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel) | 0x9CA9B0 | 0x9C9BB0 | 182 |
| System.Void ScheduleOne.GameTime.TimeManager::RpcWriter___Observers_PassMinute_Client_3316948804(System.Int32) | 0x9CABF0 | 0x9C9DF0 | 332 |
| System.Void ScheduleOne.GameTime.TimeManager::RpcLogic___PassMinute_Client_3316948804(System.Int32) | 0x9CA2D0 | 0x9C94D0 | 605 |
| System.Void ScheduleOne.GameTime.TimeManager::RpcReader___Observers_PassMinute_Client_3316948804(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel) | 0x9CA880 | 0x9C9A80 | 105 |
| System.Void ScheduleOne.GameTime.TimeManager::RpcWriter___Observers_OnTimeSkip_Client_1692629761(System.Int32,System.Int32) | 0x9CAA70 | 0x9C9C70 | 382 |
| System.Void ScheduleOne.GameTime.TimeManager::RpcLogic___OnTimeSkip_Client_1692629761(System.Int32,System.Int32) | 0x9C9F10 | 0x9C9110 | 947 |
| System.Void ScheduleOne.GameTime.TimeManager::RpcReader___Observers_OnTimeSkip_Client_1692629761(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel) | 0x9CA7E0 | 0x9C99E0 | 145 |
| System.Void ScheduleOne.GameTime.TimeManager::Awake_UserLogic_ScheduleOne.GameTime.TimeManager_Assembly-CSharp.dll() | 0x9C8BD0 | 0x9C7DD0 | 267 |
| System.Void ScheduleOne.GameTime.TimeManager/<>c::.cctor() | 0x9D00B0 | 0x9CF2B0 | 103 |
| System.Void ScheduleOne.GameTime.TimeManager/<>c::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Boolean ScheduleOne.GameTime.TimeManager/<>c::<TickLoop>b__95_0() | 0x9CFE70 | 0x9CF070 | 25 |
| System.Boolean ScheduleOne.GameTime.TimeManager/<>c::<TimeLoop>b__96_0() | 0x9CFE90 | 0x9CF090 | 120 |
| System.Boolean ScheduleOne.GameTime.TimeManager/<>c::<TimeLoop>b__96_2() | 0x9CFE70 | 0x9CF070 | 25 |
| System.Void ScheduleOne.GameTime.TimeManager/<TickLoop>d__95::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void ScheduleOne.GameTime.TimeManager/<TickLoop>d__95::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean ScheduleOne.GameTime.TimeManager/<TickLoop>d__95::MoveNext() | 0x9CE410 | 0x9CD610 | 750 |
| System.Object ScheduleOne.GameTime.TimeManager/<TickLoop>d__95::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.GameTime.TimeManager/<TickLoop>d__95::System.Collections.IEnumerator.Reset() | 0x9CE700 | 0x9CD900 | 62 |
| System.Object ScheduleOne.GameTime.TimeManager/<TickLoop>d__95::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.GameTime.TimeManager/<TimeLoop>d__96::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void ScheduleOne.GameTime.TimeManager/<TimeLoop>d__96::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean ScheduleOne.GameTime.TimeManager/<TimeLoop>d__96::MoveNext() | 0x9CE740 | 0x9CD940 | 1732 |
| System.Object ScheduleOne.GameTime.TimeManager/<TimeLoop>d__96::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.GameTime.TimeManager/<TimeLoop>d__96::System.Collections.IEnumerator.Reset() | 0x9CEE20 | 0x9CE020 | 62 |
| System.Object ScheduleOne.GameTime.TimeManager/<TimeLoop>d__96::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Single ScheduleOne.Growing.GrowContainer::get_SoilCapacity() | 0x7E8B70 | 0x7E7D70 | 9 |
| System.Void ScheduleOne.Growing.GrowContainer::set_SoilCapacity(System.Single) | 0x7E8C90 | 0x7E7E90 | 9 |
| System.Single ScheduleOne.Growing.GrowContainer::get_MoistureCapacity() | 0x7E8AE0 | 0x7E7CE0 | 9 |
| System.Void ScheduleOne.Growing.GrowContainer::set_MoistureCapacity(System.Single) | 0x7E8BE0 | 0x7E7DE0 | 9 |
| System.Boolean ScheduleOne.Growing.GrowContainer::get_HidePlantDuringPourTasks() | 0x7E8A30 | 0x7E7C30 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::set_HidePlantDuringPourTasks(System.Boolean) | 0x7E8BC0 | 0x7E7DC0 | 7 |
| UnityEngine.Transform ScheduleOne.Growing.GrowContainer::get_SoilContainer() | 0x557D00 | 0x556F00 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::set_SoilContainer(UnityEngine.Transform) | 0x557F40 | 0x557140 | 19 |
| UnityEngine.Transform ScheduleOne.Growing.GrowContainer::get_PourableStartPoint() | 0x635D20 | 0x634F20 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::set_PourableStartPoint(UnityEngine.Transform) | 0x636A90 | 0x635C90 | 19 |
| ScheduleOne.Growing.GrowContainerSurfaceCover ScheduleOne.Growing.GrowContainer::get_SurfaceCover() | 0x635FA0 | 0x6351A0 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::set_SurfaceCover(ScheduleOne.Growing.GrowContainerSurfaceCover) | 0x636D20 | 0x635F20 | 19 |
| ScheduleOne.Growing.GrowContainerCameraHandler ScheduleOne.Growing.GrowContainer::get_CameraHandler() | 0x7E8A20 | 0x7E7C20 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::set_CameraHandler(ScheduleOne.Growing.GrowContainerCameraHandler) | 0x7E8BA0 | 0x7E7DA0 | 19 |
| ScheduleOne.UI.TemperatureDisplay ScheduleOne.Growing.GrowContainer::get_TemperatureDisplay() | 0x54DDF0 | 0x54CFF0 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::set_TemperatureDisplay(ScheduleOne.UI.TemperatureDisplay) | 0x7E8CA0 | 0x7E7EA0 | 19 |
| System.Single ScheduleOne.Growing.GrowContainer::get_NormalizedSoilAmount() | 0x7E8B40 | 0x7E7D40 | 17 |
| System.Boolean ScheduleOne.Growing.GrowContainer::get_IsFullyFilledWithSoil() | 0x7E8A50 | 0x7E7C50 | 116 |
| System.Single ScheduleOne.Growing.GrowContainer::get_NormalizedMoistureAmount() | 0x7E8B20 | 0x7E7D20 | 17 |
| ScheduleOne.ItemFramework.SoilDefinition ScheduleOne.Growing.GrowContainer::get_CurrentSoil() | 0x635C20 | 0x634E20 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::set_CurrentSoil(ScheduleOne.ItemFramework.SoilDefinition) | 0x636A50 | 0x635C50 | 19 |
| System.Collections.Generic.List`1<ScheduleOne.ItemFramework.AdditiveDefinition> ScheduleOne.Growing.GrowContainer::get_AppliedAdditives() | 0x7E8A10 | 0x7E7C10 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::set_AppliedAdditives(System.Collections.Generic.List`1<ScheduleOne.ItemFramework.AdditiveDefinition>) | 0x7E8B80 | 0x7E7D80 | 19 |
| FishNet.Object.NetworkObject ScheduleOne.Growing.GrowContainer::get_NPCUserObject() | 0x635FB0 | 0x6351B0 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::set_NPCUserObject(FishNet.Object.NetworkObject) | 0x7E6500 | 0x7E5700 | 156 |
| FishNet.Object.NetworkObject ScheduleOne.Growing.GrowContainer::get_PlayerUserObject() | 0x635FC0 | 0x6351C0 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::set_PlayerUserObject(FishNet.Object.NetworkObject) | 0x7E8BF0 | 0x7E7DF0 | 156 |
| System.String ScheduleOne.Growing.GrowContainer::get_Name() | 0x7E8AF0 | 0x7E7CF0 | 42 |
| System.Collections.Generic.List`1<ScheduleOne.ItemFramework.ItemSlot> ScheduleOne.Growing.GrowContainer::get_InputSlots() | 0x635FD0 | 0x6351D0 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::set_InputSlots(System.Collections.Generic.List`1<ScheduleOne.ItemFramework.ItemSlot>) | 0x636D60 | 0x635F60 | 19 |
| System.Collections.Generic.List`1<ScheduleOne.ItemFramework.ItemSlot> ScheduleOne.Growing.GrowContainer::get_OutputSlots() | 0x6EAF60 | 0x6EA160 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::set_OutputSlots(System.Collections.Generic.List`1<ScheduleOne.ItemFramework.ItemSlot>) | 0x6EB1E0 | 0x6EA3E0 | 19 |
| UnityEngine.Transform ScheduleOne.Growing.GrowContainer::get_LinkOrigin() | 0x7E8AD0 | 0x7E7CD0 | 8 |
| UnityEngine.Transform[] ScheduleOne.Growing.GrowContainer::get_AccessPoints() | 0x7E8A00 | 0x7E7C00 | 8 |
| System.Boolean ScheduleOne.Growing.GrowContainer::get_Selectable() | 0x7E8B60 | 0x7E7D60 | 8 |
| System.Boolean ScheduleOne.Growing.GrowContainer::get_IsAcceptingItems() | 0x7E8A40 | 0x7E7C40 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::set_IsAcceptingItems(System.Boolean) | 0x7E8BD0 | 0x7E7DD0 | 7 |
| System.Void ScheduleOne.Growing.GrowContainer::ConfigureInteraction(System.String,ScheduleOne.Interaction.InteractableObject/EInteractableState) | 0x7E47C0 | 0x7E39C0 | 60 |
| System.Void ScheduleOne.Growing.GrowContainer::ConfigureInteraction(System.String,ScheduleOne.Interaction.InteractableObject/EInteractableState,UnityEngine.Vector3) | 0x7E4800 | 0x7E3A00 | 72 |
| System.Void ScheduleOne.Growing.GrowContainer::Awake() | 0x7E4290 | 0x7E3490 | 158 |
| System.Void ScheduleOne.Growing.GrowContainer::InitializeGridItem(ScheduleOne.ItemFramework.ItemInstance,ScheduleOne.Tiles.Grid,UnityEngine.Vector2,System.Int32,System.String) | 0x7E4F20 | 0x7E4120 | 1232 |
| System.Void ScheduleOne.Growing.GrowContainer::HeatmapVisibilityChanged(ScheduleOne.Property.Property,System.Boolean) | 0x7E4E70 | 0x7E4070 | 163 |
| System.Void ScheduleOne.Growing.GrowContainer::Destroy() | 0x7E4850 | 0x7E3A50 | 789 |
| System.Void ScheduleOne.Growing.GrowContainer::OnSpawnServer(FishNet.Connection.NetworkConnection) | 0x7E5D60 | 0x7E4F60 | 479 |
| System.Void ScheduleOne.Growing.GrowContainer::OnMinPass() | 0x7E5C80 | 0x7E4E80 | 214 |
| System.Void ScheduleOne.Growing.GrowContainer::OnTimeSkipped(System.Int32) | 0x7E5F40 | 0x7E5140 | 128 |
| System.Void ScheduleOne.Growing.GrowContainer::DrainMoisture(System.Int32) | 0x7E4B70 | 0x7E3D70 | 59 |
| System.Single ScheduleOne.Growing.GrowContainer::GetAverageLightExposure(System.Single&) | 0x7E4BB0 | 0x7E3DB0 | 439 |
| System.Void ScheduleOne.Growing.GrowContainer::SetSoil(ScheduleOne.ItemFramework.SoilDefinition) | 0x7E84E0 | 0x7E76E0 | 53 |
| System.Void ScheduleOne.Growing.GrowContainer::ChangeSoilAmount(System.Single) | 0x7E44B0 | 0x7E36B0 | 62 |
| System.Void ScheduleOne.Growing.GrowContainer::SetSoilAmount(System.Single) | 0x7E8220 | 0x7E7420 | 49 |
| System.Void ScheduleOne.Growing.GrowContainer::SetRemainingSoilUses(System.Int32) | 0x7E8210 | 0x7E7410 | 7 |
| System.Void ScheduleOne.Growing.GrowContainer::SyncSoilData() | 0x7E8660 | 0x7E7860 | 491 |
| System.Void ScheduleOne.Growing.GrowContainer::SetSoilData_Server(System.String,System.Single,System.Int32) | 0x7E7780 | 0x7E6980 | 361 |
| System.Void ScheduleOne.Growing.GrowContainer::SetSoilData_Client(FishNet.Connection.NetworkConnection,System.String,System.Single,System.Int32) | 0x7E8260 | 0x7E7460 | 628 |
| System.Void ScheduleOne.Growing.GrowContainer::RefreshSoilVisuals() | 0x7E6280 | 0x7E5480 | 514 |
| System.Void ScheduleOne.Growing.GrowContainer::ClearSoil() | 0x7E46D0 | 0x7E38D0 | 235 |
| System.Boolean ScheduleOne.Growing.GrowContainer::IsSoilAllowed(ScheduleOne.ItemFramework.SoilDefinition) | 0x7E5510 | 0x7E4710 | 180 |
| UnityEngine.Material ScheduleOne.Growing.GrowContainer::GetSoilMaterial() | 0x7E4DB0 | 0x7E3FB0 | 176 |
| System.Void ScheduleOne.Growing.GrowContainer::ChangeMoistureAmount(System.Single) | 0x7E4490 | 0x7E3690 | 25 |
| System.Void ScheduleOne.Growing.GrowContainer::SetMoistureAmount(System.Single) | 0x7E7D30 | 0x7E6F30 | 49 |
| System.Void ScheduleOne.Growing.GrowContainer::SyncMoistureData() | 0x7E8520 | 0x7E7720 | 311 |
| System.Void ScheduleOne.Growing.GrowContainer::SetMoistureData_Server(System.Single) | 0x7E73E0 | 0x7E65E0 | 306 |
| System.Void ScheduleOne.Growing.GrowContainer::SetMoistureData_Client(FishNet.Connection.NetworkConnection,System.Single) | 0x7E7D70 | 0x7E6F70 | 510 |
| System.Void ScheduleOne.Growing.GrowContainer::ApplyAdditive_Server(System.String) | 0x7E3DC0 | 0x7E2FC0 | 316 |
| System.Void ScheduleOne.Growing.GrowContainer::ApplyAdditive_Client(FishNet.Connection.NetworkConnection,System.String,System.Boolean) | 0x7E3B30 | 0x7E2D30 | 647 |
| ScheduleOne.ItemFramework.AdditiveDefinition ScheduleOne.Growing.GrowContainer::ApplyAdditive(System.String,System.Boolean) | 0x7E3F00 | 0x7E3100 | 770 |
| System.Single ScheduleOne.Growing.GrowContainer::GetTemperatureGrowthMultiplier() | 0x78B310 | 0x78A510 | 9 |
| System.Boolean ScheduleOne.Growing.GrowContainer::IsAdditiveApplied(System.String) | 0x7E5400 | 0x7E4600 | 270 |
| System.Void ScheduleOne.Growing.GrowContainer::ClearAdditives() | 0x7E44F0 | 0x7E36F0 | 464 |
| System.Boolean ScheduleOne.Growing.GrowContainer::CanApplyAdditive(ScheduleOne.ItemFramework.AdditiveDefinition,System.String&) | 0x7E4330 | 0x7E3530 | 339 |
| System.Void ScheduleOne.Growing.GrowContainer::SetPourTargetActive(System.Boolean) | 0x7E81D0 | 0x7E73D0 | 57 |
| System.Void ScheduleOne.Growing.GrowContainer::RandomizePourTargetPosition() | 0x7E5FC0 | 0x7E51C0 | 399 |
| UnityEngine.Vector3 ScheduleOne.Growing.GrowContainer::GetCurrentTargetPosition() | 0x7E4D70 | 0x7E3F70 | 62 |
| System.Void ScheduleOne.Growing.GrowContainer::SetPlayerUser(FishNet.Object.NetworkObject) | 0x7E80A0 | 0x7E72A0 | 298 |
| System.Void ScheduleOne.Growing.GrowContainer::SetNPCUser(FishNet.Object.NetworkObject) | 0x7E7F70 | 0x7E7170 | 298 |
| System.Void ScheduleOne.Growing.GrowContainer::Load(ScheduleOne.Persistence.Datas.GrowContainerData) | 0x7E55D0 | 0x7E47D0 | 310 |
| System.Void ScheduleOne.Growing.GrowContainer::.ctor() | 0x7E8860 | 0x7E7A60 | 406 |
| System.Single ScheduleOne.Growing.GrowContainer::<InitializeGridItem>b__99_0() | 0x7E8850 | 0x7E7A50 | 7 |
| System.Void ScheduleOne.Growing.GrowContainer::NetworkInitialize___Early() | 0x7E5780 | 0x7E4980 | 1272 |
| System.Void ScheduleOne.Growing.GrowContainer::NetworkInitialize__Late() | 0x7E5710 | 0x7E4910 | 105 |
| System.Void ScheduleOne.Growing.GrowContainer::NetworkInitializeIfDisabled() | 0x6A4B20 | 0x6A3D20 | 50 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcWriter___Server_SetSoilData_Server_3104499779(System.String,System.Single,System.Int32) | 0x7E7780 | 0x7E6980 | 361 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcLogic___SetSoilData_Server_3104499779(System.String,System.Single,System.Int32) | 0x7E6830 | 0x7E5A30 | 36 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcReader___Server_SetSoilData_Server_3104499779(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel,FishNet.Connection.NetworkConnection) | 0x7E6BF0 | 0x7E5DF0 | 160 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcWriter___Observers_SetSoilData_Client_433593356(FishNet.Connection.NetworkConnection,System.String,System.Single,System.Int32) | 0x7E7120 | 0x7E6320 | 391 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcLogic___SetSoilData_Client_433593356(FishNet.Connection.NetworkConnection,System.String,System.Single,System.Int32) | 0x7E6780 | 0x7E5980 | 167 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcReader___Observers_SetSoilData_Client_433593356(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel) | 0x7E6960 | 0x7E5B60 | 160 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcWriter___Target_SetSoilData_Client_433593356(FishNet.Connection.NetworkConnection,System.String,System.Single,System.Int32) | 0x7E7BB0 | 0x7E6DB0 | 383 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcReader___Target_SetSoilData_Client_433593356(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel) | 0x7E6DB0 | 0x7E5FB0 | 171 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcWriter___Server_SetMoistureData_Server_431000436(System.Single) | 0x7E73E0 | 0x7E65E0 | 306 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcLogic___SetMoistureData_Server_431000436(System.Single) | 0x7E64F0 | 0x7E56F0 | 13 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcReader___Server_SetMoistureData_Server_431000436(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel,FishNet.Connection.NetworkConnection) | 0x7E6A90 | 0x7E5C90 | 84 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcWriter___Observers_SetMoistureData_Client_530160725(FishNet.Connection.NetworkConnection,System.Single) | 0x7E6FD0 | 0x7E61D0 | 322 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcLogic___SetMoistureData_Client_530160725(FishNet.Connection.NetworkConnection,System.Single) | 0x7E64D0 | 0x7E56D0 | 20 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcReader___Observers_SetMoistureData_Client_530160725(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel) | 0x7E6900 | 0x7E5B00 | 90 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcWriter___Target_SetMoistureData_Client_530160725(FishNet.Connection.NetworkConnection,System.Single) | 0x7E7A50 | 0x7E6C50 | 346 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcReader___Target_SetMoistureData_Client_530160725(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel) | 0x7E6D40 | 0x7E5F40 | 100 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcWriter___Server_ApplyAdditive_Server_3615296227(System.String) | 0x7E72B0 | 0x7E64B0 | 301 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcLogic___ApplyAdditive_Server_3615296227(System.String) | 0x7E64B0 | 0x7E56B0 | 31 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcReader___Server_ApplyAdditive_Server_3615296227(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel,FishNet.Connection.NetworkConnection) | 0x7E6A10 | 0x7E5C10 | 121 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcWriter___Observers_ApplyAdditive_Client_619441887(FishNet.Connection.NetworkConnection,System.String,System.Boolean) | 0x7E6E60 | 0x7E6060 | 356 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcLogic___ApplyAdditive_Client_619441887(FishNet.Connection.NetworkConnection,System.String,System.Boolean) | 0x7E6490 | 0x7E5690 | 28 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcReader___Observers_ApplyAdditive_Client_619441887(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel) | 0x7E6860 | 0x7E5A60 | 152 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcWriter___Target_ApplyAdditive_Client_619441887(FishNet.Connection.NetworkConnection,System.String,System.Boolean) | 0x7E78F0 | 0x7E6AF0 | 344 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcReader___Target_ApplyAdditive_Client_619441887(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel) | 0x7E6CA0 | 0x7E5EA0 | 148 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcWriter___Server_SetPlayerUser_3323014238(FishNet.Object.NetworkObject) | 0x7E7650 | 0x7E6850 | 301 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcLogic___SetPlayerUser_3323014238(FishNet.Object.NetworkObject) | 0x7E65A0 | 0x7E57A0 | 467 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcReader___Server_SetPlayerUser_3323014238(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel,FishNet.Connection.NetworkConnection) | 0x7E6B70 | 0x7E5D70 | 127 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcWriter___Server_SetNPCUser_3323014238(FishNet.Object.NetworkObject) | 0x7E7520 | 0x7E6720 | 301 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcLogic___SetNPCUser_3323014238(FishNet.Object.NetworkObject) | 0x7E6500 | 0x7E5700 | 156 |
| System.Void ScheduleOne.Growing.GrowContainer::RpcReader___Server_SetNPCUser_3323014238(FishNet.Serializing.PooledReader,FishNet.Transporting.Channel,FishNet.Connection.NetworkConnection) | 0x7E6AF0 | 0x7E5CF0 | 127 |
| FishNet.Object.NetworkObject ScheduleOne.Growing.GrowContainer::sync___get_value_<NPCUserObject>k__BackingField() | 0x635FB0 | 0x6351B0 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::sync___set_value_<NPCUserObject>k__BackingField(FishNet.Object.NetworkObject,System.Boolean) | 0x7E8CC0 | 0x7E7EC0 | 190 |
| System.Boolean ScheduleOne.Growing.GrowContainer::ReadSyncVar___ScheduleOne.Growing.GrowContainer(FishNet.Serializing.PooledReader,System.UInt32,System.Boolean) | 0x7E6150 | 0x7E5350 | 293 |
| FishNet.Object.NetworkObject ScheduleOne.Growing.GrowContainer::sync___get_value_<PlayerUserObject>k__BackingField() | 0x635FC0 | 0x6351C0 | 8 |
| System.Void ScheduleOne.Growing.GrowContainer::sync___set_value_<PlayerUserObject>k__BackingField(FishNet.Object.NetworkObject,System.Boolean) | 0x7E8D80 | 0x7E7F80 | 190 |
| System.Void ScheduleOne.Growing.GrowContainer::Awake_UserLogic_ScheduleOne.Growing.GrowContainer_Assembly-CSharp.dll() | 0x7E4210 | 0x7E3410 | 119 |
| System.Void ScheduleOne.Growing.GrowContainer/<>c__DisplayClass132_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Boolean ScheduleOne.Growing.GrowContainer/<>c__DisplayClass132_0::<IsAdditiveApplied>b__0(ScheduleOne.ItemFramework.AdditiveDefinition) | 0x725300 | 0x724500 | 37 |
| ScheduleOne.ObjectScripts.Pot ScheduleOne.Growing.Plant::get_Pot() | 0x421DC0 | 0x420FC0 | 5 |
| System.Void ScheduleOne.Growing.Plant::set_Pot(ScheduleOne.ObjectScripts.Pot) | 0x421E00 | 0x421000 | 13 |
| System.Single ScheduleOne.Growing.Plant::get_NormalizedGrowthProgress() | 0x4F03D0 | 0x4EF5D0 | 6 |
| System.Void ScheduleOne.Growing.Plant::set_NormalizedGrowthProgress(System.Single) | 0x514B10 | 0x513D10 | 6 |
| System.Boolean ScheduleOne.Growing.Plant::get_IsFullyGrown() | 0x7FCE80 | 0x7FC080 | 16 |
| System.Single ScheduleOne.Growing.Plant::get_YieldMultiplier() | 0x463B00 | 0x462D00 | 6 |
| System.Void ScheduleOne.Growing.Plant::set_YieldMultiplier(System.Single) | 0x58A110 | 0x589310 | 6 |
| System.Single ScheduleOne.Growing.Plant::get_QualityLevel() | 0x463B90 | 0x462D90 | 6 |
| System.Void ScheduleOne.Growing.Plant::set_QualityLevel(System.Single) | 0x4699A0 | 0x468BA0 | 6 |
| ScheduleOne.Growing.PlantGrowthStage ScheduleOne.Growing.Plant::get_FinalGrowthStage() | 0x7FCE40 | 0x7FC040 | 49 |
| System.Void ScheduleOne.Growing.Plant::Awake() | 0x7FB800 | 0x7FAA00 | 100 |
| System.Void ScheduleOne.Growing.Plant::Initialize(FishNet.Object.NetworkObject,System.Single) | 0x7FBFF0 | 0x7FB1F0 | 411 |
| System.Void ScheduleOne.Growing.Plant::MinPass(System.Int32) | 0x7FC1F0 | 0x7FB3F0 | 429 |
| System.Void ScheduleOne.Growing.Plant::AdditiveApplied(ScheduleOne.ItemFramework.AdditiveDefinition,System.Boolean) | 0x7FB770 | 0x7FA970 | 129 |
| System.Void ScheduleOne.Growing.Plant::SetNormalizedGrowthProgress(System.Single) | 0x7FCAC0 | 0x7FBCC0 | 367 |
| System.Void ScheduleOne.Growing.Plant::UpdateVisuals() | 0x7FCC70 | 0x7FBE70 | 233 |
| System.Void ScheduleOne.Growing.Plant::SetHarvestableActive(System.Int32,System.Boolean) | 0x7FC940 | 0x7FBB40 | 373 |
| System.Void ScheduleOne.Growing.Plant::OnFullyHarvested() | 0x7FC3A0 | 0x7FB5A0 | 1160 |
| System.Boolean ScheduleOne.Growing.Plant::IsHarvestableActive(System.Int32) | 0x7FC190 | 0x7FB390 | 84 |
| System.Void ScheduleOne.Growing.Plant::GrowthDone() | 0x7FBD50 | 0x7FAF50 | 670 |
| System.Collections.Generic.List`1<System.Int32> ScheduleOne.Growing.Plant::GenerateUniqueIntegers(System.Int32,System.Int32,System.Int32) | 0x7FB9F0 | 0x7FABF0 | 560 |
| System.Void ScheduleOne.Growing.Plant::SetVisible(System.Boolean) | 0x7FCC30 | 0x7FBE30 | 54 |
| System.Void ScheduleOne.Growing.Plant::ResizeCollider() | 0x7FC830 | 0x7FBA30 | 261 |
| ScheduleOne.ItemFramework.ItemInstance ScheduleOne.Growing.Plant::GetHarvestedProduct(System.Int32) | 0x7FBC30 | 0x7FAE30 | 89 |
| ScheduleOne.Persistence.Datas.PlantData ScheduleOne.Growing.Plant::GetPlantData() | 0x7FBC90 | 0x7FAE90 | 178 |
| System.Void ScheduleOne.Growing.Plant::ActivateAllLures() | 0x7FB5F0 | 0x7FA7F0 | 377 |
| System.Void ScheduleOne.Growing.Plant::DeactivateAllLures() | 0x7FB870 | 0x7FAA70 | 377 |
| System.Void ScheduleOne.Growing.Plant::.ctor() | 0x7FCD60 | 0x7FBF60 | 224 |

Полные поля и offsets: [selected-types-fields](../EVIDENCE/current/selected-types-fields.json). Public proxy API: [interop-selected-api](../EVIDENCE/current/interop-selected-api.json).

## Сохранённые native roots
- [System.Void ScheduleOne.GameTime.TimeManager::Start()](../EVIDENCE/current/native/9CBB30.asm.txt)
- [System.Void ScheduleOne.GameTime.TimeManager::Update()](../EVIDENCE/current/native/9CBD40.asm.txt)
- [System.Void ScheduleOne.GameTime.TimeManager::FixedUpdate()](../EVIDENCE/current/native/9C8FE0.asm.txt)
- [System.Collections.IEnumerator ScheduleOne.GameTime.TimeManager::TickLoop()](../EVIDENCE/current/native/9CBC40.asm.txt)
- [System.Collections.IEnumerator ScheduleOne.GameTime.TimeManager::TimeLoop()](../EVIDENCE/current/native/9CBCB0.asm.txt)
- [System.Void ScheduleOne.GameTime.TimeManager::PassMinute()](../EVIDENCE/current/native/9C9DC0.asm.txt)
- [System.Boolean ScheduleOne.GameTime.TimeManager/<TickLoop>d__95::MoveNext()](../EVIDENCE/current/native/9CE410.asm.txt)
- [System.Boolean ScheduleOne.GameTime.TimeManager/<TimeLoop>d__96::MoveNext()](../EVIDENCE/current/native/9CE740.asm.txt)
- [System.Void ScheduleOne.Growing.Plant::MinPass(System.Int32)](../EVIDENCE/current/native/7FC1F0.asm.txt)
- [System.Void ActionList::InvokeAllStaggered(System.Single)](../EVIDENCE/current/native/519B50.asm.txt)
- [System.Boolean ActionList/<<InvokeAllStaggered>g__StaggeredInvoke|6_0>d::MoveNext()](../EVIDENCE/current/native/52E6A0.asm.txt)
- [System.Single ScheduleOne.Growing.GrowContainer::GetAverageLightExposure(System.Single&)](../EVIDENCE/current/native/7E4BB0.asm.txt)

[Native edge records](../EVIDENCE/current/native-edges.json). [Правила aliasing и scope](../REVERSE_ENGINEERING/EVIDENCE_RULES.md). [Исторический NPC report](../EVIDENCE/phase2/REPORT.ru.md). [Mod call sites](../EVIDENCE/current/mod-call-sites.json).
