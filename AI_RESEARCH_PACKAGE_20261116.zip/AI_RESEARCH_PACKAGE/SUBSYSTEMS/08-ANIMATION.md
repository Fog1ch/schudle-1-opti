# Animation и Animator

## Scope и подтверждённые наблюдения
NPCAnimation.UpdateMovementAnimation получает NPC velocity, переводит в local space через InverseTransformVector и вызывает AvatarAnimation.SetMotion/SetBool/SetFloat.
AvatarAnimation.SetFloat вызывает AvatarAnimationId.Get, затем integer Animator.SetFloat/SetFloatID. Get сначала проверяет s_CustomHashes (Dictionary<string,int>), StringToHash выполняется на miss и результат сохраняется. Отдельные static IDs также вычислены .cctor. Утверждение о повторном StringToHash для каждого знакомого параметра неверно.
AvatarAnimation.Update/standup coroutine управляют transform/bone state и enabled; LateUpdate сохраняет bone transforms. S1Perf уже меняет Animator.cullingMode и повторяет NPC scan раз в 30 секунд после первого прохода спустя 8 секунд в Main.

## Возможности, пока гипотезы
Исследовать, можно ли передавать уже готовые IDs без dictionary lookup, но только после измерения. Нельзя добавлять второй hash cache как якобы отсутствующий.

## Риски и неизвестное
Root motion, standup, IK, animation events, offscreen gameplay, Animator lifecycle, stale native pointer cache в стороннем моде.

## Адресуемые методы
| Метод | RVA | Offset | Cpp2IL bytes |
|---|---|---|---|
| System.Boolean ScheduleOne.AvatarFramework.Animation.AvatarAnimation::get_IsCrouched() | 0x4610B0 | 0x4602B0 | 5 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::set_IsCrouched(System.Boolean) | 0x4610D0 | 0x4602D0 | 4 |
| System.Boolean ScheduleOne.AvatarFramework.Animation.AvatarAnimation::get_IsSeated() | 0x7C8800 | 0x7C7A00 | 80 |
| System.Single ScheduleOne.AvatarFramework.Animation.AvatarAnimation::get_TimeSinceSitEnd() | 0x460F20 | 0x460120 | 6 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::set_TimeSinceSitEnd(System.Single) | 0x460F60 | 0x460160 | 6 |
| ScheduleOne.AvatarFramework.Animation.AvatarSeat ScheduleOne.AvatarFramework.Animation.AvatarAnimation::get_CurrentSeat() | 0x421DF0 | 0x420FF0 | 5 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::set_CurrentSeat(ScheduleOne.AvatarFramework.Animation.AvatarSeat) | 0x421E30 | 0x421030 | 13 |
| System.Boolean ScheduleOne.AvatarFramework.Animation.AvatarAnimation::get_StandUpAnimationPlaying() | 0x465080 | 0x464280 | 5 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::set_StandUpAnimationPlaying(System.Boolean) | 0x49A650 | 0x499850 | 4 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::Awake() | 0x7C5780 | 0x7C4980 | 1232 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::Start() | 0x7C7F90 | 0x7C7190 | 420 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::Update() | 0x7C81D0 | 0x7C73D0 | 1389 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::LateUpdate() | 0x7C6080 | 0x7C5280 | 53 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetFootstepVolumeMultiplier(System.Single) | 0x7C6D40 | 0x7C5F40 | 28 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetMotion(UnityEngine.Vector3,System.Boolean) | 0x7C6DE0 | 0x7C5FE0 | 620 |
| System.Single ScheduleOne.AvatarFramework.Animation.AvatarAnimation::UpdateBlend(System.Single,System.Single,UnityEngine.AnimationCurve) | 0x7C8140 | 0x7C7340 | 135 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetDirection(System.Single) | 0x7C6C00 | 0x7C5E00 | 123 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetStrafe(System.Single) | 0x7C7670 | 0x7C6870 | 124 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetTimeAirborne(System.Single) | 0x7C76F0 | 0x7C68F0 | 124 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetCrouched(System.Boolean) | 0x7C6B70 | 0x7C5D70 | 128 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetGrounded(System.Boolean) | 0x7C6D60 | 0x7C5F60 | 124 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::Jump() | 0x7C6010 | 0x7C5210 | 108 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetAnimationEnabled(System.Boolean) | 0x7C6A70 | 0x7C5C70 | 64 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::RefreshAnimatorActive() | 0x7C68F0 | 0x7C5AF0 | 63 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::ResetAnimatorState() | 0x7C6930 | 0x7C5B30 | 192 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::Flinch(UnityEngine.Vector3,ScheduleOne.AvatarFramework.Animation.AvatarAnimation/EFlinchType) | 0x7C5C60 | 0x7C4E60 | 740 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::PlayStandUpAnimation() | 0x7C60C0 | 0x7C52C0 | 586 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::RagdollChange(System.Boolean) | 0x7C6650 | 0x7C5850 | 660 |
| System.Boolean ScheduleOne.AvatarFramework.Animation.AvatarAnimation::IsHipBoneFacingUpwards() | 0x7C5F50 | 0x7C5150 | 188 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::PopulateBoneTransforms(ScheduleOne.AvatarFramework.Animation.AvatarAnimation/BoneTransform[]) | 0x7C6550 | 0x7C5750 | 242 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::PopulateAnimationStartBoneTransforms(System.String,ScheduleOne.AvatarFramework.Animation.AvatarAnimation/BoneTransform[]) | 0x7C6310 | 0x7C5510 | 572 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::ApplyBoneTransforms(ScheduleOne.AvatarFramework.Animation.AvatarAnimation/BoneTransform[]) | 0x7C5680 | 0x7C4880 | 252 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetTrigger(System.String) | 0x7C7770 | 0x7C6970 | 188 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::ResetTrigger(System.String) | 0x7C6A00 | 0x7C5C00 | 109 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetBool(System.String,System.Boolean) | 0x7C6AC0 | 0x7C5CC0 | 169 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetFloat(System.String,System.Single) | 0x7C6C80 | 0x7C5E80 | 190 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetSeat(ScheduleOne.AvatarFramework.Animation.AvatarSeat,System.String,System.Single) | 0x7C7050 | 0x7C6250 | 1562 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SkateboardMounted(ScheduleOne.Skating.Skateboard) | 0x7C7A10 | 0x7C6C10 | 1331 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SkateboardDismounted() | 0x7C7830 | 0x7C6A30 | 464 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SkateboardPush() | 0x7C7F50 | 0x7C7150 | 60 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::.ctor() | 0x7C8790 | 0x7C7990 | 108 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::.cctor() | 0x7C8740 | 0x7C7940 | 65 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::<Awake>b__56_0(System.Boolean) | 0x7C68F0 | 0x7C5AF0 | 63 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass73_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Collections.IEnumerator ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass73_0::<PlayStandUpAnimation>g__StandUpRoutine\|0() | 0x7DCB30 | 0x7DBD30 | 103 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass73_0/<<PlayStandUpAnimation>g__StandUpRoutine\|0>d::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass73_0/<<PlayStandUpAnimation>g__StandUpRoutine\|0>d::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass73_0/<<PlayStandUpAnimation>g__StandUpRoutine\|0>d::MoveNext() | 0x7DB660 | 0x7DA860 | 1743 |
| System.Object ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass73_0/<<PlayStandUpAnimation>g__StandUpRoutine\|0>d::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass73_0/<<PlayStandUpAnimation>g__StandUpRoutine\|0>d::System.Collections.IEnumerator.Reset() | 0x7DBD30 | 0x7DAF30 | 62 |
| System.Object ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass73_0/<<PlayStandUpAnimation>g__StandUpRoutine\|0>d::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Collections.IEnumerator ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_0::<SetSeat>g__LerpToStandingPosition\|0() | 0x7DCBA0 | 0x7DBDA0 | 103 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_0/<<SetSeat>g__LerpToStandingPosition\|0>d::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_0/<<SetSeat>g__LerpToStandingPosition\|0>d::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_0/<<SetSeat>g__LerpToStandingPosition\|0>d::MoveNext() | 0x7DC090 | 0x7DB290 | 1061 |
| System.Object ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_0/<<SetSeat>g__LerpToStandingPosition\|0>d::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_0/<<SetSeat>g__LerpToStandingPosition\|0>d::System.Collections.IEnumerator.Reset() | 0x7DC4C0 | 0x7DB6C0 | 62 |
| System.Object ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_0/<<SetSeat>g__LerpToStandingPosition\|0>d::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_1::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Collections.IEnumerator ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_1::<SetSeat>g__LerpToSeat\|1() | 0x7DCC10 | 0x7DBE10 | 103 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_1/<<SetSeat>g__LerpToSeat\|1>d::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_1/<<SetSeat>g__LerpToSeat\|1>d::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_1/<<SetSeat>g__LerpToSeat\|1>d::MoveNext() | 0x7DBD70 | 0x7DAF70 | 735 |
| System.Object ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_1/<<SetSeat>g__LerpToSeat\|1>d::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_1/<<SetSeat>g__LerpToSeat\|1>d::System.Collections.IEnumerator.Reset() | 0x7DC050 | 0x7DB250 | 62 |
| System.Object ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_1/<<SetSeat>g__LerpToSeat\|1>d::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimationId::Init() | 0x7C52D0 | 0x7C44D0 | 158 |
| System.Int32 ScheduleOne.AvatarFramework.Animation.AvatarAnimationId::Get(System.String) | 0x7C51B0 | 0x7C43B0 | 279 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimationId::.cctor() | 0x7C5370 | 0x7C4570 | 771 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarIKController::Awake() | 0x7CBF00 | 0x7CB100 | 129 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarIKController::Start() | 0x7CC0B0 | 0x7CB2B0 | 32 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarIKController::SetIKActive(System.Boolean) | 0x7CC090 | 0x7CB290 | 30 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarIKController::OverrideLegBendTargets(UnityEngine.Transform,UnityEngine.Transform) | 0x7CBF90 | 0x7CB190 | 126 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarIKController::ResetLegBendTargets() | 0x7CC010 | 0x7CB210 | 119 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarIKController::.ctor() | 0x41D490 | 0x41C690 | 7 |
| System.Single ScheduleOne.AvatarFramework.Animation.AvatarLookController::get_BodyRotationSpeedMultiplier() | 0x460F20 | 0x460120 | 6 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::set_BodyRotationSpeedMultiplier(System.Single) | 0x460F60 | 0x460160 | 6 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::Awake() | 0x7CC5C0 | 0x7CB7C0 | 276 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::UpdateLook() | 0x7CD500 | 0x7CC700 | 2991 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::UpdateNearestPlayer() | 0x7CE0B0 | 0x7CD2B0 | 470 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::LateUpdate() | 0x7CC7D0 | 0x7CB9D0 | 1664 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::OverrideLookTarget(UnityEngine.Vector3,System.Int32,System.Boolean) | 0x7CD2B0 | 0x7CC4B0 | 512 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::BlockLookTargetOverrides() | 0x7CC6E0 | 0x7CB8E0 | 8 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::LookForward() | 0x7CD130 | 0x7CC330 | 324 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::LerpTargetTransform() | 0x7CCE60 | 0x7CC060 | 704 |
| System.Boolean ScheduleOne.AvatarFramework.Animation.AvatarLookController::CanLookAt(UnityEngine.Vector3) | 0x7CC6F0 | 0x7CB8F0 | 223 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::OverrideIKWeight(System.Single) | 0x7CD280 | 0x7CC480 | 39 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::ResetIKWeight() | 0x7CD4C0 | 0x7CC6C0 | 50 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::.ctor() | 0x7CE370 | 0x7CD570 | 241 |
| System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::.cctor() | 0x7CE290 | 0x7CD490 | 210 |
| System.Void ScheduleOne.NPCs.NPCAnimation::Awake() | 0x8E9420 | 0x8E8620 | 307 |
| System.Void ScheduleOne.NPCs.NPCAnimation::Start() | 0x8E9680 | 0x8E8880 | 491 |
| System.Void ScheduleOne.NPCs.NPCAnimation::Update() | 0x8E9A10 | 0x8E8C10 | 112 |
| System.Void ScheduleOne.NPCs.NPCAnimation::UpdateMovementAnimation() | 0x8E9870 | 0x8E8A70 | 408 |
| System.Void ScheduleOne.NPCs.NPCAnimation::StandupStart() | 0x8E9600 | 0x8E8800 | 113 |
| System.Void ScheduleOne.NPCs.NPCAnimation::StandupDone() | 0x8E95A0 | 0x8E87A0 | 95 |
| System.Void ScheduleOne.NPCs.NPCAnimation::OnNPCVisibilityChanged(System.Boolean) | 0x8E9560 | 0x8E8760 | 59 |
| System.Void ScheduleOne.NPCs.NPCAnimation::.ctor() | 0x41D490 | 0x41C690 | 7 |

Полные поля и offsets: [selected-types-fields](../EVIDENCE/current/selected-types-fields.json). Public proxy API: [interop-selected-api](../EVIDENCE/current/interop-selected-api.json).

## Сохранённые native roots
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::Start()](../EVIDENCE/current/native/7C7F90.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::Update()](../EVIDENCE/current/native/7C81D0.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::LateUpdate()](../EVIDENCE/current/native/7C6080.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetMotion(UnityEngine.Vector3,System.Boolean)](../EVIDENCE/current/native/7C6DE0.asm.txt)
- [System.Single ScheduleOne.AvatarFramework.Animation.AvatarAnimation::UpdateBlend(System.Single,System.Single,UnityEngine.AnimationCurve)](../EVIDENCE/current/native/7C8140.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetAnimationEnabled(System.Boolean)](../EVIDENCE/current/native/7C6A70.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::RefreshAnimatorActive()](../EVIDENCE/current/native/7C68F0.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetTrigger(System.String)](../EVIDENCE/current/native/7C7770.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::ResetTrigger(System.String)](../EVIDENCE/current/native/7C6A00.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetBool(System.String,System.Boolean)](../EVIDENCE/current/native/7C6AC0.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimation::SetFloat(System.String,System.Single)](../EVIDENCE/current/native/7C6C80.asm.txt)
- [System.Boolean ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass73_0/<<PlayStandUpAnimation>g__StandUpRoutine|0>d::MoveNext()](../EVIDENCE/current/native/7DB660.asm.txt)
- [System.Boolean ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_0/<<SetSeat>g__LerpToStandingPosition|0>d::MoveNext()](../EVIDENCE/current/native/7DC090.asm.txt)
- [System.Boolean ScheduleOne.AvatarFramework.Animation.AvatarAnimation/<>c__DisplayClass83_1/<<SetSeat>g__LerpToSeat|1>d::MoveNext()](../EVIDENCE/current/native/7DBD70.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarIKController::Start()](../EVIDENCE/current/native/7CC0B0.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarLookController::LateUpdate()](../EVIDENCE/current/native/7CC7D0.asm.txt)
- [System.Void ScheduleOne.NPCs.NPCAnimation::Start()](../EVIDENCE/current/native/8E9680.asm.txt)
- [System.Void ScheduleOne.NPCs.NPCAnimation::Update()](../EVIDENCE/current/native/8E9A10.asm.txt)
- [System.Void ScheduleOne.NPCs.NPCAnimation::UpdateMovementAnimation()](../EVIDENCE/current/native/8E9870.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimationId::Init()](../EVIDENCE/current/native/7C52D0.asm.txt)
- [System.Int32 ScheduleOne.AvatarFramework.Animation.AvatarAnimationId::Get(System.String)](../EVIDENCE/current/native/7C51B0.asm.txt)
- [System.Void ScheduleOne.AvatarFramework.Animation.AvatarAnimationId::.cctor()](../EVIDENCE/current/native/7C5370.asm.txt)

[Native edge records](../EVIDENCE/current/native-edges.json). [Правила aliasing и scope](../REVERSE_ENGINEERING/EVIDENCE_RULES.md). [Исторический NPC report](../EVIDENCE/phase2/REPORT.ru.md). [Mod call sites](../EVIDENCE/current/mod-call-sites.json).
