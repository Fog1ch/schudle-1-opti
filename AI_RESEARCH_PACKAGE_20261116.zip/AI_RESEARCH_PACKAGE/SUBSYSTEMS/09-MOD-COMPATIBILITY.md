# Mod compatibility и MelonLoader

## Scope и подтверждённые наблюдения
С Cecil прочитаны 15 managed assemblies верхнего уровня Mods/UserLibs/Plugins: 10 Mods и 5 UserLibs. Записаны assembly refs/versions/MVID, 26013 IL call/newobj sites и 103 Harmony attribute records. Это статические записи, не число runtime вызовов или независимых патчей.
Подтверждено пересечение объявленных targets: Schedule1BetterEmployees prefix и WagesManager postfix для PackagerConfiguration.ShouldSave. Это основание для аудита результата и порядка, не доказанный конфликт.
Рекурсивные аргументы атрибутов сохранены. Dynamic Harmony.Patch/TargetMethod/рефлексия и фактический порядок loaders полностью не разрешены. ScheduleRu и XUnity не объявляются полностью дублирующими перевод по именам. Локальный build ScheduleRu ранее не совпал с установленным: не пересобирать вслепую.

## Возможности, пока гипотезы
Составить точную карту dynamic patch targets, результат prefix/postfix и resolution paths; отдельно измерить UI scan и диагностическую запись.

## Риски и неизвестное
Изменение сохранений и employee configuration, порядок Harmony, сторонние writers, версия IL2CPP interop. Метаданные не гарантируют совместимость.

## Адресуемые методы
| Метод | RVA | Offset | Cpp2IL bytes |
|---|---|---|---|

Полные поля и offsets: [selected-types-fields](../EVIDENCE/current/selected-types-fields.json). Public proxy API: [interop-selected-api](../EVIDENCE/current/interop-selected-api.json).

## Сохранённые native roots

[Native edge records](../EVIDENCE/current/native-edges.json). [Правила aliasing и scope](../REVERSE_ENGINEERING/EVIDENCE_RULES.md). [Исторический NPC report](../EVIDENCE/phase2/REPORT.ru.md). [Mod call sites](../EVIDENCE/current/mod-call-sites.json).
