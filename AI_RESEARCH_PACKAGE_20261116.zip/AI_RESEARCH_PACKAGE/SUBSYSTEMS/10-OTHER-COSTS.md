# Дополнительные направления: UI, транспорт, networking

## Scope и подтверждённые наблюдения
VehicleAgent.LateUpdate содержит PID.Update и пути String.Concat/Debug.Log; наличие путей логирования не доказывает выполнение каждый кадр. Reverse coroutine обращается к GetWheelSweepCollision и path utilities.
PlayerVisibility.Update вызывает сетевые ApplyState/RemoveState пути. FishNet timing metadata проиндексирована, но полная runtime tick graph не исследована.
Из прежнего установленного ScheduleRu IL: CanvasScanInterval=0 допускает один очередной canvas scan каждый кадр через GetComponentsInChildren<TMP_Text>, НЕ обход всех canvases каждый кадр. DumpUntranslated=true допускает AppendAllText. Это конкретные кандидаты, а не подтверждённая причина FPS.

## Возможности, пока гипотезы
Разрешённое в будущем измерение UI scan cadence, branch logging и сетевой роли. Изменять только отдельный параметр или узкий компонент после согласования.

## Риски и неизвестное
Задержка перевода UI, потеря диагностик, transport/host behavior. Не трогать Steam/DRM или сторонние сетевые защиты.

## Адресуемые методы
| Метод | RVA | Offset | Cpp2IL bytes |
|---|---|---|---|
| System.Boolean ScheduleOne.Vehicles.AI.VehicleAgent::get_AutoDriving() | 0x5DF7B0 | 0x5DE9B0 | 5 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::set_AutoDriving(System.Boolean) | 0x5DF880 | 0x5DEA80 | 4 |
| System.Boolean ScheduleOne.Vehicles.AI.VehicleAgent::get_KinematicMode() | 0xAD9980 | 0xAD8B80 | 44 |
| System.Boolean ScheduleOne.Vehicles.AI.VehicleAgent::get_IsReversing() | 0xAD9970 | 0xAD8B70 | 12 |
| UnityEngine.Vector3 ScheduleOne.Vehicles.AI.VehicleAgent::get_TargetLocation() | 0x4A1B80 | 0x4A0D80 | 19 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::set_TargetLocation(UnityEngine.Vector3) | 0x4A1E30 | 0x4A1030 | 16 |
| System.Single ScheduleOne.Vehicles.AI.VehicleAgent::get_sampleStepSize() | 0xAD9AD0 | 0xAD8CD0 | 138 |
| System.Single ScheduleOne.Vehicles.AI.VehicleAgent::get_turnSpeedReductionRange() | 0xAD9B80 | 0xAD8D80 | 138 |
| UnityEngine.LayerMask ScheduleOne.Vehicles.AI.VehicleAgent::get__wheelSweepCollisionMask() | 0x77B520 | 0x77A720 | 26 |
| System.Single ScheduleOne.Vehicles.AI.VehicleAgent::get_maxSteerAngle() | 0xAD9AA0 | 0xAD8CA0 | 32 |
| UnityEngine.Vector3 ScheduleOne.Vehicles.AI.VehicleAgent::get_frontOfVehiclePosition() | 0xAD99C0 | 0xAD8BC0 | 223 |
| System.Boolean ScheduleOne.Vehicles.AI.VehicleAgent::get_NavigationCalculationInProgress() | 0xAD99B0 | 0xAD8BB0 | 12 |
| System.Single ScheduleOne.Vehicles.AI.VehicleAgent::get_timeSinceLastNavigationCall() | 0xAD9B60 | 0xAD8D60 | 30 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::Awake() | 0xAD2A10 | 0xAD1C10 | 1049 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::Start() | 0xAD6B90 | 0xAD5D90 | 242 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::InitializeVehicleData() | 0xAD5600 | 0xAD4800 | 2675 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::FixedUpdate() | 0xAD3340 | 0xAD2540 | 16 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::InfrequentUpdate() | 0xAD5280 | 0xAD4480 | 887 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::LateUpdate() | 0xAD60A0 | 0xAD52A0 | 534 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::UpdateKinematic(System.Single) | 0xAD6F80 | 0xAD6180 | 2709 |
| UnityEngine.Vector3 ScheduleOne.Vehicles.AI.VehicleAgent::GetAxleGroundHit(System.Boolean) | 0xAD3350 | 0xAD2550 | 756 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::UpdateSweep() | 0xAD94C0 | 0xAD86C0 | 597 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::UpdateSpeedReduction() | 0xAD7D20 | 0xAD6F20 | 2426 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::UpdatePursuitMode() | 0xAD7B00 | 0xAD6D00 | 530 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::UpdateStuckDetection() | 0xAD9190 | 0xAD8390 | 805 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::CheckDistanceFromPath() | 0xAD2E30 | 0xAD2030 | 951 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::UpdateOvertaking() | 0xAD7A20 | 0xAD6C20 | 213 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::RefreshSpeedZone() | 0xAD69B0 | 0xAD5BB0 | 201 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::UpdateSpeed() | 0xAD86A0 | 0xAD78A0 | 267 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::UpdateSteering() | 0xAD87B0 | 0xAD79B0 | 2520 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::Navigate(UnityEngine.Vector3,ScheduleOne.Vehicles.AI.NavigationSettings,ScheduleOne.Vehicles.AI.VehicleAgent/NavigationCallback) | 0xAD62C0 | 0xAD54C0 | 1513 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::NavigationCalculationCallback(ScheduleOne.Vehicles.AI.NavigationUtility/ENavigationCalculationResult,ScheduleOne.Math.PathSmoothingUtility/SmoothedPath) | 0xAD68B0 | 0xAD5AB0 | 169 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::EndDriving() | 0xAD31F0 | 0xAD23F0 | 327 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::StopNavigating() | 0xAD6C90 | 0xAD5E90 | 82 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::RecalculateNavigation() | 0xAD6960 | 0xAD5B60 | 66 |
| System.Boolean ScheduleOne.Vehicles.AI.VehicleAgent::GetWheelSweepCollision(ScheduleOne.Vehicles.AI.VehicleAgent/ESweepType,System.Single,System.Boolean,System.Single&,UnityEngine.RaycastHit&) | 0xAD42D0 | 0xAD34D0 | 4011 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::StartReverse() | 0xAD6AF0 | 0xAD5CF0 | 152 |
| System.Collections.IEnumerator ScheduleOne.Vehicles.AI.VehicleAgent::Reverse() | 0xAD6A80 | 0xAD5C80 | 103 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::StopReversing() | 0xAD6CF0 | 0xAD5EF0 | 162 |
| System.Boolean ScheduleOne.Vehicles.AI.VehicleAgent::IsOnVehicleGraph() | 0xAD6080 | 0xAD5280 | 30 |
| System.Single ScheduleOne.Vehicles.AI.VehicleAgent::GetDistanceFromVehicleGraph() | 0xAD3650 | 0xAD2850 | 769 |
| UnityEngine.Vector3 ScheduleOne.Vehicles.AI.VehicleAgent::GetPathLateralDirection() | 0xAD4000 | 0xAD3200 | 709 |
| System.Boolean ScheduleOne.Vehicles.AI.VehicleAgent::GetForwardObstacle(System.Single,UnityEngine.LayerMask,UnityEngine.Vector3&,System.Single&) | 0xAD3960 | 0xAD2B60 | 979 |
| System.Boolean ScheduleOne.Vehicles.AI.VehicleAgent::GetIsStuck() | 0xAD3D40 | 0xAD2F40 | 703 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::.ctor() | 0xAD9840 | 0xAD8A40 | 294 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent::.cctor() | 0xAD9720 | 0xAD8920 | 278 |
| System.Boolean ScheduleOne.Vehicles.AI.VehicleAgent::<Reverse>b__143_0() | 0xAD6F50 | 0xAD6150 | 44 |
| System.Boolean ScheduleOne.Vehicles.AI.VehicleAgent::<GetForwardObstacle>g__IsValidHit\|148_0(UnityEngine.RaycastHit) | 0xAD6EF0 | 0xAD60F0 | 94 |
| System.Single ScheduleOne.Vehicles.AI.VehicleAgent::<GetForwardObstacle>b__148_1(UnityEngine.RaycastHit) | 0xAD6DA0 | 0xAD5FA0 | 320 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent/NavigationCallback::.ctor(System.Object,System.IntPtr) | 0x9D7510 | 0x9D6710 | 143 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent/NavigationCallback::Invoke(ScheduleOne.Vehicles.AI.VehicleAgent/ENavigationResult) | 0x536A90 | 0x535C90 | 15 |
| System.IAsyncResult ScheduleOne.Vehicles.AI.VehicleAgent/NavigationCallback::BeginInvoke(ScheduleOne.Vehicles.AI.VehicleAgent/ENavigationResult,System.AsyncCallback,System.Object) | 0xAC9D40 | 0xAC8F40 | 122 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent/NavigationCallback::EndInvoke(System.IAsyncResult) | 0x4255D0 | 0x4247D0 | 10 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent/<>c::.cctor() | 0xAD29A0 | 0xAD1BA0 | 103 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent/<>c::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Single ScheduleOne.Vehicles.AI.VehicleAgent/<>c::<UpdateKinematic>b__125_0(UnityEngine.RaycastHit) | 0xAD2650 | 0xAD1850 | 19 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent/<>c__DisplayClass141_0::.ctor() | 0x41D580 | 0x41C780 | 7 |
| System.Single ScheduleOne.Vehicles.AI.VehicleAgent/<>c__DisplayClass141_0::<GetWheelSweepCollision>b__0(UnityEngine.RaycastHit) | 0xAD26C0 | 0xAD18C0 | 248 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent/<Reverse>d__143::.ctor(System.Int32) | 0x52D2B0 | 0x52C4B0 | 36 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent/<Reverse>d__143::System.IDisposable.Dispose() | 0x43FEC0 | 0x43F0C0 | 3 |
| System.Boolean ScheduleOne.Vehicles.AI.VehicleAgent/<Reverse>d__143::MoveNext() | 0xACFA60 | 0xACEC60 | 4091 |
| System.Object ScheduleOne.Vehicles.AI.VehicleAgent/<Reverse>d__143::System.Collections.Generic.IEnumerator<System.Object>.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.Vehicles.AI.VehicleAgent/<Reverse>d__143::System.Collections.IEnumerator.Reset() | 0xAD0A60 | 0xACFC60 | 62 |
| System.Object ScheduleOne.Vehicles.AI.VehicleAgent/<Reverse>d__143::System.Collections.IEnumerator.get_Current() | 0x43F260 | 0x43E460 | 5 |
| System.Void ScheduleOne.Vision.PlayerVisibility::Awake() | 0x58E4B0 | 0x58D6B0 | 361 |
| System.Void ScheduleOne.Vision.PlayerVisibility::Update() | 0x58E8F0 | 0x58DAF0 | 383 |
| System.Void ScheduleOne.Vision.PlayerVisibility::LateUpdate() | 0x58E620 | 0x58D820 | 335 |
| System.Void ScheduleOne.Vision.PlayerVisibility::AddFlag_DisobeyingCurfew() | 0x58E2E0 | 0x58D4E0 | 124 |
| System.Void ScheduleOne.Vision.PlayerVisibility::RemoveFlag_DisobeyingCurfew() | 0x58E880 | 0x58DA80 | 99 |
| System.Single ScheduleOne.Vision.PlayerVisibility::get_Suspiciousness() | 0x58EC80 | 0x58DE80 | 514 |
| System.Collections.Generic.List`1<UnityEngine.Vector3> ScheduleOne.Vision.PlayerVisibility::GetVisibilityPoints() | 0x561780 | 0x560980 | 8 |
| System.Void ScheduleOne.Vision.PlayerVisibility::.ctor() | 0x58EA70 | 0x58DC70 | 521 |
| System.Void ScheduleOne.Vision.PlayerVisibility::<Awake>b__3_0() | 0x5801C0 | 0x57F3C0 | 252 |
| System.Void ScheduleOne.Vision.PlayerVisibility::NetworkInitialize___Early() | 0x58E7A0 | 0x58D9A0 | 220 |
| System.Void ScheduleOne.Vision.PlayerVisibility::NetworkInitialize__Late() | 0x58E770 | 0x58D970 | 33 |
| System.Void ScheduleOne.Vision.PlayerVisibility::NetworkInitializeIfDisabled() | 0x57F1D0 | 0x57E3D0 | 50 |
| System.Void ScheduleOne.Vision.PlayerVisibility::Awake_UserLogic_ScheduleOne.Vision.PlayerVisibility_Assembly-CSharp.dll() | 0x58E360 | 0x58D560 | 326 |
| System.Void ScheduleOne.Vision.PlayerVisibility/<>c::.cctor() | 0x592F40 | 0x592140 | 103 |
| System.Void ScheduleOne.Vision.PlayerVisibility/<>c::.ctor() | 0x41D580 | 0x41C780 | 7 |
| UnityEngine.Vector3 ScheduleOne.Vision.PlayerVisibility/<>c::<LateUpdate>b__5_0(UnityEngine.Transform) | 0x5926F0 | 0x5918F0 | 61 |
| System.Void FishNet.Managing.Timing.TimeManager::add_OnRoundTripTimeUpdated(System.Action`1<System.Int64>) | 0xD38AB0 | 0xD37CB0 | 161 |
| System.Void FishNet.Managing.Timing.TimeManager::remove_OnRoundTripTimeUpdated(System.Action`1<System.Int64>) | 0xD39140 | 0xD38340 | 161 |
| System.Void FishNet.Managing.Timing.TimeManager::add_OnPreTick(System.Action) | 0xD38A10 | 0xD37C10 | 159 |
| System.Void FishNet.Managing.Timing.TimeManager::remove_OnPreTick(System.Action) | 0xD390A0 | 0xD382A0 | 159 |
| System.Void FishNet.Managing.Timing.TimeManager::add_OnTick(System.Action) | 0xD38B60 | 0xD37D60 | 159 |
| System.Void FishNet.Managing.Timing.TimeManager::remove_OnTick(System.Action) | 0xD391F0 | 0xD383F0 | 159 |
| System.Void FishNet.Managing.Timing.TimeManager::add_OnPrePhysicsSimulation(System.Action`1<System.Single>) | 0xD38960 | 0xD37B60 | 161 |
| System.Void FishNet.Managing.Timing.TimeManager::remove_OnPrePhysicsSimulation(System.Action`1<System.Single>) | 0xD38FF0 | 0xD381F0 | 161 |
| System.Void FishNet.Managing.Timing.TimeManager::add_OnPostPhysicsSimulation(System.Action`1<System.Single>) | 0xD38810 | 0xD37A10 | 161 |
| System.Void FishNet.Managing.Timing.TimeManager::remove_OnPostPhysicsSimulation(System.Action`1<System.Single>) | 0xD38EA0 | 0xD380A0 | 161 |
| System.Void FishNet.Managing.Timing.TimeManager::add_OnPostTick(System.Action) | 0xD388C0 | 0xD37AC0 | 159 |
| System.Void FishNet.Managing.Timing.TimeManager::remove_OnPostTick(System.Action) | 0xD38F50 | 0xD38150 | 159 |
| System.Void FishNet.Managing.Timing.TimeManager::add_OnUpdate(System.Action) | 0xD38C00 | 0xD37E00 | 159 |
| System.Void FishNet.Managing.Timing.TimeManager::remove_OnUpdate(System.Action) | 0xD39290 | 0xD38490 | 159 |
| System.Void FishNet.Managing.Timing.TimeManager::add_OnLateUpdate(System.Action) | 0xD38770 | 0xD37970 | 159 |
| System.Void FishNet.Managing.Timing.TimeManager::remove_OnLateUpdate(System.Action) | 0xD38E00 | 0xD38000 | 159 |
| System.Void FishNet.Managing.Timing.TimeManager::add_OnFixedUpdate(System.Action) | 0xD386D0 | 0xD378D0 | 159 |
| System.Void FishNet.Managing.Timing.TimeManager::remove_OnFixedUpdate(System.Action) | 0xD38D60 | 0xD37F60 | 159 |
| System.Int64 FishNet.Managing.Timing.TimeManager::get_RoundTripTime() | 0x4368B0 | 0x435AB0 | 5 |
| System.Void FishNet.Managing.Timing.TimeManager::set_RoundTripTime(System.Int64) | 0xD39340 | 0xD38540 | 5 |
| System.Boolean FishNet.Managing.Timing.TimeManager::get_LowFrameRate() | 0xD38CF0 | 0xD37EF0 | 44 |
| System.UInt32 FishNet.Managing.Timing.TimeManager::get_LastPacketTick() | 0x4CBCF0 | 0x4CAEF0 | 4 |
| System.Void FishNet.Managing.Timing.TimeManager::set_LastPacketTick(System.UInt32) | 0xA684A0 | 0xA676A0 | 4 |
| System.Void FishNet.Managing.Timing.TimeManager::SetLastPacketTick(System.UInt32) | 0xD37690 | 0xD36890 | 12 |
| System.UInt32 FishNet.Managing.Timing.TimeManager::get_Tick() | 0x506990 | 0x505B90 | 4 |
| System.Void FishNet.Managing.Timing.TimeManager::set_Tick(System.UInt32) | 0xD39370 | 0xD38570 | 4 |
| System.Double FishNet.Managing.Timing.TimeManager::get_TickDelta() | 0xD38D40 | 0xD37F40 | 9 |
| System.Void FishNet.Managing.Timing.TimeManager::set_TickDelta(System.Double) | 0xD39350 | 0xD38550 | 9 |
| System.Boolean FishNet.Managing.Timing.TimeManager::get_FrameTicked() | 0xD38CA0 | 0xD37EA0 | 8 |
| System.Void FishNet.Managing.Timing.TimeManager::set_FrameTicked(System.Boolean) | 0xD39330 | 0xD38530 | 7 |
| System.Single FishNet.Managing.Timing.TimeManager::get_ServerUptime() | 0x65A620 | 0x659820 | 9 |
| System.Void FishNet.Managing.Timing.TimeManager::set_ServerUptime(System.Single) | 0xBE7890 | 0xBE6A90 | 9 |
| System.Single FishNet.Managing.Timing.TimeManager::get_ClientUptime() | 0x4823B0 | 0x4815B0 | 9 |
| System.Void FishNet.Managing.Timing.TimeManager::set_ClientUptime(System.Single) | 0x53B860 | 0x53AA60 | 9 |
| System.UInt16 FishNet.Managing.Timing.TimeManager::get_TickRate() | 0xD38D50 | 0xD37F50 | 8 |
| System.Void FishNet.Managing.Timing.TimeManager::set_TickRate(System.UInt16) | 0xD39360 | 0xD38560 | 8 |
| System.Byte FishNet.Managing.Timing.TimeManager::get_PingInterval() | 0x544A50 | 0x543C50 | 8 |
| FishNet.Managing.Timing.PhysicsMode FishNet.Managing.Timing.TimeManager::get_PhysicsMode() | 0xBE7860 | 0xBE6A60 | 7 |
| System.UInt32 FishNet.Managing.Timing.TimeManager::get_LocalTick() | 0xD38CB0 | 0xD37EB0 | 58 |
| System.Void FishNet.Managing.Timing.TimeManager::set_LocalTick(System.UInt32) | 0xBE78B0 | 0xBE6AB0 | 7 |
| System.Byte FishNet.Managing.Timing.TimeManager::get_RESET_ADJUSTMENT_THRESHOLD() | 0xD38D20 | 0xD37F20 | 30 |
| System.Void FishNet.Managing.Timing.TimeManager::TickFixedUpdate() | 0xD37860 | 0xD36A60 | 139 |
| System.Void FishNet.Managing.Timing.TimeManager::TickUpdate() | 0xD379C0 | 0xD36BC0 | 341 |
| System.Void FishNet.Managing.Timing.TimeManager::TickLateUpdate() | 0xD378F0 | 0xD36AF0 | 22 |
| System.Void FishNet.Managing.Timing.TimeManager::InitializeOnce_Internal(FishNet.Managing.NetworkManager) | 0xD367F0 | 0xD359F0 | 520 |
| System.Void FishNet.Managing.Timing.TimeManager::AddNetworkLoops() | 0xD35F50 | 0xD35150 | 238 |
| System.Void FishNet.Managing.Timing.TimeManager::ClientManager_OnClientConnectionState(FishNet.Transporting.ClientConnectionStateArgs) | 0xD36040 | 0xD35240 | 135 |
| System.Void FishNet.Managing.Timing.TimeManager::ServerManager_OnServerConnectionState(FishNet.Transporting.ServerConnectionStateArgs) | 0xD37460 | 0xD36660 | 72 |
| System.Void FishNet.Managing.Timing.TimeManager::SetInitialValues() | 0xD37570 | 0xD36770 | 275 |
| System.Void FishNet.Managing.Timing.TimeManager::UnsetSimulationSettings() | 0xD384D0 | 0xD376D0 | 182 |
| System.Void FishNet.Managing.Timing.TimeManager::SetAutomaticPhysicsSimulation(System.Boolean) | 0xD374B0 | 0xD366B0 | 183 |
| System.Void FishNet.Managing.Timing.TimeManager::InitializePhysicsMode(FishNet.Managing.Timing.PhysicsMode) | 0xD36A00 | 0xD35C00 | 256 |
| System.Void FishNet.Managing.Timing.TimeManager::SetPhysicsMode(FishNet.Managing.Timing.PhysicsMode) | 0xD376A0 | 0xD368A0 | 239 |
| System.Void FishNet.Managing.Timing.TimeManager::ModifyPing(System.UInt32) | 0xD36B90 | 0xD35D90 | 249 |
| System.Void FishNet.Managing.Timing.TimeManager::TrySendPing(System.Nullable`1<System.UInt32>) | 0xD37FB0 | 0xD371B0 | 1026 |
| System.Void FishNet.Managing.Timing.TimeManager::SendPong(FishNet.Connection.NetworkConnection,System.UInt32) | 0xD37000 | 0xD36200 | 291 |
| System.Void FishNet.Managing.Timing.TimeManager::IncreaseTick() | 0xD362A0 | 0xD354A0 | 1347 |
| System.Double FishNet.Managing.Timing.TimeManager::GetTickPercent() | 0xD36280 | 0xD35480 | 25 |
| FishNet.Managing.Timing.PreciseTick FishNet.Managing.Timing.TimeManager::GetPreciseTick(System.UInt32) | 0xD36250 | 0xD35450 | 43 |
| FishNet.Managing.Timing.PreciseTick FishNet.Managing.Timing.TimeManager::GetPreciseTick(FishNet.Managing.Timing.TickType) | 0xD360D0 | 0xD352D0 | 382 |
| System.Double FishNet.Managing.Timing.TimeManager::TicksToTime(FishNet.Managing.Timing.TickType) | 0xD37B20 | 0xD36D20 | 238 |
| System.Double FishNet.Managing.Timing.TimeManager::TicksToTime(FishNet.Managing.Timing.PreciseTick) | 0xD37C10 | 0xD36E10 | 44 |
| System.Double FishNet.Managing.Timing.TimeManager::TicksToTime(System.UInt32) | 0xD37C40 | 0xD36E40 | 19 |
| System.Double FishNet.Managing.Timing.TimeManager::TimePassed(System.UInt32,System.UInt32) | 0xD37CA0 | 0xD36EA0 | 71 |
| System.Double FishNet.Managing.Timing.TimeManager::TimePassed(FishNet.Managing.Timing.PreciseTick,System.Boolean) | 0xD37CF0 | 0xD36EF0 | 296 |
| System.Double FishNet.Managing.Timing.TimeManager::TimePassed(System.UInt32,System.Boolean) | 0xD37C60 | 0xD36E60 | 57 |
| System.UInt32 FishNet.Managing.Timing.TimeManager::TimeToTicks(System.Double,FishNet.Managing.Timing.TickRounding) | 0xD37E20 | 0xD37020 | 197 |
| System.UInt32 FishNet.Managing.Timing.TimeManager::TickToLocalTick(System.UInt32) | 0xD37910 | 0xD36B10 | 164 |
| System.UInt32 FishNet.Managing.Timing.TimeManager::LocalTickToTick(System.UInt32) | 0xD36B10 | 0xD35D10 | 124 |
| System.Void FishNet.Managing.Timing.TimeManager::TryIterateData(System.Boolean) | 0xD37EF0 | 0xD370F0 | 187 |
| System.Void FishNet.Managing.Timing.TimeManager::SendTimingAdjustment() | 0xD37130 | 0xD36330 | 802 |
| System.Void FishNet.Managing.Timing.TimeManager::ParseTimingUpdate(FishNet.Serializing.PooledReader) | 0xD36CA0 | 0xD35EA0 | 854 |
| System.Void FishNet.Managing.Timing.TimeManager::SetTickRate(System.UInt16) | 0xD37790 | 0xD36990 | 206 |
| System.Void FishNet.Managing.Timing.TimeManager::OnValidate() | 0xD36C90 | 0xD35E90 | 7 |
| System.Void FishNet.Managing.Timing.TimeManager::.ctor() | 0xD38590 | 0xD37790 | 309 |
| System.Void FishNet.Managing.Timing.TimeManager::<TickUpdate>g__MethodLogic\|103_0() | 0xD38470 | 0xD37670 | 86 |
| System.Void FishNet.Managing.Timing.TimeManager::<ParseTimingUpdate>g__UpdateTick\|135_0() | 0xD383C0 | 0xD375C0 | 162 |

Полные поля и offsets: [selected-types-fields](../EVIDENCE/current/selected-types-fields.json). Public proxy API: [interop-selected-api](../EVIDENCE/current/interop-selected-api.json).

## Сохранённые native roots
- [System.Void ScheduleOne.Vehicles.AI.VehicleAgent::Start()](../EVIDENCE/current/native/AD6B90.asm.txt)
- [System.Void ScheduleOne.Vehicles.AI.VehicleAgent::FixedUpdate()](../EVIDENCE/current/native/AD3340.asm.txt)
- [System.Void ScheduleOne.Vehicles.AI.VehicleAgent::LateUpdate()](../EVIDENCE/current/native/AD60A0.asm.txt)
- [System.Boolean ScheduleOne.Vehicles.AI.VehicleAgent/<Reverse>d__143::MoveNext()](../EVIDENCE/current/native/ACFA60.asm.txt)
- [System.Void ScheduleOne.Vision.PlayerVisibility::Update()](../EVIDENCE/current/native/58E8F0.asm.txt)
- [System.Void ScheduleOne.Vision.PlayerVisibility::LateUpdate()](../EVIDENCE/current/native/58E620.asm.txt)

[Native edge records](../EVIDENCE/current/native-edges.json). [Правила aliasing и scope](../REVERSE_ENGINEERING/EVIDENCE_RULES.md). [Исторический NPC report](../EVIDENCE/phase2/REPORT.ru.md). [Mod call sites](../EVIDENCE/current/mod-call-sites.json).
